import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.ws.Holder;


import Query.GetMaxAuditIDResponse;
import Query.GetMaxTableAuditID;
import Query.GetMaxTableAuditIDResponse;
import Query.ParametersPadding;
import Query.QueryData;
import Query.QueryDataByDate;
import Query.QueryDataByDate2;
import Query.QueryDataByDate2Response;
import Query.QueryDataByDate3;
import Query.QueryDataByDate3Response;
import Query.QueryDataByDateResponse;
import Query.QueryDataByID;
import Query.QueryDataByID2;
import Query.QueryDataByID2Response;
import Query.QueryDataByID3;
import Query.QueryDataByID3Response;
import Query.QueryDataByIDResponse;
import Query.QueryDataPortType;
import Query.QueryDataReturn;
import Query.Security;
import Query.Security.UsernameToken;



public class TestQueryService {
	
	public static void main(String[] args){
		try{
			QueryData sp = new QueryData();
			QueryDataPortType portType = sp.getQueryDataHttpSoap11Endpoint();

			TestQueryService test = new TestQueryService();
			/*test queryDataByID2 begin*//*
		    String beginAuditid2 ="4009";
		    String endAuditid2 ="4029";
		    test.testQueryDataByID2(Long.parseLong(beginAuditid2), Long.parseLong(endAuditid2),portType);
		    /*test queryDataByID2 begin*/
		    
		    /*test queryDataByID3 begin*/
		    String beginAuditid3 ="4009";
		    String endAuditid3 ="731184";
		    List<String> tableNames_ID3 = new ArrayList<String>();
		    tableNames_ID3.add("RS_JZGJBXX");
		    test.testQueryDataByID3(tableNames_ID3, Long.parseLong(beginAuditid3),Long.parseLong(endAuditid3),portType);
		    /*test queryDataByID3 begin*/

		}catch(Exception e){
			e.printStackTrace();
		}
	}
	/*
	public static void main(String[] args){
		TestQueryService test = new TestQueryService();
		
		/*test getMaxAuditID begin*/
		//test.testGetMaxAuditID();
		/*test getMaxAuditID end*/
		
		/*test getMaxTableAuditID begin*/	/*
		List<String> tableNames = new ArrayList<String>();
		tableNames.add("RY_JBXX");   
		tableNames.add("YYXT_DY");   
	    test.testGetMaxTableAuditID(tableNames);
	    /*test getMaxTableAuditID end*/
	    
	    /*test queryDataByDate begin*//*
	    String auditdate ="2010-09-19 18:22:43";
	    test.testQueryDataByDate(auditdate);  
	    /*test queryDataByDate begin*/
	    
	    /*test queryDataByDate2 begin*//*
	    String beginAuditdate2 ="2010-09-19 18:18:19";
	    String endAuditdate2 ="2010-09-21 14:33:21";
	    test.testQueryDataByDate2(beginAuditdate2, endAuditdate2);
	    /*test queryDataByDate2 begin*/
	    
	    /*test queryDataByDate3 begin*//*
	    String beginAuditdate3 ="2010-09-19 18:18:19";
	    String endAuditdate3 ="2010-09-21 14:33:21";
	    List<String> tableNames3 = new ArrayList<String>();
	    tableNames3.add("RY_JBXX");
	    test.testQueryDataByDate3(tableNames3, beginAuditdate3, endAuditdate3);
	    /*test queryDataByDate3 begin*/
	    
	    /*test queryDataByID begin*//*
	    String auditid ="36";
	    test.testQueryDataByID(Long.parseLong(auditid));
	    /*test queryDataByID begin*/
	    
	    /*test queryDataByID2 begin*//*
	    String beginAuditid2 ="1";
	    String endAuditid2 ="36";
	    test.testQueryDataByID2(Long.parseLong(beginAuditid2), Long.parseLong(endAuditid2));
	    /*test queryDataByID2 begin*/
	    
	    /*test queryDataByID3 begin*//*
	    String beginAuditid3 ="1";
	    String endAuditid3 ="36";
	    List<String> tableNames_ID3 = new ArrayList<String>();
	    tableNames_ID3.add("RY_JBXX");
	    test.testQueryDataByID3(tableNames_ID3, Long.parseLong(beginAuditid3),Long.parseLong(endAuditid3));
	    /*test queryDataByID3 begin*//*
	}*/
	
	public void testGetMaxAuditID(QueryDataPortType portType){
		Security securityHeader = new Security();
		UsernameToken ut = new UsernameToken();
		ut.setUsername("mh.ywgl");
		ut.setPassword("11111");
		securityHeader.setUsernameToken(ut);		
		ParametersPadding paddingPart = new ParametersPadding();
		GetMaxAuditIDResponse response = portType.getMaxAuditID(paddingPart, securityHeader);
		
		System.out.println("������Ϣ��"+response.getReturn());
	}
	
	public void testGetMaxTableAuditID(List<String> tableNames,QueryDataPortType portType){
		Security securityHeader = new Security();
		UsernameToken ut = new UsernameToken();
		ut.setUsername("pt.zhyw.oa");
		ut.setPassword("11111");
		securityHeader.setUsernameToken(ut);
		
		GetMaxTableAuditID parameters = new GetMaxTableAuditID();
		for(int i=0;i<tableNames.size();i++){
			parameters.getTableNames().add(tableNames.get(i));
		}
		GetMaxTableAuditIDResponse response  = portType.getMaxTableAuditID(parameters, securityHeader);
		
		List<Long> rm = response.getReturn();
		for(int i=0;i<rm.size();i++){
			System.out.println("������Ϣ��"+rm.get(i));
		}
		rm.clear();
	}
	
    public void testQueryDataByID(Long auditid,QueryDataPortType portType){
    	Security securityHeader = new Security();
    	UsernameToken ut = new UsernameToken();
		ut.setUsername("pt.zhyw.oa");
		ut.setPassword("11111");
		securityHeader.setUsernameToken(ut);
		
		QueryDataByID parameters = new QueryDataByID();
		parameters.setAuditid(auditid);
		
		QueryDataByIDResponse response= portType.queryDataByID(parameters, securityHeader);
    	
    	QueryDataReturn rm = response.getReturn().getValue();
    	System.out.println("������Ϣ��"+rm.getMessage().getValue());    
    	System.out.println("����Code��Ϣ��"+rm.getCode().getValue());
    	System.out.println("������ϸ��Ϣ��"+rm.getAddUpdateRecords().getValue());
    	System.out.println("ɾ����ϸ��Ϣ��"+rm.getDeleteRecords().getValue());
	}
      
    public void testQueryDataByID2(Long beginAuditid,Long endAuditid,QueryDataPortType portType){
    	Security securityHeader = new Security();
    	UsernameToken ut = new UsernameToken();
		ut.setUsername("jwxt");
		ut.setPassword("11111");
		securityHeader.setUsernameToken(ut);
		
		QueryDataByID2 parameters = new QueryDataByID2();
		parameters.setBeginAuditid(beginAuditid);
		parameters.setEndAuditid(endAuditid);
		
		QueryDataByID2Response response = portType.queryDataByID2(parameters, securityHeader);
    	
    	QueryDataReturn rm = response.getReturn().getValue();
    	System.out.println("11"+rm.getMessage().getValue());
    	System.out.println("22"+rm.getReturnMaxId().getValue());
    	System.out.println("00"+rm.getReturnAll().getValue());
    	System.out.println("33"+rm.getAddUpdateRecords().getValue());
    	System.out.println("44"+rm.getDeleteRecords().getValue());
	}
    
    public void testQueryDataByID3(List<String> tableNames,Long beginAuditid,Long endAuditid,QueryDataPortType portType){
    	Security securityHeader = new Security();
    	UsernameToken ut = new UsernameToken();
		ut.setUsername("jwxt");
		ut.setPassword("11111");
		securityHeader.setUsernameToken(ut);
		
		QueryDataByID3 parameters = new QueryDataByID3();
		for(int i=0;i<tableNames.size();i++){
			parameters.getTableNames().add(tableNames.get(i));
		}
		parameters.setBeginAuditid(beginAuditid);
		parameters.setEndAuditid(endAuditid);		
		
		QueryDataByID3Response response =portType.queryDataByID3(parameters, securityHeader);
    	
    	QueryDataReturn rm = response.getReturn().getValue();
    	System.out.println("������Ϣ��"+rm.getMessage().getValue());
    	System.out.println("������Ϣ��"+rm.getReturnAll().getValue());
    	System.out.println("������ϸ��Ϣ��"+rm.getAddUpdateRecords().getValue());
    	System.out.println("ɾ����ϸ��Ϣ��"+rm.getDeleteRecords().getValue());
	}
    
    public void testQueryDataByDate(String auditdate,QueryDataPortType portType){
    	Security securityHeader = new Security();
    	UsernameToken ut = new UsernameToken();
		ut.setUsername("pt.zhyw.oa");
		ut.setPassword("11111");
		securityHeader.setUsernameToken(ut);
		
		QueryDataByDate parameters = new QueryDataByDate();
		parameters.setAuditdate(changeStringOfJAXB(auditdate,"http://release.service.das.jeaw.com/xsd","auditdate"));
		
		QueryDataByDateResponse response = portType.queryDataByDate(parameters, securityHeader);
    	
    	QueryDataReturn rm = response.getReturn().getValue();
    	System.out.println("getMessage()"+rm.getMessage().getValue());
    	System.out.println("getReturnAll()"+rm.getReturnAll().getValue());
	}
    
	public void testQueryDataByDate2(String beginAuditdate,String endAuditdate,QueryDataPortType portType){
		Security securityHeader = new Security();
		UsernameToken ut = new UsernameToken();
		ut.setUsername("pt.zhyw.oa");
		ut.setPassword("11111");
		securityHeader.setUsernameToken(ut);
		
		QueryDataByDate2 parameters = new QueryDataByDate2();
		parameters.setBeginAuditdate(changeStringOfJAXB(beginAuditdate,"http://release.service.das.jeaw.com/xsd","begin_auditdate"));
		parameters.setEndAuditdate(changeStringOfJAXB(endAuditdate,"http://release.service.das.jeaw.com/xsd","end_auditdate"));
		
		QueryDataByDate2Response response = portType.queryDataByDate2(parameters, securityHeader);
		
		QueryDataReturn rm = response.getReturn().getValue();
		System.out.println("������Ϣ��"+rm.getMessage().getValue());
    	System.out.println("������Ϣ��"+rm.getReturnAll().getValue());
    	System.out.println("������ϸ��Ϣ��"+rm.getAddUpdateRecords().getValue());
    	System.out.println("ɾ����ϸ��Ϣ��"+rm.getDeleteRecords().getValue());
	}
	
	public void testQueryDataByDate3(List<String> tableNames,String beginAuditdate,String endAuditdate,QueryDataPortType portType){
		Security securityHeader = new Security();
		UsernameToken ut = new UsernameToken();
		ut.setUsername("pt.zhyw.oa");
		ut.setPassword("11111");
		securityHeader.setUsernameToken(ut);
		
		QueryDataByDate3 parameters = new QueryDataByDate3();
		for(int i=0;i<tableNames.size();i++){
			parameters.getTableNames().add(tableNames.get(i));
		}	
		parameters.setBeginAuditdate(changeStringOfJAXB(beginAuditdate,"http://release.service.das.jeaw.com/xsd","begin_auditdate"));
		parameters.setEndAuditdate(changeStringOfJAXB(endAuditdate,"http://release.service.das.jeaw.com/xsd","end_auditdate"));
		
		QueryDataByDate3Response response = portType.queryDataByDate3(parameters, securityHeader);
		
		QueryDataReturn rm = response.getReturn().getValue();
		System.out.println("������Ϣ��"+rm.getMessage().getValue());
    	System.out.println("������Ϣ��"+rm.getReturnAll().getValue());
    	System.out.println("������ϸ��Ϣ��"+rm.getAddUpdateRecords().getValue());
    	System.out.println("ɾ����ϸ��Ϣ��"+rm.getDeleteRecords().getValue());
	}
	public static JAXBElement<Long> changeLongOfJAXB(String value,String url,String valueName){
		JAXBElement<Long> result = new JAXBElement<Long>(new QName(url,valueName),Long.class,Long.valueOf(value));
		return result;
	}
	public static JAXBElement<String> changeStringOfJAXB(String value,String url,String valueName){
		JAXBElement<String> result = new JAXBElement<String>(new QName(url,valueName),String.class,value);
		return result;
	}
}
