package Query;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base=&quot;{http://www.w3.org/2001/XMLSchema}anyType&quot;&gt;
 *       &lt;sequence&gt;
 *         &lt;element name=&quot;table_names&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; maxOccurs=&quot;unbounded&quot; minOccurs=&quot;0&quot;/&gt;
 *         &lt;element name=&quot;begin_auditdate&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *         &lt;element name=&quot;end_auditdate&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "tableNames", "beginAuditdate",
		"endAuditdate" })
@XmlRootElement(name = "queryDataByDate3")
public class QueryDataByDate3 {

	@XmlElement(name = "table_names", nillable = true)
	protected List<String> tableNames;
	@XmlElementRef(name = "begin_auditdate", namespace = "http://release.service.das.jeaw.com", type = JAXBElement.class)
	protected JAXBElement<String> beginAuditdate;
	@XmlElementRef(name = "end_auditdate", namespace = "http://release.service.das.jeaw.com", type = JAXBElement.class)
	protected JAXBElement<String> endAuditdate;

	/**
	 * Gets the value of the tableNames property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a
	 * snapshot. Therefore any modification you make to the returned list will
	 * be present inside the JAXB object. This is why there is not a
	 * <CODE>set</CODE> method for the tableNames property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getTableNames().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list {@link String }
	 * 
	 * 
	 */
	public List<String> getTableNames() {
		if (tableNames == null) {
			tableNames = new ArrayList<String>();
		}
		return this.tableNames;
	}

	/**
	 * Gets the value of the beginAuditdate property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public JAXBElement<String> getBeginAuditdate() {
		return beginAuditdate;
	}

	/**
	 * Sets the value of the beginAuditdate property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public void setBeginAuditdate(JAXBElement<String> value) {
		this.beginAuditdate = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the endAuditdate property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public JAXBElement<String> getEndAuditdate() {
		return endAuditdate;
	}

	/**
	 * Sets the value of the endAuditdate property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public void setEndAuditdate(JAXBElement<String> value) {
		this.endAuditdate = ((JAXBElement<String>) value);
	}

}
