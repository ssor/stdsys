package Query;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each Java content interface and Java
 * element interface generated in the Query package.
 * <p>
 * An ObjectFactory allows you to programatically construct new instances of the
 * Java representation for XML content. The Java representation of XML content
 * can consist of schema derived interfaces and classes representing the binding
 * of schema type definitions, element declarations and model groups. Factory
 * methods for each of these are provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

	private final static QName _QueryDataByDateResponseReturn_QNAME = new QName(
			"http://release.service.das.jeaw.com", "return");
	private final static QName _QueryDataByEntityIdEntityid_QNAME = new QName(
			"http://release.service.das.jeaw.com", "entityid");
	private final static QName _QueryDataByEntityIdTableName_QNAME = new QName(
			"http://release.service.das.jeaw.com", "table_name");
	private final static QName _QueryDataByDateAuditdate_QNAME = new QName(
			"http://release.service.das.jeaw.com", "auditdate");
	private final static QName _QueryDataByDate2BeginAuditdate_QNAME = new QName(
			"http://release.service.das.jeaw.com", "begin_auditdate");
	private final static QName _QueryDataByDate2EndAuditdate_QNAME = new QName(
			"http://release.service.das.jeaw.com", "end_auditdate");
	private final static QName _QueryDataReturnReturnAll_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "returnAll");
	private final static QName _QueryDataReturnMessage_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "message");
	private final static QName _QueryDataReturnReturnMaxTime_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "returnMaxTime");
	private final static QName _QueryDataReturnReturnMaxId_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "returnMaxId");
	private final static QName _QueryDataReturnDeleteRecords_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "deleteRecords");
	private final static QName _QueryDataReturnAddUpdateRecords_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "addUpdateRecords");
	private final static QName _QueryDataReturnCode_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "code");

	/**
	 * Create a new ObjectFactory that can be used to create new instances of
	 * schema derived classes for package: Query
	 * 
	 */
	public ObjectFactory() {
	}

	/**
	 * Create an instance of {@link QueryDataByID2 }
	 * 
	 */
	public QueryDataByID2 createQueryDataByID2() {
		return new QueryDataByID2();
	}

	/**
	 * Create an instance of {@link QueryDataByDate2Response }
	 * 
	 */
	public QueryDataByDate2Response createQueryDataByDate2Response() {
		return new QueryDataByDate2Response();
	}

	/**
	 * Create an instance of {@link QueryDataByDateResponse }
	 * 
	 */
	public QueryDataByDateResponse createQueryDataByDateResponse() {
		return new QueryDataByDateResponse();
	}

	/**
	 * Create an instance of {@link Security.UsernameToken }
	 * 
	 */
	public Security.UsernameToken createSecurityUsernameToken() {
		return new Security.UsernameToken();
	}

	/**
	 * Create an instance of {@link QueryDataByEntityIdResponse }
	 * 
	 */
	public QueryDataByEntityIdResponse createQueryDataByEntityIdResponse() {
		return new QueryDataByEntityIdResponse();
	}

	/**
	 * Create an instance of {@link QueryDataByDate3Response }
	 * 
	 */
	public QueryDataByDate3Response createQueryDataByDate3Response() {
		return new QueryDataByDate3Response();
	}

	/**
	 * Create an instance of {@link QueryDataByDate }
	 * 
	 */
	public QueryDataByDate createQueryDataByDate() {
		return new QueryDataByDate();
	}

	/**
	 * Create an instance of {@link GetMaxAuditIDResponse }
	 * 
	 */
	public GetMaxAuditIDResponse createGetMaxAuditIDResponse() {
		return new GetMaxAuditIDResponse();
	}

	/**
	 * Create an instance of {@link QueryDataByEntityId }
	 * 
	 */
	public QueryDataByEntityId createQueryDataByEntityId() {
		return new QueryDataByEntityId();
	}

	/**
	 * Create an instance of {@link GetMaxTableAuditIDResponse }
	 * 
	 */
	public GetMaxTableAuditIDResponse createGetMaxTableAuditIDResponse() {
		return new GetMaxTableAuditIDResponse();
	}

	/**
	 * Create an instance of {@link Security }
	 * 
	 */
	public Security createSecurity() {
		return new Security();
	}

	/**
	 * Create an instance of {@link QueryDataByDate2 }
	 * 
	 */
	public QueryDataByDate2 createQueryDataByDate2() {
		return new QueryDataByDate2();
	}

	/**
	 * Create an instance of {@link ParametersPadding }
	 * 
	 */
	public ParametersPadding createParametersPadding() {
		return new ParametersPadding();
	}

	/**
	 * Create an instance of {@link QueryDataByID }
	 * 
	 */
	public QueryDataByID createQueryDataByID() {
		return new QueryDataByID();
	}

	/**
	 * Create an instance of {@link QueryDataByID3Response }
	 * 
	 */
	public QueryDataByID3Response createQueryDataByID3Response() {
		return new QueryDataByID3Response();
	}

	/**
	 * Create an instance of {@link QueryDataReturn }
	 * 
	 */
	public QueryDataReturn createQueryDataReturn() {
		return new QueryDataReturn();
	}

	/**
	 * Create an instance of {@link QueryDataByIDResponse }
	 * 
	 */
	public QueryDataByIDResponse createQueryDataByIDResponse() {
		return new QueryDataByIDResponse();
	}

	/**
	 * Create an instance of {@link QueryDataByID3 }
	 * 
	 */
	public QueryDataByID3 createQueryDataByID3() {
		return new QueryDataByID3();
	}

	/**
	 * Create an instance of {@link QueryDataByDate3 }
	 * 
	 */
	public QueryDataByDate3 createQueryDataByDate3() {
		return new QueryDataByDate3();
	}

	/**
	 * Create an instance of {@link GetMaxTableAuditID }
	 * 
	 */
	public GetMaxTableAuditID createGetMaxTableAuditID() {
		return new GetMaxTableAuditID();
	}

	/**
	 * Create an instance of {@link QueryDataByID2Response }
	 * 
	 */
	public QueryDataByID2Response createQueryDataByID2Response() {
		return new QueryDataByID2Response();
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link QueryDataReturn }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = QueryDataByDateResponse.class)
	public JAXBElement<QueryDataReturn> createQueryDataByDateResponseReturn(
			QueryDataReturn value) {
		return new JAXBElement<QueryDataReturn>(
				_QueryDataByDateResponseReturn_QNAME, QueryDataReturn.class,
				QueryDataByDateResponse.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link QueryDataReturn }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = QueryDataByDate2Response.class)
	public JAXBElement<QueryDataReturn> createQueryDataByDate2ResponseReturn(
			QueryDataReturn value) {
		return new JAXBElement<QueryDataReturn>(
				_QueryDataByDateResponseReturn_QNAME, QueryDataReturn.class,
				QueryDataByDate2Response.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link QueryDataReturn }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = QueryDataByDate3Response.class)
	public JAXBElement<QueryDataReturn> createQueryDataByDate3ResponseReturn(
			QueryDataReturn value) {
		return new JAXBElement<QueryDataReturn>(
				_QueryDataByDateResponseReturn_QNAME, QueryDataReturn.class,
				QueryDataByDate3Response.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link QueryDataReturn }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = QueryDataByEntityIdResponse.class)
	public JAXBElement<QueryDataReturn> createQueryDataByEntityIdResponseReturn(
			QueryDataReturn value) {
		return new JAXBElement<QueryDataReturn>(
				_QueryDataByDateResponseReturn_QNAME, QueryDataReturn.class,
				QueryDataByEntityIdResponse.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "entityid", scope = QueryDataByEntityId.class)
	public JAXBElement<String> createQueryDataByEntityIdEntityid(String value) {
		return new JAXBElement<String>(_QueryDataByEntityIdEntityid_QNAME,
				String.class, QueryDataByEntityId.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "table_name", scope = QueryDataByEntityId.class)
	public JAXBElement<String> createQueryDataByEntityIdTableName(String value) {
		return new JAXBElement<String>(_QueryDataByEntityIdTableName_QNAME,
				String.class, QueryDataByEntityId.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "auditdate", scope = QueryDataByDate.class)
	public JAXBElement<String> createQueryDataByDateAuditdate(String value) {
		return new JAXBElement<String>(_QueryDataByDateAuditdate_QNAME,
				String.class, QueryDataByDate.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "begin_auditdate", scope = QueryDataByDate2.class)
	public JAXBElement<String> createQueryDataByDate2BeginAuditdate(String value) {
		return new JAXBElement<String>(_QueryDataByDate2BeginAuditdate_QNAME,
				String.class, QueryDataByDate2.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "end_auditdate", scope = QueryDataByDate2.class)
	public JAXBElement<String> createQueryDataByDate2EndAuditdate(String value) {
		return new JAXBElement<String>(_QueryDataByDate2EndAuditdate_QNAME,
				String.class, QueryDataByDate2.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link QueryDataReturn }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = QueryDataByID3Response.class)
	public JAXBElement<QueryDataReturn> createQueryDataByID3ResponseReturn(
			QueryDataReturn value) {
		return new JAXBElement<QueryDataReturn>(
				_QueryDataByDateResponseReturn_QNAME, QueryDataReturn.class,
				QueryDataByID3Response.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link QueryDataReturn }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = QueryDataByIDResponse.class)
	public JAXBElement<QueryDataReturn> createQueryDataByIDResponseReturn(
			QueryDataReturn value) {
		return new JAXBElement<QueryDataReturn>(
				_QueryDataByDateResponseReturn_QNAME, QueryDataReturn.class,
				QueryDataByIDResponse.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "returnAll", scope = QueryDataReturn.class)
	public JAXBElement<String> createQueryDataReturnReturnAll(String value) {
		return new JAXBElement<String>(_QueryDataReturnReturnAll_QNAME,
				String.class, QueryDataReturn.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "message", scope = QueryDataReturn.class)
	public JAXBElement<String> createQueryDataReturnMessage(String value) {
		return new JAXBElement<String>(_QueryDataReturnMessage_QNAME,
				String.class, QueryDataReturn.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "returnMaxTime", scope = QueryDataReturn.class)
	public JAXBElement<String> createQueryDataReturnReturnMaxTime(String value) {
		return new JAXBElement<String>(_QueryDataReturnReturnMaxTime_QNAME,
				String.class, QueryDataReturn.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "returnMaxId", scope = QueryDataReturn.class)
	public JAXBElement<String> createQueryDataReturnReturnMaxId(String value) {
		return new JAXBElement<String>(_QueryDataReturnReturnMaxId_QNAME,
				String.class, QueryDataReturn.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "deleteRecords", scope = QueryDataReturn.class)
	public JAXBElement<String> createQueryDataReturnDeleteRecords(String value) {
		return new JAXBElement<String>(_QueryDataReturnDeleteRecords_QNAME,
				String.class, QueryDataReturn.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "addUpdateRecords", scope = QueryDataReturn.class)
	public JAXBElement<String> createQueryDataReturnAddUpdateRecords(
			String value) {
		return new JAXBElement<String>(_QueryDataReturnAddUpdateRecords_QNAME,
				String.class, QueryDataReturn.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "code", scope = QueryDataReturn.class)
	public JAXBElement<String> createQueryDataReturnCode(String value) {
		return new JAXBElement<String>(_QueryDataReturnCode_QNAME,
				String.class, QueryDataReturn.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "begin_auditdate", scope = QueryDataByDate3.class)
	public JAXBElement<String> createQueryDataByDate3BeginAuditdate(String value) {
		return new JAXBElement<String>(_QueryDataByDate2BeginAuditdate_QNAME,
				String.class, QueryDataByDate3.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "end_auditdate", scope = QueryDataByDate3.class)
	public JAXBElement<String> createQueryDataByDate3EndAuditdate(String value) {
		return new JAXBElement<String>(_QueryDataByDate2EndAuditdate_QNAME,
				String.class, QueryDataByDate3.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link QueryDataReturn }{@code >}}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = QueryDataByID2Response.class)
	public JAXBElement<QueryDataReturn> createQueryDataByID2ResponseReturn(
			QueryDataReturn value) {
		return new JAXBElement<QueryDataReturn>(
				_QueryDataByDateResponseReturn_QNAME, QueryDataReturn.class,
				QueryDataByID2Response.class, value);
	}

}
