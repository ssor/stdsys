package Query;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for QueryDataReturn complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name=&quot;QueryDataReturn&quot;&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base=&quot;{http://www.w3.org/2001/XMLSchema}anyType&quot;&gt;
 *       &lt;sequence&gt;
 *         &lt;element name=&quot;addUpdateRecords&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *         &lt;element name=&quot;code&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *         &lt;element name=&quot;deleteRecords&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *         &lt;element name=&quot;message&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *         &lt;element name=&quot;returnAll&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *         &lt;element name=&quot;returnMaxId&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *         &lt;element name=&quot;returnMaxTime&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "QueryDataReturn", namespace = "http://release.service.das.jeaw.com/xsd", propOrder = {
		"addUpdateRecords", "code", "deleteRecords", "message", "returnAll",
		"returnMaxId", "returnMaxTime" })
public class QueryDataReturn {

	@XmlElementRef(name = "addUpdateRecords", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> addUpdateRecords;
	@XmlElementRef(name = "code", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> code;
	@XmlElementRef(name = "deleteRecords", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> deleteRecords;
	@XmlElementRef(name = "message", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> message;
	@XmlElementRef(name = "returnAll", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> returnAll;
	@XmlElementRef(name = "returnMaxId", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> returnMaxId;
	@XmlElementRef(name = "returnMaxTime", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> returnMaxTime;

	/**
	 * Gets the value of the addUpdateRecords property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public JAXBElement<String> getAddUpdateRecords() {
		return addUpdateRecords;
	}

	/**
	 * Sets the value of the addUpdateRecords property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public void setAddUpdateRecords(JAXBElement<String> value) {
		this.addUpdateRecords = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the code property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public JAXBElement<String> getCode() {
		return code;
	}

	/**
	 * Sets the value of the code property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public void setCode(JAXBElement<String> value) {
		this.code = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the deleteRecords property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public JAXBElement<String> getDeleteRecords() {
		return deleteRecords;
	}

	/**
	 * Sets the value of the deleteRecords property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public void setDeleteRecords(JAXBElement<String> value) {
		this.deleteRecords = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the message property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public JAXBElement<String> getMessage() {
		return message;
	}

	/**
	 * Sets the value of the message property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public void setMessage(JAXBElement<String> value) {
		this.message = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the returnAll property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public JAXBElement<String> getReturnAll() {
		return returnAll;
	}

	/**
	 * Sets the value of the returnAll property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public void setReturnAll(JAXBElement<String> value) {
		this.returnAll = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the returnMaxId property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public JAXBElement<String> getReturnMaxId() {
		return returnMaxId;
	}

	/**
	 * Sets the value of the returnMaxId property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public void setReturnMaxId(JAXBElement<String> value) {
		this.returnMaxId = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the returnMaxTime property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public JAXBElement<String> getReturnMaxTime() {
		return returnMaxTime;
	}

	/**
	 * Sets the value of the returnMaxTime property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	public void setReturnMaxTime(JAXBElement<String> value) {
		this.returnMaxTime = ((JAXBElement<String>) value);
	}

}
