package Query;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base=&quot;{http://www.w3.org/2001/XMLSchema}anyType&quot;&gt;
 *       &lt;sequence&gt;
 *         &lt;element name=&quot;begin_auditid&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}long&quot; minOccurs=&quot;0&quot;/&gt;
 *         &lt;element name=&quot;end_auditid&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}long&quot; minOccurs=&quot;0&quot;/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "beginAuditid", "endAuditid" })
@XmlRootElement(name = "queryDataByID2")
public class QueryDataByID2 {

	@XmlElement(name = "begin_auditid")
	protected Long beginAuditid;
	@XmlElement(name = "end_auditid")
	protected Long endAuditid;

	/**
	 * Gets the value of the beginAuditid property.
	 * 
	 * @return possible object is {@link Long }
	 * 
	 */
	public Long getBeginAuditid() {
		return beginAuditid;
	}

	/**
	 * Sets the value of the beginAuditid property.
	 * 
	 * @param value
	 *            allowed object is {@link Long }
	 * 
	 */
	public void setBeginAuditid(Long value) {
		this.beginAuditid = value;
	}

	/**
	 * Gets the value of the endAuditid property.
	 * 
	 * @return possible object is {@link Long }
	 * 
	 */
	public Long getEndAuditid() {
		return endAuditid;
	}

	/**
	 * Sets the value of the endAuditid property.
	 * 
	 * @param value
	 *            allowed object is {@link Long }
	 * 
	 */
	public void setEndAuditid(Long value) {
		this.endAuditid = value;
	}

}
