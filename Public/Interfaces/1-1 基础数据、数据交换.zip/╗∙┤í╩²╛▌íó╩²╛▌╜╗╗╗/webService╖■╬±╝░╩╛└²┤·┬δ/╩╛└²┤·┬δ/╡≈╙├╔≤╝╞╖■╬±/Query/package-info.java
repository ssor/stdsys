/**
 * QueryData
 * 
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "http://release.service.das.jeaw.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package Query;

