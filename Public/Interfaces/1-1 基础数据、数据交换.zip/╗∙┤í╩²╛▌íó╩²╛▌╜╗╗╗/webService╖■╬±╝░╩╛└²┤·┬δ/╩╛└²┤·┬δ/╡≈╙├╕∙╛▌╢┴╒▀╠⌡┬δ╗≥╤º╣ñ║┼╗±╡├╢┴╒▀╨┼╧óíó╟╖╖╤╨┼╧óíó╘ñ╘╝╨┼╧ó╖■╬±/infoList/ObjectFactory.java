package infoList;

import javax.xml.bind.annotation.XmlRegistry;

/**
 * This object contains factory methods for each Java content interface and Java
 * element interface generated in the infoList package.
 * <p>
 * An ObjectFactory allows you to programatically construct new instances of the
 * Java representation for XML content. The Java representation of XML content
 * can consist of schema derived interfaces and classes representing the binding
 * of schema type definitions, element declarations and model groups. Factory
 * methods for each of these are provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

	/**
	 * Create a new ObjectFactory that can be used to create new instances of
	 * schema derived classes for package: infoList
	 * 
	 */
	public ObjectFactory() {
	}

	/**
	 * Create an instance of {@link GetReaderDebtResponse }
	 * 
	 */
	public GetReaderDebtResponse createGetReaderDebtResponse() {
		return new GetReaderDebtResponse();
	}

	/**
	 * Create an instance of {@link GetReaderDebt }
	 * 
	 */
	public GetReaderDebt createGetReaderDebt() {
		return new GetReaderDebt();
	}

	/**
	 * Create an instance of {@link GetReaderInfoResponse }
	 * 
	 */
	public GetReaderInfoResponse createGetReaderInfoResponse() {
		return new GetReaderInfoResponse();
	}

	/**
	 * Create an instance of {@link GetReaderHoldInfoResponse }
	 * 
	 */
	public GetReaderHoldInfoResponse createGetReaderHoldInfoResponse() {
		return new GetReaderHoldInfoResponse();
	}

	/**
	 * Create an instance of {@link GetReaderInfo }
	 * 
	 */
	public GetReaderInfo createGetReaderInfo() {
		return new GetReaderInfo();
	}

	/**
	 * Create an instance of {@link GetReaderDebtIdentidResponse }
	 * 
	 */
	public GetReaderDebtIdentidResponse createGetReaderDebtIdentidResponse() {
		return new GetReaderDebtIdentidResponse();
	}

	/**
	 * Create an instance of {@link GetReaderCheckOut }
	 * 
	 */
	public GetReaderCheckOut createGetReaderCheckOut() {
		return new GetReaderCheckOut();
	}

	/**
	 * Create an instance of {@link GetReaderDebtIdentid }
	 * 
	 */
	public GetReaderDebtIdentid createGetReaderDebtIdentid() {
		return new GetReaderDebtIdentid();
	}

	/**
	 * Create an instance of {@link GetReaderCheckOutResponse }
	 * 
	 */
	public GetReaderCheckOutResponse createGetReaderCheckOutResponse() {
		return new GetReaderCheckOutResponse();
	}

	/**
	 * Create an instance of {@link GetReaderHoldInfo }
	 * 
	 */
	public GetReaderHoldInfo createGetReaderHoldInfo() {
		return new GetReaderHoldInfo();
	}

}
