@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.bcrj.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package infoList;

