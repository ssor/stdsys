import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import ORG.ArgumentRSJGXX;
import ORG.EntityRSJGXX;
import ORG.ServiceRSJGXX;
import ORG.ServiceRSJGXXPortType;
import ORGCODE.ArgumentJGXXBYORGCODE;
import ORGCODE.EntityJGXXBYORGCODE;
import ORGCODE.Query;
import ORGCODE.QueryResponse;
import ORGCODE.Security;
import ORGCODE.ServiceJGXXBYORGCODE;
import ORGCODE.ServiceJGXXBYORGCODEPortType;
import ORGCODE.Security.UsernameToken;


public class testORG {
	public static void main(String args[]){
		try{
		
			ServiceJGXXBYORGCODE sp = new ServiceJGXXBYORGCODE();
			ServiceJGXXBYORGCODEPortType portType = sp.getServiceJGXXBYORGCODEHttpSoap11Endpoint();
			
			ServiceRSJGXX sp_jg = new ServiceRSJGXX();
			ServiceRSJGXXPortType portType_jg=sp_jg.getServiceRSJGXXHttpSoap11Endpoint();

			testQuery(portType_jg);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static JAXBElement<Long> changeLongOfJAXB(String value,String url,String valueName){
		JAXBElement<Long> result = new JAXBElement<Long>(new QName(url,valueName),Long.class,Long.valueOf(value));
		return result;
	}
	public static JAXBElement<String> changeStringOfJAXB(String value,String url,String valueName){
		JAXBElement<String> result = new JAXBElement<String>(new QName(url,valueName),String.class,value);
		return result;
	}

	public static void testQueryByCode(ServiceJGXXBYORGCODEPortType portType){
		Query parameters = new  Query();	
		JAXBElement<String> ORGCODE = changeStringOfJAXB("100000","http://release.service.das.jeaw.com/xsd","ORGCODE");
		
		ArgumentJGXXBYORGCODE argument = new ArgumentJGXXBYORGCODE();
		argument.setORGCODE(ORGCODE);
		argument.setPage(1);
		argument.setPageSize(50);

		JAXBElement<ArgumentJGXXBYORGCODE> arg0 = new JAXBElement<ArgumentJGXXBYORGCODE>(
				new QName("http://release.service.das.jeaw.com", "args0"),
				ArgumentJGXXBYORGCODE.class, argument);
		
		parameters.setArgs0(arg0);
		
		Security securityHeader = new Security();
		Security.UsernameToken ut = new UsernameToken();
		ut.setUsername("pt.jcsj");
		ut.setPassword("111111");
		securityHeader.setUsernameToken(ut);
		securityHeader.setMustUnderstand(true);

		QueryResponse response = new QueryResponse();

		response = portType.query(parameters, securityHeader);

		List<Object> enlist = response.getReturn().getValue().getResult();
		System.out.println("enlist:"+enlist.size());
		for(Object obj:enlist){
			EntityJGXXBYORGCODE en = (EntityJGXXBYORGCODE)obj;	
				System.out.println("ID: "+en.getID().getValue());
				System.out.println("ORGNAME: "+en.getORGNAME().getValue());
				System.out.println("ORGCODE: "+en.getORGCODE().getValue());
		}
	}
	public static void testQuery(ServiceRSJGXXPortType portType_jg){
		ORG.Query parameters = new  ORG.Query();	
		
		ArgumentRSJGXX argument = new ArgumentRSJGXX();
		argument.setPage(1);
		argument.setPageSize(100);

		JAXBElement<ArgumentRSJGXX> arg0 = new JAXBElement<ArgumentRSJGXX>(
				new QName("http://release.service.das.jeaw.com", "args0"),
				ArgumentRSJGXX.class, argument);
		
		parameters.setArgs0(arg0);
		
		ORG.Security securityHeader = new ORG.Security();
		ORG.Security.UsernameToken ut = new ORG.Security.UsernameToken();
		ut.setUsername("pt.jcsj");
		ut.setPassword("111111");
		securityHeader.setUsernameToken(ut);
		securityHeader.setMustUnderstand(true);

		ORG.QueryResponse response = new ORG.QueryResponse();

		response = portType_jg.query(parameters, securityHeader);

		List<Object> enlist = response.getReturn().getValue().getResult();
		System.out.println("enlist:"+enlist.size());
		for(Object obj:enlist){
			EntityRSJGXX en = (EntityRSJGXX)obj;	
				System.out.println("ID: "+en.getID().getValue());
				System.out.println("ORGNAME: "+en.getORGNAME().getValue());
				System.out.println("ORGCODE: "+en.getORGCODE().getValue());
		}
	}
}
