package ORG;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for EntityRS_JGXX complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="EntityRS_JGXX">
 *   &lt;complexContent>
 *     &lt;extension base="{http://pojo.servgen.das.jeaw.com/xsd}Entity">
 *       &lt;sequence>
 *         &lt;element name="ADDRESS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ADMINDIRECTOR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ATTRIBUTE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BZ" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CREATEDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DELFLAG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DESCN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EMAIL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FATHERID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FAX" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INNERCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INVALIDDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ISCORP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OPERATERID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OPERATERNAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OPERATETIME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ORGCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ORGENNAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ORGENSIMNAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ORGLEVEL" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="ORGNAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ORGNAMESPELL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ORGORDER" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="ORGSIMNAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ORGTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PARENTORGCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PARTYDIRECTOR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="POSTCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SJC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="STATUS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TELEPHONE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TREEPATH" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VIRFLAG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EntityRS_JGXX", namespace = "http://release.service.das.jeaw.com/xsd", propOrder = {
		"address", "admindirector", "attribute", "bz", "createdate", "delflag",
		"descn", "email", "fatherid", "fax", "id", "innercode", "invaliddate",
		"iscorp", "operaterid", "operatername", "operatetime", "orgcode",
		"orgenname", "orgensimname", "orglevel", "orgname", "orgnamespell",
		"orgorder", "orgsimname", "orgtype", "parentorgcode", "partydirector",
		"postcode", "sjc", "status", "telephone", "treepath", "virflag" })
public class EntityRSJGXX extends Entity {

	@XmlElementRef(name = "ADDRESS", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> address;
	@XmlElementRef(name = "ADMINDIRECTOR", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> admindirector;
	@XmlElementRef(name = "ATTRIBUTE", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> attribute;
	@XmlElementRef(name = "BZ", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> bz;
	@XmlElementRef(name = "CREATEDATE", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> createdate;
	@XmlElementRef(name = "DELFLAG", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> delflag;
	@XmlElementRef(name = "DESCN", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> descn;
	@XmlElementRef(name = "EMAIL", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> email;
	@XmlElementRef(name = "FATHERID", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> fatherid;
	@XmlElementRef(name = "FAX", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> fax;
	@XmlElementRef(name = "ID", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> id;
	@XmlElementRef(name = "INNERCODE", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> innercode;
	@XmlElementRef(name = "INVALIDDATE", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> invaliddate;
	@XmlElementRef(name = "ISCORP", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> iscorp;
	@XmlElementRef(name = "OPERATERID", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> operaterid;
	@XmlElementRef(name = "OPERATERNAME", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> operatername;
	@XmlElementRef(name = "OPERATETIME", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> operatetime;
	@XmlElementRef(name = "ORGCODE", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> orgcode;
	@XmlElementRef(name = "ORGENNAME", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> orgenname;
	@XmlElementRef(name = "ORGENSIMNAME", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> orgensimname;
	@XmlElementRef(name = "ORGLEVEL", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<Double> orglevel;
	@XmlElementRef(name = "ORGNAME", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> orgname;
	@XmlElementRef(name = "ORGNAMESPELL", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> orgnamespell;
	@XmlElementRef(name = "ORGORDER", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<Double> orgorder;
	@XmlElementRef(name = "ORGSIMNAME", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> orgsimname;
	@XmlElementRef(name = "ORGTYPE", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> orgtype;
	@XmlElementRef(name = "PARENTORGCODE", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> parentorgcode;
	@XmlElementRef(name = "PARTYDIRECTOR", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> partydirector;
	@XmlElementRef(name = "POSTCODE", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> postcode;
	@XmlElementRef(name = "SJC", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sjc;
	@XmlElementRef(name = "STATUS", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> status;
	@XmlElementRef(name = "TELEPHONE", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> telephone;
	@XmlElementRef(name = "TREEPATH", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> treepath;
	@XmlElementRef(name = "VIRFLAG", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> virflag;

	/**
	 * Gets the value of the address property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getADDRESS() {
		return address;
	}

	/**
	 * Sets the value of the address property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setADDRESS(JAXBElement<String> value) {
		this.address = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the admindirector property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getADMINDIRECTOR() {
		return admindirector;
	}

	/**
	 * Sets the value of the admindirector property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setADMINDIRECTOR(JAXBElement<String> value) {
		this.admindirector = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the attribute property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getATTRIBUTE() {
		return attribute;
	}

	/**
	 * Sets the value of the attribute property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setATTRIBUTE(JAXBElement<String> value) {
		this.attribute = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the bz property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getBZ() {
		return bz;
	}

	/**
	 * Sets the value of the bz property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setBZ(JAXBElement<String> value) {
		this.bz = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the createdate property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getCREATEDATE() {
		return createdate;
	}

	/**
	 * Sets the value of the createdate property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setCREATEDATE(JAXBElement<String> value) {
		this.createdate = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the delflag property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getDELFLAG() {
		return delflag;
	}

	/**
	 * Sets the value of the delflag property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setDELFLAG(JAXBElement<String> value) {
		this.delflag = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the descn property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getDESCN() {
		return descn;
	}

	/**
	 * Sets the value of the descn property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setDESCN(JAXBElement<String> value) {
		this.descn = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the email property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getEMAIL() {
		return email;
	}

	/**
	 * Sets the value of the email property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setEMAIL(JAXBElement<String> value) {
		this.email = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the fatherid property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getFATHERID() {
		return fatherid;
	}

	/**
	 * Sets the value of the fatherid property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setFATHERID(JAXBElement<String> value) {
		this.fatherid = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the fax property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getFAX() {
		return fax;
	}

	/**
	 * Sets the value of the fax property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setFAX(JAXBElement<String> value) {
		this.fax = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the id property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getID() {
		return id;
	}

	/**
	 * Sets the value of the id property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setID(JAXBElement<String> value) {
		this.id = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the innercode property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getINNERCODE() {
		return innercode;
	}

	/**
	 * Sets the value of the innercode property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setINNERCODE(JAXBElement<String> value) {
		this.innercode = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the invaliddate property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getINVALIDDATE() {
		return invaliddate;
	}

	/**
	 * Sets the value of the invaliddate property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setINVALIDDATE(JAXBElement<String> value) {
		this.invaliddate = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the iscorp property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getISCORP() {
		return iscorp;
	}

	/**
	 * Sets the value of the iscorp property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setISCORP(JAXBElement<String> value) {
		this.iscorp = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the operaterid property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getOPERATERID() {
		return operaterid;
	}

	/**
	 * Sets the value of the operaterid property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setOPERATERID(JAXBElement<String> value) {
		this.operaterid = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the operatername property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getOPERATERNAME() {
		return operatername;
	}

	/**
	 * Sets the value of the operatername property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setOPERATERNAME(JAXBElement<String> value) {
		this.operatername = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the operatetime property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getOPERATETIME() {
		return operatetime;
	}

	/**
	 * Sets the value of the operatetime property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setOPERATETIME(JAXBElement<String> value) {
		this.operatetime = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the orgcode property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getORGCODE() {
		return orgcode;
	}

	/**
	 * Sets the value of the orgcode property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setORGCODE(JAXBElement<String> value) {
		this.orgcode = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the orgenname property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getORGENNAME() {
		return orgenname;
	}

	/**
	 * Sets the value of the orgenname property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setORGENNAME(JAXBElement<String> value) {
		this.orgenname = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the orgensimname property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getORGENSIMNAME() {
		return orgensimname;
	}

	/**
	 * Sets the value of the orgensimname property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setORGENSIMNAME(JAXBElement<String> value) {
		this.orgensimname = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the orglevel property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link Double }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<Double> getORGLEVEL() {
		return orglevel;
	}

	/**
	 * Sets the value of the orglevel property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link Double }
	 *            {@code >}
	 * 
	 */
	public void setORGLEVEL(JAXBElement<Double> value) {
		this.orglevel = ((JAXBElement<Double>) value);
	}

	/**
	 * Gets the value of the orgname property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getORGNAME() {
		return orgname;
	}

	/**
	 * Sets the value of the orgname property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setORGNAME(JAXBElement<String> value) {
		this.orgname = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the orgnamespell property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getORGNAMESPELL() {
		return orgnamespell;
	}

	/**
	 * Sets the value of the orgnamespell property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setORGNAMESPELL(JAXBElement<String> value) {
		this.orgnamespell = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the orgorder property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link Double }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<Double> getORGORDER() {
		return orgorder;
	}

	/**
	 * Sets the value of the orgorder property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link Double }
	 *            {@code >}
	 * 
	 */
	public void setORGORDER(JAXBElement<Double> value) {
		this.orgorder = ((JAXBElement<Double>) value);
	}

	/**
	 * Gets the value of the orgsimname property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getORGSIMNAME() {
		return orgsimname;
	}

	/**
	 * Sets the value of the orgsimname property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setORGSIMNAME(JAXBElement<String> value) {
		this.orgsimname = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the orgtype property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getORGTYPE() {
		return orgtype;
	}

	/**
	 * Sets the value of the orgtype property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setORGTYPE(JAXBElement<String> value) {
		this.orgtype = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the parentorgcode property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getPARENTORGCODE() {
		return parentorgcode;
	}

	/**
	 * Sets the value of the parentorgcode property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setPARENTORGCODE(JAXBElement<String> value) {
		this.parentorgcode = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the partydirector property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getPARTYDIRECTOR() {
		return partydirector;
	}

	/**
	 * Sets the value of the partydirector property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setPARTYDIRECTOR(JAXBElement<String> value) {
		this.partydirector = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the postcode property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getPOSTCODE() {
		return postcode;
	}

	/**
	 * Sets the value of the postcode property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setPOSTCODE(JAXBElement<String> value) {
		this.postcode = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sjc property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSJC() {
		return sjc;
	}

	/**
	 * Sets the value of the sjc property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSJC(JAXBElement<String> value) {
		this.sjc = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the status property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSTATUS() {
		return status;
	}

	/**
	 * Sets the value of the status property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSTATUS(JAXBElement<String> value) {
		this.status = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the telephone property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getTELEPHONE() {
		return telephone;
	}

	/**
	 * Sets the value of the telephone property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setTELEPHONE(JAXBElement<String> value) {
		this.telephone = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the treepath property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getTREEPATH() {
		return treepath;
	}

	/**
	 * Sets the value of the treepath property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setTREEPATH(JAXBElement<String> value) {
		this.treepath = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the virflag property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getVIRFLAG() {
		return virflag;
	}

	/**
	 * Sets the value of the virflag property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setVIRFLAG(JAXBElement<String> value) {
		this.virflag = ((JAXBElement<String>) value);
	}

}
