package ORG;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="return" type="{http://pojo.servgen.das.jeaw.com/xsd}ReturnEntity" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "_return" })
@XmlRootElement(name = "updateResponse")
public class UpdateResponse {

	@XmlElementRef(name = "return", namespace = "http://release.service.das.jeaw.com", type = JAXBElement.class)
	protected JAXBElement<ReturnEntity> _return;

	/**
	 * Gets the value of the return property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}
	 *         {@link ReturnEntity }{@code >}
	 * 
	 */
	public JAXBElement<ReturnEntity> getReturn() {
		return _return;
	}

	/**
	 * Sets the value of the return property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}
	 *            {@link ReturnEntity }{@code >}
	 * 
	 */
	public void setReturn(JAXBElement<ReturnEntity> value) {
		this._return = ((JAXBElement<ReturnEntity>) value);
	}

}
