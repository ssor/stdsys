package ORG;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for ReturnEntity complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="ReturnEntity">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="code" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currentPageNo" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="message" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="pageSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="result" type="{http://www.w3.org/2001/XMLSchema}anyType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="totalPageCount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="totalRowCount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReturnEntity", namespace = "http://pojo.servgen.das.jeaw.com/xsd", propOrder = {
		"code", "currentPageNo", "message", "pageSize", "result",
		"totalPageCount", "totalRowCount" })
public class ReturnEntity {

	@XmlElementRef(name = "code", namespace = "http://pojo.servgen.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> code;
	protected Integer currentPageNo;
	@XmlElementRef(name = "message", namespace = "http://pojo.servgen.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> message;
	protected Integer pageSize;
	@XmlElement(nillable = true)
	protected List<Object> result;
	protected Integer totalPageCount;
	protected Integer totalRowCount;

	/**
	 * Gets the value of the code property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getCode() {
		return code;
	}

	/**
	 * Sets the value of the code property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setCode(JAXBElement<String> value) {
		this.code = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the currentPageNo property.
	 * 
	 * @return possible object is {@link Integer }
	 * 
	 */
	public Integer getCurrentPageNo() {
		return currentPageNo;
	}

	/**
	 * Sets the value of the currentPageNo property.
	 * 
	 * @param value
	 *            allowed object is {@link Integer }
	 * 
	 */
	public void setCurrentPageNo(Integer value) {
		this.currentPageNo = value;
	}

	/**
	 * Gets the value of the message property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getMessage() {
		return message;
	}

	/**
	 * Sets the value of the message property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setMessage(JAXBElement<String> value) {
		this.message = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the pageSize property.
	 * 
	 * @return possible object is {@link Integer }
	 * 
	 */
	public Integer getPageSize() {
		return pageSize;
	}

	/**
	 * Sets the value of the pageSize property.
	 * 
	 * @param value
	 *            allowed object is {@link Integer }
	 * 
	 */
	public void setPageSize(Integer value) {
		this.pageSize = value;
	}

	/**
	 * Gets the value of the result property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a
	 * snapshot. Therefore any modification you make to the returned list will
	 * be present inside the JAXB object. This is why there is not a
	 * <CODE>set</CODE> method for the result property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getResult().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list {@link Object }
	 * 
	 * 
	 */
	public List<Object> getResult() {
		if (result == null) {
			result = new ArrayList<Object>();
		}
		return this.result;
	}

	/**
	 * Gets the value of the totalPageCount property.
	 * 
	 * @return possible object is {@link Integer }
	 * 
	 */
	public Integer getTotalPageCount() {
		return totalPageCount;
	}

	/**
	 * Sets the value of the totalPageCount property.
	 * 
	 * @param value
	 *            allowed object is {@link Integer }
	 * 
	 */
	public void setTotalPageCount(Integer value) {
		this.totalPageCount = value;
	}

	/**
	 * Gets the value of the totalRowCount property.
	 * 
	 * @return possible object is {@link Integer }
	 * 
	 */
	public Integer getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * Sets the value of the totalRowCount property.
	 * 
	 * @param value
	 *            allowed object is {@link Integer }
	 * 
	 */
	public void setTotalRowCount(Integer value) {
		this.totalRowCount = value;
	}

}
