package ORG;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each Java content interface and Java
 * element interface generated in the ORG package.
 * <p>
 * An ObjectFactory allows you to programatically construct new instances of the
 * Java representation for XML content. The Java representation of XML content
 * can consist of schema derived interfaces and classes representing the binding
 * of schema type definitions, element declarations and model groups. Factory
 * methods for each of these are provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

	private final static QName _BatchDeleteResponseReturn_QNAME = new QName(
			"http://release.service.das.jeaw.com", "return");
	private final static QName _UpdateArgs0_QNAME = new QName(
			"http://release.service.das.jeaw.com", "args0");
	private final static QName _ReturnEntityMessage_QNAME = new QName(
			"http://pojo.servgen.das.jeaw.com/xsd", "message");
	private final static QName _ReturnEntityCode_QNAME = new QName(
			"http://pojo.servgen.das.jeaw.com/xsd", "code");
	private final static QName _EntityRSJGXXTREEPATH_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "TREEPATH");
	private final static QName _EntityRSJGXXDELFLAG_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "DELFLAG");
	private final static QName _EntityRSJGXXORGNAME_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGNAME");
	private final static QName _EntityRSJGXXCREATEDATE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "CREATEDATE");
	private final static QName _EntityRSJGXXINNERCODE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "INNERCODE");
	private final static QName _EntityRSJGXXTELEPHONE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "TELEPHONE");
	private final static QName _EntityRSJGXXORGORDER_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGORDER");
	private final static QName _EntityRSJGXXPARTYDIRECTOR_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "PARTYDIRECTOR");
	private final static QName _EntityRSJGXXADDRESS_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ADDRESS");
	private final static QName _EntityRSJGXXDESCN_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "DESCN");
	private final static QName _EntityRSJGXXISCORP_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ISCORP");
	private final static QName _EntityRSJGXXORGENNAME_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGENNAME");
	private final static QName _EntityRSJGXXORGENSIMNAME_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGENSIMNAME");
	private final static QName _EntityRSJGXXFAX_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "FAX");
	private final static QName _EntityRSJGXXVIRFLAG_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "VIRFLAG");
	private final static QName _EntityRSJGXXID_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ID");
	private final static QName _EntityRSJGXXEMAIL_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "EMAIL");
	private final static QName _EntityRSJGXXSJC_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SJC");
	private final static QName _EntityRSJGXXPARENTORGCODE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "PARENTORGCODE");
	private final static QName _EntityRSJGXXORGNAMESPELL_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGNAMESPELL");
	private final static QName _EntityRSJGXXOPERATERNAME_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "OPERATERNAME");
	private final static QName _EntityRSJGXXORGLEVEL_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGLEVEL");
	private final static QName _EntityRSJGXXOPERATERID_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "OPERATERID");
	private final static QName _EntityRSJGXXORGTYPE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGTYPE");
	private final static QName _EntityRSJGXXBZ_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "BZ");
	private final static QName _EntityRSJGXXORGSIMNAME_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGSIMNAME");
	private final static QName _EntityRSJGXXSTATUS_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "STATUS");
	private final static QName _EntityRSJGXXATTRIBUTE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ATTRIBUTE");
	private final static QName _EntityRSJGXXOPERATETIME_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "OPERATETIME");
	private final static QName _EntityRSJGXXPOSTCODE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "POSTCODE");
	private final static QName _EntityRSJGXXADMINDIRECTOR_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ADMINDIRECTOR");
	private final static QName _EntityRSJGXXORGCODE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGCODE");
	private final static QName _EntityRSJGXXINVALIDDATE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "INVALIDDATE");
	private final static QName _EntityRSJGXXFATHERID_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "FATHERID");

	/**
	 * Create a new ObjectFactory that can be used to create new instances of
	 * schema derived classes for package: ORG
	 * 
	 */
	public ObjectFactory() {
	}

	/**
	 * Create an instance of {@link ParametersPadding }
	 * 
	 */
	public ParametersPadding createParametersPadding() {
		return new ParametersPadding();
	}

	/**
	 * Create an instance of {@link BatchDeleteResponse }
	 * 
	 */
	public BatchDeleteResponse createBatchDeleteResponse() {
		return new BatchDeleteResponse();
	}

	/**
	 * Create an instance of {@link UpdateResponse }
	 * 
	 */
	public UpdateResponse createUpdateResponse() {
		return new UpdateResponse();
	}

	/**
	 * Create an instance of {@link Update }
	 * 
	 */
	public Update createUpdate() {
		return new Update();
	}

	/**
	 * Create an instance of {@link BatchUpdate }
	 * 
	 */
	public BatchUpdate createBatchUpdate() {
		return new BatchUpdate();
	}

	/**
	 * Create an instance of {@link InsertResponse }
	 * 
	 */
	public InsertResponse createInsertResponse() {
		return new InsertResponse();
	}

	/**
	 * Create an instance of {@link GetEntityTypeResponse }
	 * 
	 */
	public GetEntityTypeResponse createGetEntityTypeResponse() {
		return new GetEntityTypeResponse();
	}

	/**
	 * Create an instance of {@link Delete }
	 * 
	 */
	public Delete createDelete() {
		return new Delete();
	}

	/**
	 * Create an instance of {@link BatchInsert }
	 * 
	 */
	public BatchInsert createBatchInsert() {
		return new BatchInsert();
	}

	/**
	 * Create an instance of {@link DeleteResponse }
	 * 
	 */
	public DeleteResponse createDeleteResponse() {
		return new DeleteResponse();
	}

	/**
	 * Create an instance of {@link Security.UsernameToken }
	 * 
	 */
	public Security.UsernameToken createSecurityUsernameToken() {
		return new Security.UsernameToken();
	}

	/**
	 * Create an instance of {@link Query }
	 * 
	 */
	public Query createQuery() {
		return new Query();
	}

	/**
	 * Create an instance of {@link BatchInsertResponse }
	 * 
	 */
	public BatchInsertResponse createBatchInsertResponse() {
		return new BatchInsertResponse();
	}

	/**
	 * Create an instance of {@link Entity }
	 * 
	 */
	public Entity createEntity() {
		return new Entity();
	}

	/**
	 * Create an instance of {@link Security }
	 * 
	 */
	public Security createSecurity() {
		return new Security();
	}

	/**
	 * Create an instance of {@link ArgumentRSJGXX }
	 * 
	 */
	public ArgumentRSJGXX createArgumentRSJGXX() {
		return new ArgumentRSJGXX();
	}

	/**
	 * Create an instance of {@link QueryResponse }
	 * 
	 */
	public QueryResponse createQueryResponse() {
		return new QueryResponse();
	}

	/**
	 * Create an instance of {@link BatchUpdateResponse }
	 * 
	 */
	public BatchUpdateResponse createBatchUpdateResponse() {
		return new BatchUpdateResponse();
	}

	/**
	 * Create an instance of {@link ReturnEntity }
	 * 
	 */
	public ReturnEntity createReturnEntity() {
		return new ReturnEntity();
	}

	/**
	 * Create an instance of {@link Argument }
	 * 
	 */
	public Argument createArgument() {
		return new Argument();
	}

	/**
	 * Create an instance of {@link EntityRSJGXX }
	 * 
	 */
	public EntityRSJGXX createEntityRSJGXX() {
		return new EntityRSJGXX();
	}

	/**
	 * Create an instance of {@link BatchDelete }
	 * 
	 */
	public BatchDelete createBatchDelete() {
		return new BatchDelete();
	}

	/**
	 * Create an instance of {@link Insert }
	 * 
	 */
	public Insert createInsert() {
		return new Insert();
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link ReturnEntity }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = BatchDeleteResponse.class)
	public JAXBElement<ReturnEntity> createBatchDeleteResponseReturn(
			ReturnEntity value) {
		return new JAXBElement<ReturnEntity>(_BatchDeleteResponseReturn_QNAME,
				ReturnEntity.class, BatchDeleteResponse.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link ReturnEntity }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = UpdateResponse.class)
	public JAXBElement<ReturnEntity> createUpdateResponseReturn(
			ReturnEntity value) {
		return new JAXBElement<ReturnEntity>(_BatchDeleteResponseReturn_QNAME,
				ReturnEntity.class, UpdateResponse.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link EntityRSJGXX }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "args0", scope = Update.class)
	public JAXBElement<EntityRSJGXX> createUpdateArgs0(EntityRSJGXX value) {
		return new JAXBElement<EntityRSJGXX>(_UpdateArgs0_QNAME,
				EntityRSJGXX.class, Update.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link ReturnEntity }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = InsertResponse.class)
	public JAXBElement<ReturnEntity> createInsertResponseReturn(
			ReturnEntity value) {
		return new JAXBElement<ReturnEntity>(_BatchDeleteResponseReturn_QNAME,
				ReturnEntity.class, InsertResponse.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link EntityRSJGXX }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = GetEntityTypeResponse.class)
	public JAXBElement<EntityRSJGXX> createGetEntityTypeResponseReturn(
			EntityRSJGXX value) {
		return new JAXBElement<EntityRSJGXX>(_BatchDeleteResponseReturn_QNAME,
				EntityRSJGXX.class, GetEntityTypeResponse.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link EntityRSJGXX }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "args0", scope = Delete.class)
	public JAXBElement<EntityRSJGXX> createDeleteArgs0(EntityRSJGXX value) {
		return new JAXBElement<EntityRSJGXX>(_UpdateArgs0_QNAME,
				EntityRSJGXX.class, Delete.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link ReturnEntity }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = DeleteResponse.class)
	public JAXBElement<ReturnEntity> createDeleteResponseReturn(
			ReturnEntity value) {
		return new JAXBElement<ReturnEntity>(_BatchDeleteResponseReturn_QNAME,
				ReturnEntity.class, DeleteResponse.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link ArgumentRSJGXX }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "args0", scope = Query.class)
	public JAXBElement<ArgumentRSJGXX> createQueryArgs0(ArgumentRSJGXX value) {
		return new JAXBElement<ArgumentRSJGXX>(_UpdateArgs0_QNAME,
				ArgumentRSJGXX.class, Query.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link ReturnEntity }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = BatchInsertResponse.class)
	public JAXBElement<ReturnEntity> createBatchInsertResponseReturn(
			ReturnEntity value) {
		return new JAXBElement<ReturnEntity>(_BatchDeleteResponseReturn_QNAME,
				ReturnEntity.class, BatchInsertResponse.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link ReturnEntity }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = QueryResponse.class)
	public JAXBElement<ReturnEntity> createQueryResponseReturn(
			ReturnEntity value) {
		return new JAXBElement<ReturnEntity>(_BatchDeleteResponseReturn_QNAME,
				ReturnEntity.class, QueryResponse.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link ReturnEntity }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = BatchUpdateResponse.class)
	public JAXBElement<ReturnEntity> createBatchUpdateResponseReturn(
			ReturnEntity value) {
		return new JAXBElement<ReturnEntity>(_BatchDeleteResponseReturn_QNAME,
				ReturnEntity.class, BatchUpdateResponse.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://pojo.servgen.das.jeaw.com/xsd", name = "message", scope = ReturnEntity.class)
	public JAXBElement<String> createReturnEntityMessage(String value) {
		return new JAXBElement<String>(_ReturnEntityMessage_QNAME,
				String.class, ReturnEntity.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://pojo.servgen.das.jeaw.com/xsd", name = "code", scope = ReturnEntity.class)
	public JAXBElement<String> createReturnEntityCode(String value) {
		return new JAXBElement<String>(_ReturnEntityCode_QNAME, String.class,
				ReturnEntity.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "TREEPATH", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXTREEPATH(String value) {
		return new JAXBElement<String>(_EntityRSJGXXTREEPATH_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "DELFLAG", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXDELFLAG(String value) {
		return new JAXBElement<String>(_EntityRSJGXXDELFLAG_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGNAME", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXORGNAME(String value) {
		return new JAXBElement<String>(_EntityRSJGXXORGNAME_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "CREATEDATE", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXCREATEDATE(String value) {
		return new JAXBElement<String>(_EntityRSJGXXCREATEDATE_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "INNERCODE", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXINNERCODE(String value) {
		return new JAXBElement<String>(_EntityRSJGXXINNERCODE_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "TELEPHONE", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXTELEPHONE(String value) {
		return new JAXBElement<String>(_EntityRSJGXXTELEPHONE_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGORDER", scope = EntityRSJGXX.class)
	public JAXBElement<Double> createEntityRSJGXXORGORDER(Double value) {
		return new JAXBElement<Double>(_EntityRSJGXXORGORDER_QNAME,
				Double.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "PARTYDIRECTOR", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXPARTYDIRECTOR(String value) {
		return new JAXBElement<String>(_EntityRSJGXXPARTYDIRECTOR_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ADDRESS", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXADDRESS(String value) {
		return new JAXBElement<String>(_EntityRSJGXXADDRESS_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "DESCN", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXDESCN(String value) {
		return new JAXBElement<String>(_EntityRSJGXXDESCN_QNAME, String.class,
				EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ISCORP", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXISCORP(String value) {
		return new JAXBElement<String>(_EntityRSJGXXISCORP_QNAME, String.class,
				EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGENNAME", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXORGENNAME(String value) {
		return new JAXBElement<String>(_EntityRSJGXXORGENNAME_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGENSIMNAME", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXORGENSIMNAME(String value) {
		return new JAXBElement<String>(_EntityRSJGXXORGENSIMNAME_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "FAX", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXFAX(String value) {
		return new JAXBElement<String>(_EntityRSJGXXFAX_QNAME, String.class,
				EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "VIRFLAG", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXVIRFLAG(String value) {
		return new JAXBElement<String>(_EntityRSJGXXVIRFLAG_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ID", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXID(String value) {
		return new JAXBElement<String>(_EntityRSJGXXID_QNAME, String.class,
				EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "EMAIL", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXEMAIL(String value) {
		return new JAXBElement<String>(_EntityRSJGXXEMAIL_QNAME, String.class,
				EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SJC", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXSJC(String value) {
		return new JAXBElement<String>(_EntityRSJGXXSJC_QNAME, String.class,
				EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "PARENTORGCODE", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXPARENTORGCODE(String value) {
		return new JAXBElement<String>(_EntityRSJGXXPARENTORGCODE_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGNAMESPELL", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXORGNAMESPELL(String value) {
		return new JAXBElement<String>(_EntityRSJGXXORGNAMESPELL_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "OPERATERNAME", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXOPERATERNAME(String value) {
		return new JAXBElement<String>(_EntityRSJGXXOPERATERNAME_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGLEVEL", scope = EntityRSJGXX.class)
	public JAXBElement<Double> createEntityRSJGXXORGLEVEL(Double value) {
		return new JAXBElement<Double>(_EntityRSJGXXORGLEVEL_QNAME,
				Double.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "OPERATERID", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXOPERATERID(String value) {
		return new JAXBElement<String>(_EntityRSJGXXOPERATERID_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGTYPE", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXORGTYPE(String value) {
		return new JAXBElement<String>(_EntityRSJGXXORGTYPE_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "BZ", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXBZ(String value) {
		return new JAXBElement<String>(_EntityRSJGXXBZ_QNAME, String.class,
				EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGSIMNAME", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXORGSIMNAME(String value) {
		return new JAXBElement<String>(_EntityRSJGXXORGSIMNAME_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "STATUS", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXSTATUS(String value) {
		return new JAXBElement<String>(_EntityRSJGXXSTATUS_QNAME, String.class,
				EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ATTRIBUTE", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXATTRIBUTE(String value) {
		return new JAXBElement<String>(_EntityRSJGXXATTRIBUTE_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "OPERATETIME", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXOPERATETIME(String value) {
		return new JAXBElement<String>(_EntityRSJGXXOPERATETIME_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "POSTCODE", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXPOSTCODE(String value) {
		return new JAXBElement<String>(_EntityRSJGXXPOSTCODE_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ADMINDIRECTOR", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXADMINDIRECTOR(String value) {
		return new JAXBElement<String>(_EntityRSJGXXADMINDIRECTOR_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGCODE", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXORGCODE(String value) {
		return new JAXBElement<String>(_EntityRSJGXXORGCODE_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "INVALIDDATE", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXINVALIDDATE(String value) {
		return new JAXBElement<String>(_EntityRSJGXXINVALIDDATE_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "FATHERID", scope = EntityRSJGXX.class)
	public JAXBElement<String> createEntityRSJGXXFATHERID(String value) {
		return new JAXBElement<String>(_EntityRSJGXXFATHERID_QNAME,
				String.class, EntityRSJGXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link EntityRSJGXX }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "args0", scope = Insert.class)
	public JAXBElement<EntityRSJGXX> createInsertArgs0(EntityRSJGXX value) {
		return new JAXBElement<EntityRSJGXX>(_UpdateArgs0_QNAME,
				EntityRSJGXX.class, Insert.class, value);
	}

}
