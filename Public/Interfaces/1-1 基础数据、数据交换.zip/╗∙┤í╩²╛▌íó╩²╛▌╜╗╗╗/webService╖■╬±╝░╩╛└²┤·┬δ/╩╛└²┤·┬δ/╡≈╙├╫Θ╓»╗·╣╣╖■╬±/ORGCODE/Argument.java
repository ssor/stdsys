package ORGCODE;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for Argument complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="Argument">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="page" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="pageSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Argument", propOrder = { "page", "pageSize" })
public class Argument {

	protected Integer page;
	protected Integer pageSize;

	/**
	 * Gets the value of the page property.
	 * 
	 * @return possible object is {@link Integer }
	 * 
	 */
	public Integer getPage() {
		return page;
	}

	/**
	 * Sets the value of the page property.
	 * 
	 * @param value
	 *            allowed object is {@link Integer }
	 * 
	 */
	public void setPage(Integer value) {
		this.page = value;
	}

	/**
	 * Gets the value of the pageSize property.
	 * 
	 * @return possible object is {@link Integer }
	 * 
	 */
	public Integer getPageSize() {
		return pageSize;
	}

	/**
	 * Sets the value of the pageSize property.
	 * 
	 * @param value
	 *            allowed object is {@link Integer }
	 * 
	 */
	public void setPageSize(Integer value) {
		this.pageSize = value;
	}

}
