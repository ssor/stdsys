package ORGCODE;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each Java content interface and Java
 * element interface generated in the ORGCODE package.
 * <p>
 * An ObjectFactory allows you to programatically construct new instances of the
 * Java representation for XML content. The Java representation of XML content
 * can consist of schema derived interfaces and classes representing the binding
 * of schema type definitions, element declarations and model groups. Factory
 * methods for each of these are provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

	private final static QName _ArgumentJGXXBYORGCODEORGCODE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGCODE");
	private final static QName _QueryResponseReturn_QNAME = new QName(
			"http://release.service.das.jeaw.com", "return");
	private final static QName _ReturnEntityMessage_QNAME = new QName(
			"http://pojo.servgen.das.jeaw.com/xsd", "message");
	private final static QName _ReturnEntityCode_QNAME = new QName(
			"http://pojo.servgen.das.jeaw.com/xsd", "code");
	private final static QName _EntityJGXXBYORGCODETREEPATH_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "TREEPATH");
	private final static QName _EntityJGXXBYORGCODEDELFLAG_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "DELFLAG");
	private final static QName _EntityJGXXBYORGCODEORGNAME_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGNAME");
	private final static QName _EntityJGXXBYORGCODECREATEDATE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "CREATEDATE");
	private final static QName _EntityJGXXBYORGCODEINNERCODE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "INNERCODE");
	private final static QName _EntityJGXXBYORGCODETELEPHONE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "TELEPHONE");
	private final static QName _EntityJGXXBYORGCODEORGORDER_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGORDER");
	private final static QName _EntityJGXXBYORGCODEPARTYDIRECTOR_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "PARTYDIRECTOR");
	private final static QName _EntityJGXXBYORGCODEADDRESS_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ADDRESS");
	private final static QName _EntityJGXXBYORGCODEDESCN_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "DESCN");
	private final static QName _EntityJGXXBYORGCODEISCORP_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ISCORP");
	private final static QName _EntityJGXXBYORGCODEORGENNAME_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGENNAME");
	private final static QName _EntityJGXXBYORGCODEORGENSIMNAME_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGENSIMNAME");
	private final static QName _EntityJGXXBYORGCODEFAX_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "FAX");
	private final static QName _EntityJGXXBYORGCODEVIRFLAG_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "VIRFLAG");
	private final static QName _EntityJGXXBYORGCODEID_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ID");
	private final static QName _EntityJGXXBYORGCODEEMAIL_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "EMAIL");
	private final static QName _EntityJGXXBYORGCODESJC_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SJC");
	private final static QName _EntityJGXXBYORGCODEPARENTORGCODE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "PARENTORGCODE");
	private final static QName _EntityJGXXBYORGCODEORGNAMESPELL_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGNAMESPELL");
	private final static QName _EntityJGXXBYORGCODEOPERATERNAME_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "OPERATERNAME");
	private final static QName _EntityJGXXBYORGCODEORGLEVEL_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGLEVEL");
	private final static QName _EntityJGXXBYORGCODEOPERATERID_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "OPERATERID");
	private final static QName _EntityJGXXBYORGCODEORGTYPE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGTYPE");
	private final static QName _EntityJGXXBYORGCODEBZ_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "BZ");
	private final static QName _EntityJGXXBYORGCODEORGSIMNAME_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ORGSIMNAME");
	private final static QName _EntityJGXXBYORGCODESTATUS_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "STATUS");
	private final static QName _EntityJGXXBYORGCODEATTRIBUTE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ATTRIBUTE");
	private final static QName _EntityJGXXBYORGCODEOPERATETIME_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "OPERATETIME");
	private final static QName _EntityJGXXBYORGCODEPOSTCODE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "POSTCODE");
	private final static QName _EntityJGXXBYORGCODEADMINDIRECTOR_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ADMINDIRECTOR");
	private final static QName _EntityJGXXBYORGCODEINVALIDDATE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "INVALIDDATE");
	private final static QName _EntityJGXXBYORGCODEFATHERID_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "FATHERID");
	private final static QName _QueryArgs0_QNAME = new QName(
			"http://release.service.das.jeaw.com", "args0");

	/**
	 * Create a new ObjectFactory that can be used to create new instances of
	 * schema derived classes for package: ORGCODE
	 * 
	 */
	public ObjectFactory() {
	}

	/**
	 * Create an instance of {@link Security.UsernameToken }
	 * 
	 */
	public Security.UsernameToken createSecurityUsernameToken() {
		return new Security.UsernameToken();
	}

	/**
	 * Create an instance of {@link ArgumentJGXXBYORGCODE }
	 * 
	 */
	public ArgumentJGXXBYORGCODE createArgumentJGXXBYORGCODE() {
		return new ArgumentJGXXBYORGCODE();
	}

	/**
	 * Create an instance of {@link QueryResponse }
	 * 
	 */
	public QueryResponse createQueryResponse() {
		return new QueryResponse();
	}

	/**
	 * Create an instance of {@link EntityJGXXBYORGCODE }
	 * 
	 */
	public EntityJGXXBYORGCODE createEntityJGXXBYORGCODE() {
		return new EntityJGXXBYORGCODE();
	}

	/**
	 * Create an instance of {@link ReturnEntity }
	 * 
	 */
	public ReturnEntity createReturnEntity() {
		return new ReturnEntity();
	}

	/**
	 * Create an instance of {@link Query }
	 * 
	 */
	public Query createQuery() {
		return new Query();
	}

	/**
	 * Create an instance of {@link ParametersPadding }
	 * 
	 */
	public ParametersPadding createParametersPadding() {
		return new ParametersPadding();
	}

	/**
	 * Create an instance of {@link Argument }
	 * 
	 */
	public Argument createArgument() {
		return new Argument();
	}

	/**
	 * Create an instance of {@link Entity }
	 * 
	 */
	public Entity createEntity() {
		return new Entity();
	}

	/**
	 * Create an instance of {@link GetEntityTypeResponse }
	 * 
	 */
	public GetEntityTypeResponse createGetEntityTypeResponse() {
		return new GetEntityTypeResponse();
	}

	/**
	 * Create an instance of {@link Security }
	 * 
	 */
	public Security createSecurity() {
		return new Security();
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGCODE", scope = ArgumentJGXXBYORGCODE.class)
	public JAXBElement<String> createArgumentJGXXBYORGCODEORGCODE(String value) {
		return new JAXBElement<String>(_ArgumentJGXXBYORGCODEORGCODE_QNAME,
				String.class, ArgumentJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link ReturnEntity }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = QueryResponse.class)
	public JAXBElement<ReturnEntity> createQueryResponseReturn(
			ReturnEntity value) {
		return new JAXBElement<ReturnEntity>(_QueryResponseReturn_QNAME,
				ReturnEntity.class, QueryResponse.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://pojo.servgen.das.jeaw.com/xsd", name = "message", scope = ReturnEntity.class)
	public JAXBElement<String> createReturnEntityMessage(String value) {
		return new JAXBElement<String>(_ReturnEntityMessage_QNAME,
				String.class, ReturnEntity.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://pojo.servgen.das.jeaw.com/xsd", name = "code", scope = ReturnEntity.class)
	public JAXBElement<String> createReturnEntityCode(String value) {
		return new JAXBElement<String>(_ReturnEntityCode_QNAME, String.class,
				ReturnEntity.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "TREEPATH", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODETREEPATH(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODETREEPATH_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "DELFLAG", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEDELFLAG(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEDELFLAG_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGNAME", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEORGNAME(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEORGNAME_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "CREATEDATE", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODECREATEDATE(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODECREATEDATE_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "INNERCODE", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEINNERCODE(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEINNERCODE_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "TELEPHONE", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODETELEPHONE(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODETELEPHONE_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGORDER", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<Double> createEntityJGXXBYORGCODEORGORDER(Double value) {
		return new JAXBElement<Double>(_EntityJGXXBYORGCODEORGORDER_QNAME,
				Double.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "PARTYDIRECTOR", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEPARTYDIRECTOR(
			String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEPARTYDIRECTOR_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ADDRESS", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEADDRESS(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEADDRESS_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "DESCN", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEDESCN(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEDESCN_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ISCORP", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEISCORP(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEISCORP_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGENNAME", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEORGENNAME(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEORGENNAME_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGENSIMNAME", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEORGENSIMNAME(
			String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEORGENSIMNAME_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "FAX", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEFAX(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEFAX_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "VIRFLAG", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEVIRFLAG(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEVIRFLAG_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ID", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEID(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEID_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "EMAIL", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEEMAIL(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEEMAIL_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SJC", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODESJC(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODESJC_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "PARENTORGCODE", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEPARENTORGCODE(
			String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEPARENTORGCODE_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGNAMESPELL", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEORGNAMESPELL(
			String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEORGNAMESPELL_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "OPERATERNAME", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEOPERATERNAME(
			String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEOPERATERNAME_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGLEVEL", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<Double> createEntityJGXXBYORGCODEORGLEVEL(Double value) {
		return new JAXBElement<Double>(_EntityJGXXBYORGCODEORGLEVEL_QNAME,
				Double.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "OPERATERID", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEOPERATERID(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEOPERATERID_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGTYPE", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEORGTYPE(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEORGTYPE_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "BZ", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEBZ(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEBZ_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGSIMNAME", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEORGSIMNAME(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEORGSIMNAME_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "STATUS", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODESTATUS(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODESTATUS_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ATTRIBUTE", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEATTRIBUTE(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEATTRIBUTE_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "OPERATETIME", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEOPERATETIME(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEOPERATETIME_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "POSTCODE", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEPOSTCODE(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEPOSTCODE_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ADMINDIRECTOR", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEADMINDIRECTOR(
			String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEADMINDIRECTOR_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ORGCODE", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEORGCODE(String value) {
		return new JAXBElement<String>(_ArgumentJGXXBYORGCODEORGCODE_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "INVALIDDATE", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEINVALIDDATE(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEINVALIDDATE_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "FATHERID", scope = EntityJGXXBYORGCODE.class)
	public JAXBElement<String> createEntityJGXXBYORGCODEFATHERID(String value) {
		return new JAXBElement<String>(_EntityJGXXBYORGCODEFATHERID_QNAME,
				String.class, EntityJGXXBYORGCODE.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}
	 * {@link ArgumentJGXXBYORGCODE }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "args0", scope = Query.class)
	public JAXBElement<ArgumentJGXXBYORGCODE> createQueryArgs0(
			ArgumentJGXXBYORGCODE value) {
		return new JAXBElement<ArgumentJGXXBYORGCODE>(_QueryArgs0_QNAME,
				ArgumentJGXXBYORGCODE.class, Query.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}
	 * {@link EntityJGXXBYORGCODE }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = GetEntityTypeResponse.class)
	public JAXBElement<EntityJGXXBYORGCODE> createGetEntityTypeResponseReturn(
			EntityJGXXBYORGCODE value) {
		return new JAXBElement<EntityJGXXBYORGCODE>(_QueryResponseReturn_QNAME,
				EntityJGXXBYORGCODE.class, GetEntityTypeResponse.class, value);
	}

}
