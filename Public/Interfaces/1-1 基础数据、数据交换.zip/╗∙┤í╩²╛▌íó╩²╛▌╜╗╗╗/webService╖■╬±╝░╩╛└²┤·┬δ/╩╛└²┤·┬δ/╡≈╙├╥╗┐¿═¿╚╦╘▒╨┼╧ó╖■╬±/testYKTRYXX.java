import java.net.URL;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.ws.Holder;

import YKTRYXX.ArgumentTSGYKTRYXX;
import YKTRYXX.EntityTSGYKTRYXX;
import YKTRYXX.Query;
import YKTRYXX.QueryResponse;
import YKTRYXX.Security;
import YKTRYXX.ServiceTSGYKTRYXX;
import YKTRYXX.ServiceTSGYKTRYXXPortType;
import YKTRYXX.Security.UsernameToken;


public class testYKTRYXX {
	public static void main(String args[]){
		try{
		
			ServiceTSGYKTRYXX sp = new ServiceTSGYKTRYXX();
			ServiceTSGYKTRYXXPortType portType = sp.getServiceTSGYKTRYXXHttpSoap11Endpoint();

			testQuery(portType);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static JAXBElement<Long> changeLongOfJAXB(String value,String url,String valueName){
		JAXBElement<Long> result = new JAXBElement<Long>(new QName(url,valueName),Long.class,Long.valueOf(value));
		return result;
	}
	public static JAXBElement<String> changeStringOfJAXB(String value,String url,String valueName){
		JAXBElement<String> result = new JAXBElement<String>(new QName(url,valueName),String.class,value);
		return result;
	}

	public static void testQuery(ServiceTSGYKTRYXXPortType portType){
		Query parameters = new  Query();	
		ArgumentTSGYKTRYXX argument = new ArgumentTSGYKTRYXX();
		argument.setPage(1);
		argument.setPageSize(50);

		JAXBElement<ArgumentTSGYKTRYXX> arg0 = new JAXBElement<ArgumentTSGYKTRYXX>(
				new QName("http://release.service.das.jeaw.com", "args0"),
				ArgumentTSGYKTRYXX.class, argument);
		
		
		parameters.setArgs0(arg0);
		
		Security securityHeader = new Security();
		UsernameToken ut = new UsernameToken();
		ut.setUsername("pt.jcsj");
		ut.setPassword("111111");
		securityHeader.setUsernameToken(ut);
		securityHeader.setMustUnderstand(true);

		QueryResponse response = new QueryResponse();

		response = portType.query(parameters, securityHeader);

		List<Object> enlist = response.getReturn().getValue().getResult();

		for(Object obj:enlist){
			EntityTSGYKTRYXX en = (EntityTSGYKTRYXX)obj;	
				System.out.println("BH0: "+en.getBH0().getValue());
				System.out.println("CSRQ0: "+en.getCSRQ0().getValue());
				System.out.println("BZLBM1: "+en.getBZLBM1().getValue());
		}
	}
}
