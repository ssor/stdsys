package YKTRYXX;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each Java content interface and Java
 * element interface generated in the YKTRYXX package.
 * <p>
 * An ObjectFactory allows you to programatically construct new instances of the
 * Java representation for XML content. The Java representation of XML content
 * can consist of schema derived interfaces and classes representing the binding
 * of schema type definitions, element declarations and model groups. Factory
 * methods for each of these are provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

	private final static QName _EntityTSGYKTRYXXDQZTM1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "DQZTM_1");
	private final static QName _EntityTSGYKTRYXXSSYXM2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SSYXM_2");
	private final static QName _EntityTSGYKTRYXXZGXLM1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ZGXLM_1");
	private final static QName _EntityTSGYKTRYXXWHCDM1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "WHCDM_1");
	private final static QName _EntityTSGYKTRYXXBZLBM1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "BZLBM_1");
	private final static QName _EntityTSGYKTRYXXGJM0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "GJM_0");
	private final static QName _EntityTSGYKTRYXXGJM1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "GJM_1");
	private final static QName _EntityTSGYKTRYXXID2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ID_2");
	private final static QName _EntityTSGYKTRYXXID3_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ID_3");
	private final static QName _EntityTSGYKTRYXXID0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ID_0");
	private final static QName _EntityTSGYKTRYXXSFBY2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SFBY_2");
	private final static QName _EntityTSGYKTRYXXID1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ID_1");
	private final static QName _EntityTSGYKTRYXXDZXX0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "DZXX_0");
	private final static QName _EntityTSGYKTRYXXXBM1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XBM_1");
	private final static QName _EntityTSGYKTRYXXSFBY0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SFBY_0");
	private final static QName _EntityTSGYKTRYXXXM2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XM_2");
	private final static QName _EntityTSGYKTRYXXXBM0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XBM_0");
	private final static QName _EntityTSGYKTRYXXXKZYM2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XKZYM_2");
	private final static QName _EntityTSGYKTRYXXXBM2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XBM_2");
	private final static QName _EntityTSGYKTRYXXXZ0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XZ_0");
	private final static QName _EntityTSGYKTRYXXXM1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XM_1");
	private final static QName _EntityTSGYKTRYXXXCSXK1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XCSXK_1");
	private final static QName _EntityTSGYKTRYXXXM0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XM_0");
	private final static QName _EntityTSGYKTRYXXXZ2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XZ_2");
	private final static QName _EntityTSGYKTRYXXSJC0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SJC_0");
	private final static QName _EntityTSGYKTRYXXSSDWM1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SSDWM_1");
	private final static QName _EntityTSGYKTRYXXSJC2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SJC_2");
	private final static QName _EntityTSGYKTRYXXSJC1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SJC_1");
	private final static QName _EntityTSGYKTRYXXJGM0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "JGM_0");
	private final static QName _EntityTSGYKTRYXXTSXSLXM0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "TSXSLXM_0");
	private final static QName _EntityTSGYKTRYXXSSYXM0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SSYXM_0");
	private final static QName _EntityTSGYKTRYXXNJ0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "NJ_0");
	private final static QName _EntityTSGYKTRYXXRYBH3_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "RYBH_3");
	private final static QName _EntityTSGYKTRYXXJGM2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "JGM_2");
	private final static QName _EntityTSGYKTRYXXJGM1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "JGM_1");
	private final static QName _EntityTSGYKTRYXXNJ2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "NJ_2");
	private final static QName _EntityTSGYKTRYXXXSLBM2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XSLBM_2");
	private final static QName _EntityTSGYKTRYXXXSLBM0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XSLBM_0");
	private final static QName _EntityTSGYKTRYXXJGH1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "JGH_1");
	private final static QName _EntityTSGYKTRYXXDSJGH2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "DSJGH_2");
	private final static QName _EntityTSGYKTRYXXBZ0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "BZ_0");
	private final static QName _EntityTSGYKTRYXXPYFSM2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "PYFSM_2");
	private final static QName _EntityTSGYKTRYXXHKSZD0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "HKSZD_0");
	private final static QName _EntityTSGYKTRYXXBZ2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "BZ_2");
	private final static QName _EntityTSGYKTRYXXPYFSM0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "PYFSM_0");
	private final static QName _EntityTSGYKTRYXXBZ1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "BZ_1");
	private final static QName _EntityTSGYKTRYXXBZ3_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "BZ_3");
	private final static QName _EntityTSGYKTRYXXRXNY2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "RXNY_2");
	private final static QName _EntityTSGYKTRYXXZP3_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ZP_3");
	private final static QName _EntityTSGYKTRYXXRXNY0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "RXNY_0");
	private final static QName _EntityTSGYKTRYXXSFYXJ0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SFYXJ_0");
	private final static QName _EntityTSGYKTRYXXSFZJH0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SFZJH_0");
	private final static QName _EntityTSGYKTRYXXZZMMM2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ZZMMM_2");
	private final static QName _EntityTSGYKTRYXXYHCZZH3_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "YHCZZH_3");
	private final static QName _EntityTSGYKTRYXXRYXM3_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "RYXM_3");
	private final static QName _EntityTSGYKTRYXXSFZJH1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SFZJH_1");
	private final static QName _EntityTSGYKTRYXXSFZJH2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SFZJH_2");
	private final static QName _EntityTSGYKTRYXXSJC3_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SJC_3");
	private final static QName _EntityTSGYKTRYXXLXSJ1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "LXSJ_1");
	private final static QName _EntityTSGYKTRYXXKZT3_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "KZT_3");
	private final static QName _EntityTSGYKTRYXXCJGZNY1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "CJGZNY_1");
	private final static QName _EntityTSGYKTRYXXMZM1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "MZM_1");
	private final static QName _EntityTSGYKTRYXXMZM2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "MZM_2");
	private final static QName _EntityTSGYKTRYXXMZM0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "MZM_0");
	private final static QName _EntityTSGYKTRYXXJZGLBM1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "JZGLBM_1");
	private final static QName _EntityTSGYKTRYXXXSCCM2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XSCCM_2");
	private final static QName _EntityTSGYKTRYXXSFZJLXM2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SFZJLXM_2");
	private final static QName _EntityTSGYKTRYXXZXZTM0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ZXZTM_0");
	private final static QName _EntityTSGYKTRYXXSFZJLXM1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SFZJLXM_1");
	private final static QName _EntityTSGYKTRYXXZZMMM0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ZZMMM_0");
	private final static QName _EntityTSGYKTRYXXZZMMM1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ZZMMM_1");
	private final static QName _EntityTSGYKTRYXXXKMLM0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XKMLM_0");
	private final static QName _EntityTSGYKTRYXXZYM1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ZYM_1");
	private final static QName _EntityTSGYKTRYXXSFZJLXM0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SFZJLXM_0");
	private final static QName _EntityTSGYKTRYXXBH0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "BH_0");
	private final static QName _EntityTSGYKTRYXXCSRQ2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "CSRQ_2");
	private final static QName _EntityTSGYKTRYXXCSRQ1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "CSRQ_1");
	private final static QName _EntityTSGYKTRYXXCSRQ0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "CSRQ_0");
	private final static QName _EntityTSGYKTRYXXYKTKH3_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "YKTKH_3");
	private final static QName _EntityTSGYKTRYXXXH0_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XH_0");
	private final static QName _EntityTSGYKTRYXXCJNY1_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "CJNY_1");
	private final static QName _EntityTSGYKTRYXXXH2_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "XH_2");
	private final static QName _QueryArgs0_QNAME = new QName(
			"http://release.service.das.jeaw.com", "args0");
	private final static QName _ReturnEntityMessage_QNAME = new QName(
			"http://pojo.servgen.das.jeaw.com/xsd", "message");
	private final static QName _ReturnEntityCode_QNAME = new QName(
			"http://pojo.servgen.das.jeaw.com/xsd", "code");
	private final static QName _GetEntityTypeResponseReturn_QNAME = new QName(
			"http://release.service.das.jeaw.com", "return");

	/**
	 * Create a new ObjectFactory that can be used to create new instances of
	 * schema derived classes for package: YKTRYXX
	 * 
	 */
	public ObjectFactory() {
	}

	/**
	 * Create an instance of {@link ArgumentTSGYKTRYXX }
	 * 
	 */
	public ArgumentTSGYKTRYXX createArgumentTSGYKTRYXX() {
		return new ArgumentTSGYKTRYXX();
	}

	/**
	 * Create an instance of {@link Entity }
	 * 
	 */
	public Entity createEntity() {
		return new Entity();
	}

	/**
	 * Create an instance of {@link Argument }
	 * 
	 */
	public Argument createArgument() {
		return new Argument();
	}

	/**
	 * Create an instance of {@link Security }
	 * 
	 */
	public Security createSecurity() {
		return new Security();
	}

	/**
	 * Create an instance of {@link Security.UsernameToken }
	 * 
	 */
	public Security.UsernameToken createSecurityUsernameToken() {
		return new Security.UsernameToken();
	}

	/**
	 * Create an instance of {@link EntityTSGYKTRYXX }
	 * 
	 */
	public EntityTSGYKTRYXX createEntityTSGYKTRYXX() {
		return new EntityTSGYKTRYXX();
	}

	/**
	 * Create an instance of {@link ParametersPadding }
	 * 
	 */
	public ParametersPadding createParametersPadding() {
		return new ParametersPadding();
	}

	/**
	 * Create an instance of {@link Query }
	 * 
	 */
	public Query createQuery() {
		return new Query();
	}

	/**
	 * Create an instance of {@link GetEntityTypeResponse }
	 * 
	 */
	public GetEntityTypeResponse createGetEntityTypeResponse() {
		return new GetEntityTypeResponse();
	}

	/**
	 * Create an instance of {@link QueryResponse }
	 * 
	 */
	public QueryResponse createQueryResponse() {
		return new QueryResponse();
	}

	/**
	 * Create an instance of {@link ReturnEntity }
	 * 
	 */
	public ReturnEntity createReturnEntity() {
		return new ReturnEntity();
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "DQZTM_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXDQZTM1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXDQZTM1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SSYXM_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSSYXM2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSSYXM2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ZGXLM_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXZGXLM1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXZGXLM1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "WHCDM_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXWHCDM1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXWHCDM1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "BZLBM_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXBZLBM1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXBZLBM1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "GJM_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXGJM0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXGJM0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "GJM_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXGJM1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXGJM1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ID_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXID2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXID2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ID_3", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXID3(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXID3_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ID_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXID0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXID0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SFBY_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSFBY2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSFBY2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ID_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXID1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXID1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "DZXX_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXDZXX0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXDZXX0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XBM_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXXBM1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXXBM1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SFBY_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSFBY0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSFBY0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XM_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXXM2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXXM2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XBM_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXXBM0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXXBM0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XKZYM_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXXKZYM2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXXKZYM2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XBM_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXXBM2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXXBM2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XZ_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<Double> createEntityTSGYKTRYXXXZ0(Double value) {
		return new JAXBElement<Double>(_EntityTSGYKTRYXXXZ0_QNAME,
				Double.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XM_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXXM1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXXM1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XCSXK_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXXCSXK1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXXCSXK1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XM_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXXM0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXXM0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XZ_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<Double> createEntityTSGYKTRYXXXZ2(Double value) {
		return new JAXBElement<Double>(_EntityTSGYKTRYXXXZ2_QNAME,
				Double.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SJC_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSJC0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSJC0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SSDWM_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSSDWM1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSSDWM1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SJC_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSJC2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSJC2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SJC_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSJC1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSJC1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "JGM_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXJGM0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXJGM0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "TSXSLXM_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXTSXSLXM0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXTSXSLXM0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SSYXM_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSSYXM0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSSYXM0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "NJ_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXNJ0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXNJ0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "RYBH_3", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXRYBH3(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXRYBH3_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "JGM_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXJGM2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXJGM2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "JGM_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXJGM1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXJGM1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "NJ_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXNJ2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXNJ2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XSLBM_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXXSLBM2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXXSLBM2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XSLBM_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXXSLBM0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXXSLBM0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "JGH_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXJGH1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXJGH1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "DSJGH_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXDSJGH2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXDSJGH2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "BZ_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXBZ0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXBZ0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "PYFSM_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXPYFSM2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXPYFSM2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "HKSZD_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXHKSZD0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXHKSZD0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "BZ_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXBZ2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXBZ2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "PYFSM_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXPYFSM0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXPYFSM0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "BZ_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXBZ1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXBZ1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "BZ_3", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXBZ3(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXBZ3_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "RXNY_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXRXNY2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXRXNY2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ZP_3", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXZP3(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXZP3_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "RXNY_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXRXNY0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXRXNY0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SFYXJ_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSFYXJ0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSFYXJ0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SFZJH_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSFZJH0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSFZJH0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ZZMMM_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXZZMMM2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXZZMMM2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "YHCZZH_3", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXYHCZZH3(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXYHCZZH3_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "RYXM_3", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXRYXM3(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXRYXM3_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SFZJH_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSFZJH1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSFZJH1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SFZJH_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSFZJH2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSFZJH2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SJC_3", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSJC3(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSJC3_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "LXSJ_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXLXSJ1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXLXSJ1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "KZT_3", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<Double> createEntityTSGYKTRYXXKZT3(Double value) {
		return new JAXBElement<Double>(_EntityTSGYKTRYXXKZT3_QNAME,
				Double.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "CJGZNY_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXCJGZNY1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXCJGZNY1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "MZM_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXMZM1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXMZM1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "MZM_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXMZM2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXMZM2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "MZM_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXMZM0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXMZM0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "JZGLBM_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXJZGLBM1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXJZGLBM1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XSCCM_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXXSCCM2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXXSCCM2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SFZJLXM_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSFZJLXM2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSFZJLXM2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ZXZTM_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXZXZTM0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXZXZTM0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SFZJLXM_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSFZJLXM1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSFZJLXM1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ZZMMM_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXZZMMM0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXZZMMM0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ZZMMM_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXZZMMM1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXZZMMM1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XKMLM_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXXKMLM0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXXKMLM0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ZYM_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXZYM1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXZYM1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SFZJLXM_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXSFZJLXM0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXSFZJLXM0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "BH_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXBH0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXBH0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "CSRQ_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXCSRQ2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXCSRQ2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "CSRQ_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXCSRQ1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXCSRQ1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "CSRQ_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXCSRQ0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXCSRQ0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "YKTKH_3", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXYKTKH3(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXYKTKH3_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XH_0", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXXH0(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXXH0_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "CJNY_1", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXCJNY1(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXCJNY1_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "XH_2", scope = EntityTSGYKTRYXX.class)
	public JAXBElement<String> createEntityTSGYKTRYXXXH2(String value) {
		return new JAXBElement<String>(_EntityTSGYKTRYXXXH2_QNAME,
				String.class, EntityTSGYKTRYXX.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}
	 * {@link ArgumentTSGYKTRYXX }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "args0", scope = Query.class)
	public JAXBElement<ArgumentTSGYKTRYXX> createQueryArgs0(
			ArgumentTSGYKTRYXX value) {
		return new JAXBElement<ArgumentTSGYKTRYXX>(_QueryArgs0_QNAME,
				ArgumentTSGYKTRYXX.class, Query.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://pojo.servgen.das.jeaw.com/xsd", name = "message", scope = ReturnEntity.class)
	public JAXBElement<String> createReturnEntityMessage(String value) {
		return new JAXBElement<String>(_ReturnEntityMessage_QNAME,
				String.class, ReturnEntity.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://pojo.servgen.das.jeaw.com/xsd", name = "code", scope = ReturnEntity.class)
	public JAXBElement<String> createReturnEntityCode(String value) {
		return new JAXBElement<String>(_ReturnEntityCode_QNAME, String.class,
				ReturnEntity.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}
	 * {@link EntityTSGYKTRYXX }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = GetEntityTypeResponse.class)
	public JAXBElement<EntityTSGYKTRYXX> createGetEntityTypeResponseReturn(
			EntityTSGYKTRYXX value) {
		return new JAXBElement<EntityTSGYKTRYXX>(
				_GetEntityTypeResponseReturn_QNAME, EntityTSGYKTRYXX.class,
				GetEntityTypeResponse.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link ReturnEntity }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = QueryResponse.class)
	public JAXBElement<ReturnEntity> createQueryResponseReturn(
			ReturnEntity value) {
		return new JAXBElement<ReturnEntity>(
				_GetEntityTypeResponseReturn_QNAME, ReturnEntity.class,
				QueryResponse.class, value);
	}

}
