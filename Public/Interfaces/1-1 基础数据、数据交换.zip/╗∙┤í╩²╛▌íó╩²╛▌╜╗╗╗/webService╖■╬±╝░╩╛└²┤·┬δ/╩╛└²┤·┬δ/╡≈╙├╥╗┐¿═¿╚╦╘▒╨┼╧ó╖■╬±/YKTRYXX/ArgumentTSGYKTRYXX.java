package YKTRYXX;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for ArgumentTSG_YKTRYXX complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="ArgumentTSG_YKTRYXX">
 *   &lt;complexContent>
 *     &lt;extension base="{http://pojo.servgen.das.jeaw.com/xsd}Argument">
 *       &lt;sequence>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArgumentTSG_YKTRYXX", namespace = "http://release.service.das.jeaw.com/xsd")
public class ArgumentTSGYKTRYXX extends Argument {

}
