package YKTRYXX;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for EntityTSG_YKTRYXX complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="EntityTSG_YKTRYXX">
 *   &lt;complexContent>
 *     &lt;extension base="{http://pojo.servgen.das.jeaw.com/xsd}Entity">
 *       &lt;sequence>
 *         &lt;element name="BH_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BZLBM_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BZ_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BZ_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BZ_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BZ_3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CJGZNY_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CJNY_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CSRQ_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CSRQ_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CSRQ_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DQZTM_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DSJGH_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DZXX_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="GJM_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="GJM_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HKSZD_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ID_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ID_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ID_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ID_3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="JGH_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="JGM_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="JGM_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="JGM_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="JZGLBM_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="KZT_3" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="LXSJ_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MZM_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MZM_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MZM_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NJ_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NJ_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PYFSM_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PYFSM_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RXNY_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RXNY_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RYBH_3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RYXM_3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SFBY_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SFBY_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SFYXJ_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SFZJH_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SFZJH_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SFZJH_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SFZJLXM_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SFZJLXM_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SFZJLXM_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SJC_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SJC_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SJC_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SJC_3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SSDWM_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SSYXM_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SSYXM_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TSXSLXM_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="WHCDM_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XBM_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XBM_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XBM_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XCSXK_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XH_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XH_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XKMLM_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XKZYM_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XM_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XM_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XM_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XSCCM_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XSLBM_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XSLBM_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="XZ_0" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="XZ_2" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="YHCZZH_3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="YKTKH_3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ZGXLM_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ZP_3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ZXZTM_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ZYM_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ZZMMM_0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ZZMMM_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ZZMMM_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EntityTSG_YKTRYXX", namespace = "http://release.service.das.jeaw.com/xsd", propOrder = {
		"bh0", "bzlbm1", "bz0", "bz1", "bz2", "bz3", "cjgzny1", "cjny1",
		"csrq0", "csrq1", "csrq2", "dqztm1", "dsjgh2", "dzxx0", "gjm0", "gjm1",
		"hkszd0", "id0", "id1", "id2", "id3", "jgh1", "jgm0", "jgm1", "jgm2",
		"jzglbm1", "kzt3", "lxsj1", "mzm0", "mzm1", "mzm2", "nj0", "nj2",
		"pyfsm0", "pyfsm2", "rxny0", "rxny2", "rybh3", "ryxm3", "sfby0",
		"sfby2", "sfyxj0", "sfzjh0", "sfzjh1", "sfzjh2", "sfzjlxm0",
		"sfzjlxm1", "sfzjlxm2", "sjc0", "sjc1", "sjc2", "sjc3", "ssdwm1",
		"ssyxm0", "ssyxm2", "tsxslxm0", "whcdm1", "xbm0", "xbm1", "xbm2",
		"xcsxk1", "xh0", "xh2", "xkmlm0", "xkzym2", "xm0", "xm1", "xm2",
		"xsccm2", "xslbm0", "xslbm2", "xz0", "xz2", "yhczzh3", "yktkh3",
		"zgxlm1", "zp3", "zxztm0", "zym1", "zzmmm0", "zzmmm1", "zzmmm2" })
public class EntityTSGYKTRYXX extends Entity {

	@XmlElementRef(name = "BH_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> bh0;
	@XmlElementRef(name = "BZLBM_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> bzlbm1;
	@XmlElementRef(name = "BZ_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> bz0;
	@XmlElementRef(name = "BZ_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> bz1;
	@XmlElementRef(name = "BZ_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> bz2;
	@XmlElementRef(name = "BZ_3", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> bz3;
	@XmlElementRef(name = "CJGZNY_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> cjgzny1;
	@XmlElementRef(name = "CJNY_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> cjny1;
	@XmlElementRef(name = "CSRQ_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> csrq0;
	@XmlElementRef(name = "CSRQ_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> csrq1;
	@XmlElementRef(name = "CSRQ_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> csrq2;
	@XmlElementRef(name = "DQZTM_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> dqztm1;
	@XmlElementRef(name = "DSJGH_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> dsjgh2;
	@XmlElementRef(name = "DZXX_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> dzxx0;
	@XmlElementRef(name = "GJM_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> gjm0;
	@XmlElementRef(name = "GJM_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> gjm1;
	@XmlElementRef(name = "HKSZD_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> hkszd0;
	@XmlElementRef(name = "ID_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> id0;
	@XmlElementRef(name = "ID_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> id1;
	@XmlElementRef(name = "ID_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> id2;
	@XmlElementRef(name = "ID_3", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> id3;
	@XmlElementRef(name = "JGH_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> jgh1;
	@XmlElementRef(name = "JGM_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> jgm0;
	@XmlElementRef(name = "JGM_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> jgm1;
	@XmlElementRef(name = "JGM_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> jgm2;
	@XmlElementRef(name = "JZGLBM_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> jzglbm1;
	@XmlElementRef(name = "KZT_3", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<Double> kzt3;
	@XmlElementRef(name = "LXSJ_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> lxsj1;
	@XmlElementRef(name = "MZM_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> mzm0;
	@XmlElementRef(name = "MZM_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> mzm1;
	@XmlElementRef(name = "MZM_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> mzm2;
	@XmlElementRef(name = "NJ_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> nj0;
	@XmlElementRef(name = "NJ_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> nj2;
	@XmlElementRef(name = "PYFSM_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> pyfsm0;
	@XmlElementRef(name = "PYFSM_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> pyfsm2;
	@XmlElementRef(name = "RXNY_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> rxny0;
	@XmlElementRef(name = "RXNY_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> rxny2;
	@XmlElementRef(name = "RYBH_3", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> rybh3;
	@XmlElementRef(name = "RYXM_3", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> ryxm3;
	@XmlElementRef(name = "SFBY_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sfby0;
	@XmlElementRef(name = "SFBY_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sfby2;
	@XmlElementRef(name = "SFYXJ_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sfyxj0;
	@XmlElementRef(name = "SFZJH_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sfzjh0;
	@XmlElementRef(name = "SFZJH_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sfzjh1;
	@XmlElementRef(name = "SFZJH_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sfzjh2;
	@XmlElementRef(name = "SFZJLXM_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sfzjlxm0;
	@XmlElementRef(name = "SFZJLXM_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sfzjlxm1;
	@XmlElementRef(name = "SFZJLXM_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sfzjlxm2;
	@XmlElementRef(name = "SJC_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sjc0;
	@XmlElementRef(name = "SJC_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sjc1;
	@XmlElementRef(name = "SJC_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sjc2;
	@XmlElementRef(name = "SJC_3", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sjc3;
	@XmlElementRef(name = "SSDWM_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> ssdwm1;
	@XmlElementRef(name = "SSYXM_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> ssyxm0;
	@XmlElementRef(name = "SSYXM_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> ssyxm2;
	@XmlElementRef(name = "TSXSLXM_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> tsxslxm0;
	@XmlElementRef(name = "WHCDM_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> whcdm1;
	@XmlElementRef(name = "XBM_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> xbm0;
	@XmlElementRef(name = "XBM_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> xbm1;
	@XmlElementRef(name = "XBM_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> xbm2;
	@XmlElementRef(name = "XCSXK_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> xcsxk1;
	@XmlElementRef(name = "XH_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> xh0;
	@XmlElementRef(name = "XH_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> xh2;
	@XmlElementRef(name = "XKMLM_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> xkmlm0;
	@XmlElementRef(name = "XKZYM_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> xkzym2;
	@XmlElementRef(name = "XM_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> xm0;
	@XmlElementRef(name = "XM_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> xm1;
	@XmlElementRef(name = "XM_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> xm2;
	@XmlElementRef(name = "XSCCM_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> xsccm2;
	@XmlElementRef(name = "XSLBM_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> xslbm0;
	@XmlElementRef(name = "XSLBM_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> xslbm2;
	@XmlElementRef(name = "XZ_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<Double> xz0;
	@XmlElementRef(name = "XZ_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<Double> xz2;
	@XmlElementRef(name = "YHCZZH_3", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> yhczzh3;
	@XmlElementRef(name = "YKTKH_3", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> yktkh3;
	@XmlElementRef(name = "ZGXLM_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> zgxlm1;
	@XmlElementRef(name = "ZP_3", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> zp3;
	@XmlElementRef(name = "ZXZTM_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> zxztm0;
	@XmlElementRef(name = "ZYM_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> zym1;
	@XmlElementRef(name = "ZZMMM_0", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> zzmmm0;
	@XmlElementRef(name = "ZZMMM_1", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> zzmmm1;
	@XmlElementRef(name = "ZZMMM_2", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> zzmmm2;

	/**
	 * Gets the value of the bh0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getBH0() {
		return bh0;
	}

	/**
	 * Sets the value of the bh0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setBH0(JAXBElement<String> value) {
		this.bh0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the bzlbm1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getBZLBM1() {
		return bzlbm1;
	}

	/**
	 * Sets the value of the bzlbm1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setBZLBM1(JAXBElement<String> value) {
		this.bzlbm1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the bz0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getBZ0() {
		return bz0;
	}

	/**
	 * Sets the value of the bz0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setBZ0(JAXBElement<String> value) {
		this.bz0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the bz1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getBZ1() {
		return bz1;
	}

	/**
	 * Sets the value of the bz1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setBZ1(JAXBElement<String> value) {
		this.bz1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the bz2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getBZ2() {
		return bz2;
	}

	/**
	 * Sets the value of the bz2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setBZ2(JAXBElement<String> value) {
		this.bz2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the bz3 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getBZ3() {
		return bz3;
	}

	/**
	 * Sets the value of the bz3 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setBZ3(JAXBElement<String> value) {
		this.bz3 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the cjgzny1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getCJGZNY1() {
		return cjgzny1;
	}

	/**
	 * Sets the value of the cjgzny1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setCJGZNY1(JAXBElement<String> value) {
		this.cjgzny1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the cjny1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getCJNY1() {
		return cjny1;
	}

	/**
	 * Sets the value of the cjny1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setCJNY1(JAXBElement<String> value) {
		this.cjny1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the csrq0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getCSRQ0() {
		return csrq0;
	}

	/**
	 * Sets the value of the csrq0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setCSRQ0(JAXBElement<String> value) {
		this.csrq0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the csrq1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getCSRQ1() {
		return csrq1;
	}

	/**
	 * Sets the value of the csrq1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setCSRQ1(JAXBElement<String> value) {
		this.csrq1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the csrq2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getCSRQ2() {
		return csrq2;
	}

	/**
	 * Sets the value of the csrq2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setCSRQ2(JAXBElement<String> value) {
		this.csrq2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the dqztm1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getDQZTM1() {
		return dqztm1;
	}

	/**
	 * Sets the value of the dqztm1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setDQZTM1(JAXBElement<String> value) {
		this.dqztm1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the dsjgh2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getDSJGH2() {
		return dsjgh2;
	}

	/**
	 * Sets the value of the dsjgh2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setDSJGH2(JAXBElement<String> value) {
		this.dsjgh2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the dzxx0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getDZXX0() {
		return dzxx0;
	}

	/**
	 * Sets the value of the dzxx0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setDZXX0(JAXBElement<String> value) {
		this.dzxx0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the gjm0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getGJM0() {
		return gjm0;
	}

	/**
	 * Sets the value of the gjm0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setGJM0(JAXBElement<String> value) {
		this.gjm0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the gjm1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getGJM1() {
		return gjm1;
	}

	/**
	 * Sets the value of the gjm1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setGJM1(JAXBElement<String> value) {
		this.gjm1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the hkszd0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getHKSZD0() {
		return hkszd0;
	}

	/**
	 * Sets the value of the hkszd0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setHKSZD0(JAXBElement<String> value) {
		this.hkszd0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the id0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getID0() {
		return id0;
	}

	/**
	 * Sets the value of the id0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setID0(JAXBElement<String> value) {
		this.id0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the id1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getID1() {
		return id1;
	}

	/**
	 * Sets the value of the id1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setID1(JAXBElement<String> value) {
		this.id1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the id2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getID2() {
		return id2;
	}

	/**
	 * Sets the value of the id2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setID2(JAXBElement<String> value) {
		this.id2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the id3 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getID3() {
		return id3;
	}

	/**
	 * Sets the value of the id3 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setID3(JAXBElement<String> value) {
		this.id3 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the jgh1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getJGH1() {
		return jgh1;
	}

	/**
	 * Sets the value of the jgh1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setJGH1(JAXBElement<String> value) {
		this.jgh1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the jgm0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getJGM0() {
		return jgm0;
	}

	/**
	 * Sets the value of the jgm0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setJGM0(JAXBElement<String> value) {
		this.jgm0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the jgm1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getJGM1() {
		return jgm1;
	}

	/**
	 * Sets the value of the jgm1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setJGM1(JAXBElement<String> value) {
		this.jgm1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the jgm2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getJGM2() {
		return jgm2;
	}

	/**
	 * Sets the value of the jgm2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setJGM2(JAXBElement<String> value) {
		this.jgm2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the jzglbm1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getJZGLBM1() {
		return jzglbm1;
	}

	/**
	 * Sets the value of the jzglbm1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setJZGLBM1(JAXBElement<String> value) {
		this.jzglbm1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the kzt3 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link Double }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<Double> getKZT3() {
		return kzt3;
	}

	/**
	 * Sets the value of the kzt3 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link Double }
	 *            {@code >}
	 * 
	 */
	public void setKZT3(JAXBElement<Double> value) {
		this.kzt3 = ((JAXBElement<Double>) value);
	}

	/**
	 * Gets the value of the lxsj1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getLXSJ1() {
		return lxsj1;
	}

	/**
	 * Sets the value of the lxsj1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setLXSJ1(JAXBElement<String> value) {
		this.lxsj1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the mzm0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getMZM0() {
		return mzm0;
	}

	/**
	 * Sets the value of the mzm0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setMZM0(JAXBElement<String> value) {
		this.mzm0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the mzm1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getMZM1() {
		return mzm1;
	}

	/**
	 * Sets the value of the mzm1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setMZM1(JAXBElement<String> value) {
		this.mzm1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the mzm2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getMZM2() {
		return mzm2;
	}

	/**
	 * Sets the value of the mzm2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setMZM2(JAXBElement<String> value) {
		this.mzm2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the nj0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getNJ0() {
		return nj0;
	}

	/**
	 * Sets the value of the nj0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setNJ0(JAXBElement<String> value) {
		this.nj0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the nj2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getNJ2() {
		return nj2;
	}

	/**
	 * Sets the value of the nj2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setNJ2(JAXBElement<String> value) {
		this.nj2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the pyfsm0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getPYFSM0() {
		return pyfsm0;
	}

	/**
	 * Sets the value of the pyfsm0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setPYFSM0(JAXBElement<String> value) {
		this.pyfsm0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the pyfsm2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getPYFSM2() {
		return pyfsm2;
	}

	/**
	 * Sets the value of the pyfsm2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setPYFSM2(JAXBElement<String> value) {
		this.pyfsm2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the rxny0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getRXNY0() {
		return rxny0;
	}

	/**
	 * Sets the value of the rxny0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setRXNY0(JAXBElement<String> value) {
		this.rxny0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the rxny2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getRXNY2() {
		return rxny2;
	}

	/**
	 * Sets the value of the rxny2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setRXNY2(JAXBElement<String> value) {
		this.rxny2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the rybh3 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getRYBH3() {
		return rybh3;
	}

	/**
	 * Sets the value of the rybh3 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setRYBH3(JAXBElement<String> value) {
		this.rybh3 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the ryxm3 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getRYXM3() {
		return ryxm3;
	}

	/**
	 * Sets the value of the ryxm3 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setRYXM3(JAXBElement<String> value) {
		this.ryxm3 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sfby0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSFBY0() {
		return sfby0;
	}

	/**
	 * Sets the value of the sfby0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSFBY0(JAXBElement<String> value) {
		this.sfby0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sfby2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSFBY2() {
		return sfby2;
	}

	/**
	 * Sets the value of the sfby2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSFBY2(JAXBElement<String> value) {
		this.sfby2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sfyxj0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSFYXJ0() {
		return sfyxj0;
	}

	/**
	 * Sets the value of the sfyxj0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSFYXJ0(JAXBElement<String> value) {
		this.sfyxj0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sfzjh0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSFZJH0() {
		return sfzjh0;
	}

	/**
	 * Sets the value of the sfzjh0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSFZJH0(JAXBElement<String> value) {
		this.sfzjh0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sfzjh1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSFZJH1() {
		return sfzjh1;
	}

	/**
	 * Sets the value of the sfzjh1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSFZJH1(JAXBElement<String> value) {
		this.sfzjh1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sfzjh2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSFZJH2() {
		return sfzjh2;
	}

	/**
	 * Sets the value of the sfzjh2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSFZJH2(JAXBElement<String> value) {
		this.sfzjh2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sfzjlxm0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSFZJLXM0() {
		return sfzjlxm0;
	}

	/**
	 * Sets the value of the sfzjlxm0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSFZJLXM0(JAXBElement<String> value) {
		this.sfzjlxm0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sfzjlxm1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSFZJLXM1() {
		return sfzjlxm1;
	}

	/**
	 * Sets the value of the sfzjlxm1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSFZJLXM1(JAXBElement<String> value) {
		this.sfzjlxm1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sfzjlxm2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSFZJLXM2() {
		return sfzjlxm2;
	}

	/**
	 * Sets the value of the sfzjlxm2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSFZJLXM2(JAXBElement<String> value) {
		this.sfzjlxm2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sjc0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSJC0() {
		return sjc0;
	}

	/**
	 * Sets the value of the sjc0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSJC0(JAXBElement<String> value) {
		this.sjc0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sjc1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSJC1() {
		return sjc1;
	}

	/**
	 * Sets the value of the sjc1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSJC1(JAXBElement<String> value) {
		this.sjc1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sjc2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSJC2() {
		return sjc2;
	}

	/**
	 * Sets the value of the sjc2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSJC2(JAXBElement<String> value) {
		this.sjc2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sjc3 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSJC3() {
		return sjc3;
	}

	/**
	 * Sets the value of the sjc3 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSJC3(JAXBElement<String> value) {
		this.sjc3 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the ssdwm1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSSDWM1() {
		return ssdwm1;
	}

	/**
	 * Sets the value of the ssdwm1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSSDWM1(JAXBElement<String> value) {
		this.ssdwm1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the ssyxm0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSSYXM0() {
		return ssyxm0;
	}

	/**
	 * Sets the value of the ssyxm0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSSYXM0(JAXBElement<String> value) {
		this.ssyxm0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the ssyxm2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSSYXM2() {
		return ssyxm2;
	}

	/**
	 * Sets the value of the ssyxm2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSSYXM2(JAXBElement<String> value) {
		this.ssyxm2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the tsxslxm0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getTSXSLXM0() {
		return tsxslxm0;
	}

	/**
	 * Sets the value of the tsxslxm0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setTSXSLXM0(JAXBElement<String> value) {
		this.tsxslxm0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the whcdm1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getWHCDM1() {
		return whcdm1;
	}

	/**
	 * Sets the value of the whcdm1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setWHCDM1(JAXBElement<String> value) {
		this.whcdm1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xbm0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getXBM0() {
		return xbm0;
	}

	/**
	 * Sets the value of the xbm0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setXBM0(JAXBElement<String> value) {
		this.xbm0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xbm1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getXBM1() {
		return xbm1;
	}

	/**
	 * Sets the value of the xbm1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setXBM1(JAXBElement<String> value) {
		this.xbm1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xbm2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getXBM2() {
		return xbm2;
	}

	/**
	 * Sets the value of the xbm2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setXBM2(JAXBElement<String> value) {
		this.xbm2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xcsxk1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getXCSXK1() {
		return xcsxk1;
	}

	/**
	 * Sets the value of the xcsxk1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setXCSXK1(JAXBElement<String> value) {
		this.xcsxk1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xh0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getXH0() {
		return xh0;
	}

	/**
	 * Sets the value of the xh0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setXH0(JAXBElement<String> value) {
		this.xh0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xh2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getXH2() {
		return xh2;
	}

	/**
	 * Sets the value of the xh2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setXH2(JAXBElement<String> value) {
		this.xh2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xkmlm0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getXKMLM0() {
		return xkmlm0;
	}

	/**
	 * Sets the value of the xkmlm0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setXKMLM0(JAXBElement<String> value) {
		this.xkmlm0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xkzym2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getXKZYM2() {
		return xkzym2;
	}

	/**
	 * Sets the value of the xkzym2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setXKZYM2(JAXBElement<String> value) {
		this.xkzym2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xm0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getXM0() {
		return xm0;
	}

	/**
	 * Sets the value of the xm0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setXM0(JAXBElement<String> value) {
		this.xm0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xm1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getXM1() {
		return xm1;
	}

	/**
	 * Sets the value of the xm1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setXM1(JAXBElement<String> value) {
		this.xm1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xm2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getXM2() {
		return xm2;
	}

	/**
	 * Sets the value of the xm2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setXM2(JAXBElement<String> value) {
		this.xm2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xsccm2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getXSCCM2() {
		return xsccm2;
	}

	/**
	 * Sets the value of the xsccm2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setXSCCM2(JAXBElement<String> value) {
		this.xsccm2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xslbm0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getXSLBM0() {
		return xslbm0;
	}

	/**
	 * Sets the value of the xslbm0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setXSLBM0(JAXBElement<String> value) {
		this.xslbm0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xslbm2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getXSLBM2() {
		return xslbm2;
	}

	/**
	 * Sets the value of the xslbm2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setXSLBM2(JAXBElement<String> value) {
		this.xslbm2 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the xz0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link Double }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<Double> getXZ0() {
		return xz0;
	}

	/**
	 * Sets the value of the xz0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link Double }
	 *            {@code >}
	 * 
	 */
	public void setXZ0(JAXBElement<Double> value) {
		this.xz0 = ((JAXBElement<Double>) value);
	}

	/**
	 * Gets the value of the xz2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link Double }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<Double> getXZ2() {
		return xz2;
	}

	/**
	 * Sets the value of the xz2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link Double }
	 *            {@code >}
	 * 
	 */
	public void setXZ2(JAXBElement<Double> value) {
		this.xz2 = ((JAXBElement<Double>) value);
	}

	/**
	 * Gets the value of the yhczzh3 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getYHCZZH3() {
		return yhczzh3;
	}

	/**
	 * Sets the value of the yhczzh3 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setYHCZZH3(JAXBElement<String> value) {
		this.yhczzh3 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the yktkh3 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getYKTKH3() {
		return yktkh3;
	}

	/**
	 * Sets the value of the yktkh3 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setYKTKH3(JAXBElement<String> value) {
		this.yktkh3 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the zgxlm1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getZGXLM1() {
		return zgxlm1;
	}

	/**
	 * Sets the value of the zgxlm1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setZGXLM1(JAXBElement<String> value) {
		this.zgxlm1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the zp3 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getZP3() {
		return zp3;
	}

	/**
	 * Sets the value of the zp3 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setZP3(JAXBElement<String> value) {
		this.zp3 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the zxztm0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getZXZTM0() {
		return zxztm0;
	}

	/**
	 * Sets the value of the zxztm0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setZXZTM0(JAXBElement<String> value) {
		this.zxztm0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the zym1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getZYM1() {
		return zym1;
	}

	/**
	 * Sets the value of the zym1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setZYM1(JAXBElement<String> value) {
		this.zym1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the zzmmm0 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getZZMMM0() {
		return zzmmm0;
	}

	/**
	 * Sets the value of the zzmmm0 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setZZMMM0(JAXBElement<String> value) {
		this.zzmmm0 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the zzmmm1 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getZZMMM1() {
		return zzmmm1;
	}

	/**
	 * Sets the value of the zzmmm1 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setZZMMM1(JAXBElement<String> value) {
		this.zzmmm1 = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the zzmmm2 property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getZZMMM2() {
		return zzmmm2;
	}

	/**
	 * Sets the value of the zzmmm2 property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setZZMMM2(JAXBElement<String> value) {
		this.zzmmm2 = ((JAXBElement<String>) value);
	}

}
