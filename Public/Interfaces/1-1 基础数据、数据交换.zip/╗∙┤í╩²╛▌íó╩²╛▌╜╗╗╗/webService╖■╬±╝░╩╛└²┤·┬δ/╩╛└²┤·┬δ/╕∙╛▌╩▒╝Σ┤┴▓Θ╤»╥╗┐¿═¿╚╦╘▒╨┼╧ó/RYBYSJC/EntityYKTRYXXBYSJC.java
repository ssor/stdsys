package RYBYSJC;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for EntityYKTRYXXBYSJC complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="EntityYKTRYXXBYSJC">
 *   &lt;complexContent>
 *     &lt;extension base="{http://pojo.servgen.das.jeaw.com/xsd}Entity">
 *       &lt;sequence>
 *         &lt;element name="BZ" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="KZT" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="RYBH" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RYXM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SJC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="YHCZZH" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="YKTKH" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ZP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EntityYKTRYXXBYSJC", namespace = "http://release.service.das.jeaw.com/xsd", propOrder = {
		"bz", "id", "kzt", "rybh", "ryxm", "sjc", "yhczzh", "yktkh", "zp" })
public class EntityYKTRYXXBYSJC extends Entity {

	@XmlElementRef(name = "BZ", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> bz;
	@XmlElementRef(name = "ID", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> id;
	@XmlElementRef(name = "KZT", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<Double> kzt;
	@XmlElementRef(name = "RYBH", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> rybh;
	@XmlElementRef(name = "RYXM", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> ryxm;
	@XmlElementRef(name = "SJC", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> sjc;
	@XmlElementRef(name = "YHCZZH", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> yhczzh;
	@XmlElementRef(name = "YKTKH", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> yktkh;
	@XmlElementRef(name = "ZP", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> zp;

	/**
	 * Gets the value of the bz property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getBZ() {
		return bz;
	}

	/**
	 * Sets the value of the bz property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setBZ(JAXBElement<String> value) {
		this.bz = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the id property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getID() {
		return id;
	}

	/**
	 * Sets the value of the id property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setID(JAXBElement<String> value) {
		this.id = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the kzt property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link Double }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<Double> getKZT() {
		return kzt;
	}

	/**
	 * Sets the value of the kzt property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link Double }
	 *            {@code >}
	 * 
	 */
	public void setKZT(JAXBElement<Double> value) {
		this.kzt = ((JAXBElement<Double>) value);
	}

	/**
	 * Gets the value of the rybh property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getRYBH() {
		return rybh;
	}

	/**
	 * Sets the value of the rybh property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setRYBH(JAXBElement<String> value) {
		this.rybh = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the ryxm property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getRYXM() {
		return ryxm;
	}

	/**
	 * Sets the value of the ryxm property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setRYXM(JAXBElement<String> value) {
		this.ryxm = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the sjc property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getSJC() {
		return sjc;
	}

	/**
	 * Sets the value of the sjc property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setSJC(JAXBElement<String> value) {
		this.sjc = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the yhczzh property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getYHCZZH() {
		return yhczzh;
	}

	/**
	 * Sets the value of the yhczzh property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setYHCZZH(JAXBElement<String> value) {
		this.yhczzh = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the yktkh property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getYKTKH() {
		return yktkh;
	}

	/**
	 * Sets the value of the yktkh property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setYKTKH(JAXBElement<String> value) {
		this.yktkh = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the zp property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getZP() {
		return zp;
	}

	/**
	 * Sets the value of the zp property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setZP(JAXBElement<String> value) {
		this.zp = ((JAXBElement<String>) value);
	}

}
