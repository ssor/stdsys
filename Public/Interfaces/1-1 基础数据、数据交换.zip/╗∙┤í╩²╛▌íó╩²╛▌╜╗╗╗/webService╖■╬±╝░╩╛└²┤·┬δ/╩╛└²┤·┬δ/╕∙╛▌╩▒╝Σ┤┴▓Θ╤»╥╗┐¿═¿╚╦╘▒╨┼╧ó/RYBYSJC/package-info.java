/**
 * ServiceYKTRYXXBYSJC
 * 
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "http://pojo.servgen.das.jeaw.com/xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package RYBYSJC;

