package RYBYSJC;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each Java content interface and Java
 * element interface generated in the RYBYSJC package.
 * <p>
 * An ObjectFactory allows you to programatically construct new instances of the
 * Java representation for XML content. The Java representation of XML content
 * can consist of schema derived interfaces and classes representing the binding
 * of schema type definitions, element declarations and model groups. Factory
 * methods for each of these are provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

	private final static QName _EntityYKTRYXXBYSJCBZ_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "BZ");
	private final static QName _EntityYKTRYXXBYSJCRYXM_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "RYXM");
	private final static QName _EntityYKTRYXXBYSJCYKTKH_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "YKTKH");
	private final static QName _EntityYKTRYXXBYSJCYHCZZH_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "YHCZZH");
	private final static QName _EntityYKTRYXXBYSJCID_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ID");
	private final static QName _EntityYKTRYXXBYSJCSJC_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "SJC");
	private final static QName _EntityYKTRYXXBYSJCRYBH_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "RYBH");
	private final static QName _EntityYKTRYXXBYSJCZP_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ZP");
	private final static QName _EntityYKTRYXXBYSJCKZT_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "KZT");
	private final static QName _ReturnEntityMessage_QNAME = new QName(
			"http://pojo.servgen.das.jeaw.com/xsd", "message");
	private final static QName _ReturnEntityCode_QNAME = new QName(
			"http://pojo.servgen.das.jeaw.com/xsd", "code");
	private final static QName _GetEntityTypeResponseReturn_QNAME = new QName(
			"http://release.service.das.jeaw.com", "return");
	private final static QName _QueryArgs0_QNAME = new QName(
			"http://release.service.das.jeaw.com", "args0");
	private final static QName _ArgumentYKTRYXXBYSJCENDDATE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "ENDDATE");
	private final static QName _ArgumentYKTRYXXBYSJCBEGINDATE_QNAME = new QName(
			"http://release.service.das.jeaw.com/xsd", "BEGINDATE");

	/**
	 * Create a new ObjectFactory that can be used to create new instances of
	 * schema derived classes for package: RYBYSJC
	 * 
	 */
	public ObjectFactory() {
	}

	/**
	 * Create an instance of {@link ParametersPadding }
	 * 
	 */
	public ParametersPadding createParametersPadding() {
		return new ParametersPadding();
	}

	/**
	 * Create an instance of {@link Entity }
	 * 
	 */
	public Entity createEntity() {
		return new Entity();
	}

	/**
	 * Create an instance of {@link EntityYKTRYXXBYSJC }
	 * 
	 */
	public EntityYKTRYXXBYSJC createEntityYKTRYXXBYSJC() {
		return new EntityYKTRYXXBYSJC();
	}

	/**
	 * Create an instance of {@link ReturnEntity }
	 * 
	 */
	public ReturnEntity createReturnEntity() {
		return new ReturnEntity();
	}

	/**
	 * Create an instance of {@link Security }
	 * 
	 */
	public Security createSecurity() {
		return new Security();
	}

	/**
	 * Create an instance of {@link GetEntityTypeResponse }
	 * 
	 */
	public GetEntityTypeResponse createGetEntityTypeResponse() {
		return new GetEntityTypeResponse();
	}

	/**
	 * Create an instance of {@link Query }
	 * 
	 */
	public Query createQuery() {
		return new Query();
	}

	/**
	 * Create an instance of {@link Security.UsernameToken }
	 * 
	 */
	public Security.UsernameToken createSecurityUsernameToken() {
		return new Security.UsernameToken();
	}

	/**
	 * Create an instance of {@link ArgumentYKTRYXXBYSJC }
	 * 
	 */
	public ArgumentYKTRYXXBYSJC createArgumentYKTRYXXBYSJC() {
		return new ArgumentYKTRYXXBYSJC();
	}

	/**
	 * Create an instance of {@link Argument }
	 * 
	 */
	public Argument createArgument() {
		return new Argument();
	}

	/**
	 * Create an instance of {@link QueryResponse }
	 * 
	 */
	public QueryResponse createQueryResponse() {
		return new QueryResponse();
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "BZ", scope = EntityYKTRYXXBYSJC.class)
	public JAXBElement<String> createEntityYKTRYXXBYSJCBZ(String value) {
		return new JAXBElement<String>(_EntityYKTRYXXBYSJCBZ_QNAME,
				String.class, EntityYKTRYXXBYSJC.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "RYXM", scope = EntityYKTRYXXBYSJC.class)
	public JAXBElement<String> createEntityYKTRYXXBYSJCRYXM(String value) {
		return new JAXBElement<String>(_EntityYKTRYXXBYSJCRYXM_QNAME,
				String.class, EntityYKTRYXXBYSJC.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "YKTKH", scope = EntityYKTRYXXBYSJC.class)
	public JAXBElement<String> createEntityYKTRYXXBYSJCYKTKH(String value) {
		return new JAXBElement<String>(_EntityYKTRYXXBYSJCYKTKH_QNAME,
				String.class, EntityYKTRYXXBYSJC.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "YHCZZH", scope = EntityYKTRYXXBYSJC.class)
	public JAXBElement<String> createEntityYKTRYXXBYSJCYHCZZH(String value) {
		return new JAXBElement<String>(_EntityYKTRYXXBYSJCYHCZZH_QNAME,
				String.class, EntityYKTRYXXBYSJC.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ID", scope = EntityYKTRYXXBYSJC.class)
	public JAXBElement<String> createEntityYKTRYXXBYSJCID(String value) {
		return new JAXBElement<String>(_EntityYKTRYXXBYSJCID_QNAME,
				String.class, EntityYKTRYXXBYSJC.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "SJC", scope = EntityYKTRYXXBYSJC.class)
	public JAXBElement<String> createEntityYKTRYXXBYSJCSJC(String value) {
		return new JAXBElement<String>(_EntityYKTRYXXBYSJCSJC_QNAME,
				String.class, EntityYKTRYXXBYSJC.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "RYBH", scope = EntityYKTRYXXBYSJC.class)
	public JAXBElement<String> createEntityYKTRYXXBYSJCRYBH(String value) {
		return new JAXBElement<String>(_EntityYKTRYXXBYSJCRYBH_QNAME,
				String.class, EntityYKTRYXXBYSJC.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ZP", scope = EntityYKTRYXXBYSJC.class)
	public JAXBElement<String> createEntityYKTRYXXBYSJCZP(String value) {
		return new JAXBElement<String>(_EntityYKTRYXXBYSJCZP_QNAME,
				String.class, EntityYKTRYXXBYSJC.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "KZT", scope = EntityYKTRYXXBYSJC.class)
	public JAXBElement<Double> createEntityYKTRYXXBYSJCKZT(Double value) {
		return new JAXBElement<Double>(_EntityYKTRYXXBYSJCKZT_QNAME,
				Double.class, EntityYKTRYXXBYSJC.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://pojo.servgen.das.jeaw.com/xsd", name = "message", scope = ReturnEntity.class)
	public JAXBElement<String> createReturnEntityMessage(String value) {
		return new JAXBElement<String>(_ReturnEntityMessage_QNAME,
				String.class, ReturnEntity.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://pojo.servgen.das.jeaw.com/xsd", name = "code", scope = ReturnEntity.class)
	public JAXBElement<String> createReturnEntityCode(String value) {
		return new JAXBElement<String>(_ReturnEntityCode_QNAME, String.class,
				ReturnEntity.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}
	 * {@link EntityYKTRYXXBYSJC }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = GetEntityTypeResponse.class)
	public JAXBElement<EntityYKTRYXXBYSJC> createGetEntityTypeResponseReturn(
			EntityYKTRYXXBYSJC value) {
		return new JAXBElement<EntityYKTRYXXBYSJC>(
				_GetEntityTypeResponseReturn_QNAME, EntityYKTRYXXBYSJC.class,
				GetEntityTypeResponse.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}
	 * {@link ArgumentYKTRYXXBYSJC }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "args0", scope = Query.class)
	public JAXBElement<ArgumentYKTRYXXBYSJC> createQueryArgs0(
			ArgumentYKTRYXXBYSJC value) {
		return new JAXBElement<ArgumentYKTRYXXBYSJC>(_QueryArgs0_QNAME,
				ArgumentYKTRYXXBYSJC.class, Query.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "ENDDATE", scope = ArgumentYKTRYXXBYSJC.class)
	public JAXBElement<String> createArgumentYKTRYXXBYSJCENDDATE(String value) {
		return new JAXBElement<String>(_ArgumentYKTRYXXBYSJCENDDATE_QNAME,
				String.class, ArgumentYKTRYXXBYSJC.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com/xsd", name = "BEGINDATE", scope = ArgumentYKTRYXXBYSJC.class)
	public JAXBElement<String> createArgumentYKTRYXXBYSJCBEGINDATE(String value) {
		return new JAXBElement<String>(_ArgumentYKTRYXXBYSJCBEGINDATE_QNAME,
				String.class, ArgumentYKTRYXXBYSJC.class, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link ReturnEntity }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://release.service.das.jeaw.com", name = "return", scope = QueryResponse.class)
	public JAXBElement<ReturnEntity> createQueryResponseReturn(
			ReturnEntity value) {
		return new JAXBElement<ReturnEntity>(
				_GetEntityTypeResponseReturn_QNAME, ReturnEntity.class,
				QueryResponse.class, value);
	}

}
