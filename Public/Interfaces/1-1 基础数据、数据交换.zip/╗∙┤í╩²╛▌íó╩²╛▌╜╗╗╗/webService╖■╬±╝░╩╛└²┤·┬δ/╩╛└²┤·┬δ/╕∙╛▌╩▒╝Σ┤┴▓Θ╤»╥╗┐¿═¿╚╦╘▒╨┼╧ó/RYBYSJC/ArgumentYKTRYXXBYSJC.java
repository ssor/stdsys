package RYBYSJC;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for ArgumentYKTRYXXBYSJC complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="ArgumentYKTRYXXBYSJC">
 *   &lt;complexContent>
 *     &lt;extension base="{http://pojo.servgen.das.jeaw.com/xsd}Argument">
 *       &lt;sequence>
 *         &lt;element name="BEGINDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ENDDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArgumentYKTRYXXBYSJC", namespace = "http://release.service.das.jeaw.com/xsd", propOrder = {
		"begindate", "enddate" })
public class ArgumentYKTRYXXBYSJC extends Argument {

	@XmlElementRef(name = "BEGINDATE", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> begindate;
	@XmlElementRef(name = "ENDDATE", namespace = "http://release.service.das.jeaw.com/xsd", type = JAXBElement.class)
	protected JAXBElement<String> enddate;

	/**
	 * Gets the value of the begindate property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getBEGINDATE() {
		return begindate;
	}

	/**
	 * Sets the value of the begindate property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setBEGINDATE(JAXBElement<String> value) {
		this.begindate = ((JAXBElement<String>) value);
	}

	/**
	 * Gets the value of the enddate property.
	 * 
	 * @return possible object is {@link JAXBElement }{@code <}{@link String }
	 *         {@code >}
	 * 
	 */
	public JAXBElement<String> getENDDATE() {
		return enddate;
	}

	/**
	 * Sets the value of the enddate property.
	 * 
	 * @param value
	 *            allowed object is {@link JAXBElement }{@code <}{@link String }
	 *            {@code >}
	 * 
	 */
	public void setENDDATE(JAXBElement<String> value) {
		this.enddate = ((JAXBElement<String>) value);
	}

}
