import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import RYBYSJC.ArgumentYKTRYXXBYSJC;
import RYBYSJC.EntityYKTRYXXBYSJC;
import RYBYSJC.Query;
import RYBYSJC.QueryResponse;
import RYBYSJC.Security;
import RYBYSJC.Security.UsernameToken;
import RYBYSJC.ServiceYKTRYXXBYSJC;
import RYBYSJC.ServiceYKTRYXXBYSJCPortType;


public class testRyBySJC {
	public static void main(String args[]){
		try{
		
			ServiceYKTRYXXBYSJC sp = new ServiceYKTRYXXBYSJC();
			ServiceYKTRYXXBYSJCPortType portType = sp.getServiceYKTRYXXBYSJCHttpSoap11Endpoint();
			
			testQuery(portType);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static JAXBElement<Long> changeLongOfJAXB(String value,String url,String valueName){
		JAXBElement<Long> result = new JAXBElement<Long>(new QName(url,valueName),Long.class,Long.valueOf(value));
		return result;
	}
	public static JAXBElement<String> changeStringOfJAXB(String value,String url,String valueName){
		JAXBElement<String> result = new JAXBElement<String>(new QName(url,valueName),String.class,value);
		return result;
	}
	public static void testQuery(ServiceYKTRYXXBYSJCPortType portType){
		Query parameters = new  Query();	
		
		JAXBElement<String> bjdate = changeStringOfJAXB("2011-07-01","http://release.service.das.jeaw.com/xsd","BEGINDATE");
		JAXBElement<String> enddate = changeStringOfJAXB("2011-07-22","http://release.service.das.jeaw.com/xsd","ENDDATE");
		
		
		ArgumentYKTRYXXBYSJC argument = new ArgumentYKTRYXXBYSJC();
		argument.setBEGINDATE(bjdate);
		argument.setENDDATE(enddate);
		argument.setPage(1);
		argument.setPageSize(100);

		JAXBElement<ArgumentYKTRYXXBYSJC> arg0 = new JAXBElement<ArgumentYKTRYXXBYSJC>(
				new QName("http://release.service.das.jeaw.com", "args0"),
				ArgumentYKTRYXXBYSJC.class, argument);
		
		parameters.setArgs0(arg0);
		
		Security securityHeader = new Security();
		UsernameToken ut = new UsernameToken();
		ut.setUsername("pt.jcsj");
		ut.setPassword("111111");
		securityHeader.setUsernameToken(ut);
		securityHeader.setMustUnderstand(true);

		QueryResponse response = new QueryResponse();

		response = portType.query(parameters, securityHeader);

		List<Object> enlist = response.getReturn().getValue().getResult();
		System.out.println("enlist:"+enlist.size());
		for(Object obj:enlist){
			EntityYKTRYXXBYSJC en = (EntityYKTRYXXBYSJC)obj;	
				System.out.println("ID: "+en.getID().getValue());
				System.out.println("ORGNAME: "+en.getRYBH().getValue());
				System.out.println("ORGCODE: "+en.getRYXM().getValue());
		}
	}
}
