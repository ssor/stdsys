package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "writeBeginOrEndReceiptParam", propOrder = {"auth", "syncType", "syncStatus", "beginOrEndFlag"})
public class WriteBeginOrEndReceiptParam {
	protected AuthEntity auth;
	protected String syncType;
	protected String syncStatus;
	protected String beginOrEndFlag;

	/**
	 * Gets the value of the auth property.
	 * 
	 * @return possible object is {@link AuthEntity }
	 * 
	 */
	public AuthEntity getAuth() {
		return auth;
	}

	/**
	 * Sets the value of the auth property.
	 * 
	 * @param value allowed object is {@link AuthEntity }
	 * 
	 */
	public void setAuth(AuthEntity value) {
		this.auth = value;
	}

	/**
	 * Gets the value of the syncType property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSyncType() {
		return syncType;
	}

	/**
	 * Sets the value of the syncType property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSyncType(String value) {
		this.syncType = value;
	}

	/**
	 * Gets the value of the syncStatus property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSyncStatus() {
		return syncStatus;
	}

	/**
	 * Sets the value of the syncStatus property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSyncStatus(String value) {
		this.syncStatus = value;
	}

	/**
	 * Gets the value of the beginOrEndFlag property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getBeginOrEndFlag() {
		return beginOrEndFlag;
	}

	/**
	 * Sets the value of the beginOrEndFlag property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setBeginOrEndFlag(String value) {
		this.beginOrEndFlag = value;
	}
}