package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "teacherEntity", propOrder = {"jgh", "xm", "xmqp", "xmjp", "ywxm", "cym", "xbm", "mzdm", "zzmmdm",
		"gbdm", "csrq", "zjlx", "zjh", "jg", "zcdm", "zwdm", "xlm", "xwlx", "xwfk", "sjh", "dwdh", "zzdh", "xqh",
		"bmdm", "gzdw", "email", "qq", "msn", "dztm", "lxdz", "yzbm", "zyfxh"})
public class TeacherEntity extends SyncDataEntity {
	protected String jgh;
	protected String xm;
	protected String xmqp;
	protected String xmjp;
	protected String ywxm;
	protected String cym;
	protected String xbm;
	protected String mzdm;
	protected String zzmmdm;
	protected String gbdm;
	protected String csrq;
	protected String zjlx;
	protected String zjh;
	protected String jg;
	protected String zcdm;
	protected String zwdm;
	protected String xlm;
	protected String xwlx;
	protected String xwfk;
	protected String sjh;
	protected String dwdh;
	protected String zzdh;
	protected String xqh;
	protected String bmdm;
	protected String gzdw;
	protected String email;
	protected String qq;
	protected String msn;
	protected String dztm;
	protected String lxdz;
	protected String yzbm;
	protected String zyfxh;

	/**
	 * Gets the value of the jgh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getJgh() {
		return jgh;
	}

	/**
	 * Sets the value of the jgh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setJgh(String value) {
		this.jgh = value;
	}

	/**
	 * Gets the value of the xm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXm() {
		return xm;
	}

	/**
	 * Sets the value of the xm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXm(String value) {
		this.xm = value;
	}

	/**
	 * Gets the value of the xmqp property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXmqp() {
		return xmqp;
	}

	/**
	 * Sets the value of the xmqp property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXmqp(String value) {
		this.xmqp = value;
	}

	/**
	 * Gets the value of the xmjp property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXmjp() {
		return xmjp;
	}

	/**
	 * Sets the value of the xmjp property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXmjp(String value) {
		this.xmjp = value;
	}

	/**
	 * Gets the value of the ywxm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getYwxm() {
		return ywxm;
	}

	/**
	 * Sets the value of the ywxm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setYwxm(String value) {
		this.ywxm = value;
	}

	/**
	 * Gets the value of the cym property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCym() {
		return cym;
	}

	/**
	 * Sets the value of the cym property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setCym(String value) {
		this.cym = value;
	}

	/**
	 * Gets the value of the xbm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXbm() {
		return xbm;
	}

	/**
	 * Sets the value of the xbm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXbm(String value) {
		this.xbm = value;
	}

	/**
	 * Gets the value of the mzdm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMzdm() {
		return mzdm;
	}

	/**
	 * Sets the value of the mzdm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setMzdm(String value) {
		this.mzdm = value;
	}

	/**
	 * Gets the value of the zzmmdm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZzmmdm() {
		return zzmmdm;
	}

	/**
	 * Sets the value of the zzmmdm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setZzmmdm(String value) {
		this.zzmmdm = value;
	}

	/**
	 * Gets the value of the gbdm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getGbdm() {
		return gbdm;
	}

	/**
	 * Sets the value of the gbdm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setGbdm(String value) {
		this.gbdm = value;
	}

	/**
	 * Gets the value of the csrq property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCsrq() {
		return csrq;
	}

	/**
	 * Sets the value of the csrq property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setCsrq(String value) {
		this.csrq = value;
	}

	/**
	 * Gets the value of the zjlx property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZjlx() {
		return zjlx;
	}

	/**
	 * Sets the value of the zjlx property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setZjlx(String value) {
		this.zjlx = value;
	}

	/**
	 * Gets the value of the zjh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZjh() {
		return zjh;
	}

	/**
	 * Sets the value of the zjh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setZjh(String value) {
		this.zjh = value;
	}

	/**
	 * Gets the value of the jg property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getJg() {
		return jg;
	}

	/**
	 * Sets the value of the jg property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setJg(String value) {
		this.jg = value;
	}

	/**
	 * Gets the value of the zcdm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZcdm() {
		return zcdm;
	}

	/**
	 * Sets the value of the zcdm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setZcdm(String value) {
		this.zcdm = value;
	}

	/**
	 * Gets the value of the zwdm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZwdm() {
		return zwdm;
	}

	/**
	 * Sets the value of the zwdm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setZwdm(String value) {
		this.zwdm = value;
	}

	/**
	 * Gets the value of the xlm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXlm() {
		return xlm;
	}

	/**
	 * Sets the value of the xlm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXlm(String value) {
		this.xlm = value;
	}

	/**
	 * Gets the value of the xwlx property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXwlx() {
		return xwlx;
	}

	/**
	 * Sets the value of the xwlx property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXwlx(String value) {
		this.xwlx = value;
	}

	/**
	 * Gets the value of the xwfk property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXwfk() {
		return xwfk;
	}

	/**
	 * Sets the value of the xwfk property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXwfk(String value) {
		this.xwfk = value;
	}

	/**
	 * Gets the value of the sjh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSjh() {
		return sjh;
	}

	/**
	 * Sets the value of the sjh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSjh(String value) {
		this.sjh = value;
	}

	/**
	 * Gets the value of the dwdh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDwdh() {
		return dwdh;
	}

	/**
	 * Sets the value of the dwdh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setDwdh(String value) {
		this.dwdh = value;
	}

	/**
	 * Gets the value of the zzdh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZzdh() {
		return zzdh;
	}

	/**
	 * Sets the value of the zzdh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setZzdh(String value) {
		this.zzdh = value;
	}

	/**
	 * Gets the value of the xqh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXqh() {
		return xqh;
	}

	/**
	 * Sets the value of the xqh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXqh(String value) {
		this.xqh = value;
	}

	/**
	 * Gets the value of the bmdm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getBmdm() {
		return bmdm;
	}

	/**
	 * Sets the value of the bmdm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setBmdm(String value) {
		this.bmdm = value;
	}

	/**
	 * Gets the value of the gzdw property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getGzdw() {
		return gzdw;
	}

	/**
	 * Sets the value of the gzdw property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setGzdw(String value) {
		this.gzdw = value;
	}

	/**
	 * Gets the value of the email property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the value of the email property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setEmail(String value) {
		this.email = value;
	}

	/**
	 * Gets the value of the qq property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getQq() {
		return qq;
	}

	/**
	 * Sets the value of the qq property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setQq(String value) {
		this.qq = value;
	}

	/**
	 * Gets the value of the msn property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMsn() {
		return msn;
	}

	/**
	 * Sets the value of the msn property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setMsn(String value) {
		this.msn = value;
	}

	/**
	 * Gets the value of the dztm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDztm() {
		return dztm;
	}

	/**
	 * Sets the value of the dztm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setDztm(String value) {
		this.dztm = value;
	}

	/**
	 * Gets the value of the lxdz property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getLxdz() {
		return lxdz;
	}

	/**
	 * Sets the value of the lxdz property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setLxdz(String value) {
		this.lxdz = value;
	}

	/**
	 * Gets the value of the yzbm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getYzbm() {
		return yzbm;
	}

	/**
	 * Sets the value of the yzbm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setYzbm(String value) {
		this.yzbm = value;
	}

	/**
	 * Gets the value of the zyfxh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZyfxh() {
		return zyfxh;
	}

	/**
	 * Sets the value of the zyfxh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setZyfxh(String value) {
		this.zyfxh = value;
	}
}