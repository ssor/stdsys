package com.jeaw.sso.intersys.datasync.client;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateSyncDataResult", propOrder = {"code", "message", "receipts"})
public class UpdateSyncDataResult {
	protected String code;
	protected String message;
	protected UpdateSyncDataResult.Receipts receipts;

	/**
	 * Gets the value of the code property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Sets the value of the code property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setCode(String value) {
		this.code = value;
	}

	/**
	 * Gets the value of the message property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the value of the message property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setMessage(String value) {
		this.message = value;
	}

	/**
	 * Gets the value of the syncDatas property.
	 * 
	 * @return possible object is {@link List<String> }
	 * 
	 */
	public List<ReceiptEntity> getReceipts() {
		if (receipts != null) {
			return receipts.getReceipt();
		}
		return new ArrayList<ReceiptEntity>();
	}

	public void addReceipt(ReceiptEntity entity) {
		if (receipts == null) {
			receipts = new Receipts();
		}
		receipts.getReceipt().add(entity);
	}

	public void addReceipts(List<ReceiptEntity> entities) {
		if (receipts == null) {
			receipts = new Receipts();
		}
		receipts.getReceipt().addAll(entities);
	}

	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "", propOrder = {"receipt"})
	public static class Receipts {
		protected List<ReceiptEntity> receipt;

		public List<ReceiptEntity> getReceipt() {
			if (receipt == null) {
				receipt = new ArrayList<ReceiptEntity>();
			}
			return this.receipt;
		}
	}
}