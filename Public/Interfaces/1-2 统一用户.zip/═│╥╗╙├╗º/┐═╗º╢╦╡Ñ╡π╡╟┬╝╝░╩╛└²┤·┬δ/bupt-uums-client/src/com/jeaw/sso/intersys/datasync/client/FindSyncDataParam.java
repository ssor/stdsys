package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "findSyncDataParam", propOrder = {"auth", "page", "syncType", "objectCode"})
public class FindSyncDataParam {
	protected AuthEntity auth;
	protected PageEntity page;
	protected String syncType;
	protected String objectCode;

	/**
	 * Gets the value of the auth property.
	 * 
	 * @return possible object is {@link AuthEntity }
	 * 
	 */
	public AuthEntity getAuth() {
		return auth;
	}

	/**
	 * Sets the value of the auth property.
	 * 
	 * @param value allowed object is {@link AuthEntity }
	 * 
	 */
	public void setAuth(AuthEntity value) {
		this.auth = value;
	}

	/**
	 * Gets the value of the page property.
	 * 
	 * @return possible object is {@link PageEntity }
	 * 
	 */
	public PageEntity getPage() {
		return page;
	}

	/**
	 * Sets the value of the page property.
	 * 
	 * @param value allowed object is {@link PageEntity }
	 * 
	 */
	public void setPage(PageEntity value) {
		this.page = value;
	}

	/**
	 * Gets the value of the syncType property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSyncType() {
		return syncType;
	}

	/**
	 * Sets the value of the syncType property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSyncType(String value) {
		this.syncType = value;
	}

	/**
	 * Gets the value of the objectCode property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getObjectCode() {
		return objectCode;
	}

	/**
	 * Sets the value of the objectCode property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setObjectCode(String value) {
		this.objectCode = value;
	}
}