package com.jeaw.sso.intersys.datasync.client;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import javax.xml.ws.WebEndpoint;
import javax.xml.ws.WebServiceClient;
import javax.xml.ws.WebServiceFeature;

import com.jeaw.sso.commons.util.Configer;

@WebServiceClient(name = "SSODataSyncService", targetNamespace = "http://www.jeaw.com/sso")
public class SSODataSyncServiceImpl extends Service {
	public final static QName QNAME_SERVICE_NAME = new QName("http://www.jeaw.com/sso", "SSODataSyncService");
	public final static QName QNAME_SERVICE_PORT_NAME = new QName("http://www.jeaw.com/sso", "SSODataSyncServicePort");
	private static URL wsdlLocation = null;

	static {
		String ssoServerUrl = Configer.getString("ssoServerUrl");

		try {
			wsdlLocation = new URL(ssoServerUrl + "/cxfws/ssoDataSync?wsdl");
		} catch (MalformedURLException e) {
			System.err.println("Can not initialize ssoDataSync wsdl from " + ssoServerUrl + "/cxfws/ssoDataSync?wsdl");
			e.printStackTrace();
		}
	}

	public SSODataSyncServiceImpl() {
		super(wsdlLocation, QNAME_SERVICE_NAME);
	}

	@WebEndpoint(name = "SSODataSyncServicePort")
	public SSODataSyncService getSSODataSyncServicePort() {
		return super.getPort(QNAME_SERVICE_PORT_NAME, SSODataSyncService.class);
	}

	@WebEndpoint(name = "SSODataSyncServicePort")
	public SSODataSyncService getSSODataSyncServicePort(WebServiceFeature... features) {
		return super.getPort(QNAME_SERVICE_PORT_NAME, SSODataSyncService.class, features);
	}
}