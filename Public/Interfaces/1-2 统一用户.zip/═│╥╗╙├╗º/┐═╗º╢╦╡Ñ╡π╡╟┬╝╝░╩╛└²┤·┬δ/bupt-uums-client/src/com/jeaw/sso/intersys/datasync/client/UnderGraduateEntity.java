package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "underGraduateEntity", propOrder = {"xh", "xm", "xmqp", "xmjp", "ywxm", "cym", "zjlx", "zjh", "xbm",
		"xslbdm", "sflbdm", "mzdm", "jg", "csrq", "zzmmdm", "kqh", "byzx", "gkzf", "lqh", "gkksh", "rxksyz", "lxdz",
		"yb", "jzxx", "rxrq", "yxsh", "zyh", "zyfxh", "nj", "bjh", "sfyxj", "sfygjxj", "xqh", "ydf", "dztm", "sjhm",
		"sslh", "fjh", "ssdh", "email", "qq", "msn", "tz", "sg", "hcz"})
public class UnderGraduateEntity extends SyncDataEntity {
	protected String xh;
	protected String xm;
	protected String xmqp;
	protected String xmjp;
	protected String ywxm;
	protected String cym;
	protected String zjlx;
	protected String zjh;
	protected String xbm;
	protected String xslbdm;
	protected String sflbdm;
	protected String mzdm;
	protected String jg;
	protected String csrq;
	protected String zzmmdm;
	protected String kqh;
	protected String byzx;
	protected Float gkzf;
	protected String lqh;
	protected String gkksh;
	protected String rxksyz;
	protected String lxdz;
	protected String yb;
	protected String jzxx;
	protected String rxrq;
	protected String yxsh;
	protected String zyh;
	protected String zyfxh;
	protected String nj;
	protected String bjh;
	protected String sfyxj;
	protected String sfygjxj;
	protected String xqh;
	protected String ydf;
	protected String dztm;
	protected String sjhm;
	protected String sslh;
	protected String fjh;
	protected String ssdh;
	protected String email;
	protected String qq;
	protected String msn;
	protected Float tz;
	protected Float sg;
	protected String hcz;

	/**
	 * Gets the value of the xh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXh() {
		return xh;
	}

	/**
	 * Sets the value of the xh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXh(String value) {
		this.xh = value;
	}

	/**
	 * Gets the value of the xm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXm() {
		return xm;
	}

	/**
	 * Sets the value of the xm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXm(String value) {
		this.xm = value;
	}

	/**
	 * Gets the value of the xmqp property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXmqp() {
		return xmqp;
	}

	/**
	 * Sets the value of the xmqp property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXmqp(String value) {
		this.xmqp = value;
	}

	/**
	 * Gets the value of the xmjp property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXmjp() {
		return xmjp;
	}

	/**
	 * Sets the value of the xmjp property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXmjp(String value) {
		this.xmjp = value;
	}

	/**
	 * Gets the value of the ywxm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getYwxm() {
		return ywxm;
	}

	/**
	 * Sets the value of the ywxm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setYwxm(String value) {
		this.ywxm = value;
	}

	/**
	 * Gets the value of the cym property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCym() {
		return cym;
	}

	/**
	 * Sets the value of the cym property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setCym(String value) {
		this.cym = value;
	}

	/**
	 * Gets the value of the zjlx property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZjlx() {
		return zjlx;
	}

	/**
	 * Sets the value of the zjlx property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setZjlx(String value) {
		this.zjlx = value;
	}

	/**
	 * Gets the value of the zjh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZjh() {
		return zjh;
	}

	/**
	 * Sets the value of the zjh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setZjh(String value) {
		this.zjh = value;
	}

	/**
	 * Gets the value of the xbm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXbm() {
		return xbm;
	}

	/**
	 * Sets the value of the xbm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXbm(String value) {
		this.xbm = value;
	}

	/**
	 * Gets the value of the xslbdm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXslbdm() {
		return xslbdm;
	}

	/**
	 * Sets the value of the xslbdm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXslbdm(String value) {
		this.xslbdm = value;
	}

	/**
	 * Gets the value of the sflbdm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSflbdm() {
		return sflbdm;
	}

	/**
	 * Sets the value of the sflbdm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSflbdm(String value) {
		this.sflbdm = value;
	}

	/**
	 * Gets the value of the mzdm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMzdm() {
		return mzdm;
	}

	/**
	 * Sets the value of the mzdm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setMzdm(String value) {
		this.mzdm = value;
	}

	/**
	 * Gets the value of the jg property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getJg() {
		return jg;
	}

	/**
	 * Sets the value of the jg property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setJg(String value) {
		this.jg = value;
	}

	/**
	 * Gets the value of the csrq property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCsrq() {
		return csrq;
	}

	/**
	 * Sets the value of the csrq property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setCsrq(String value) {
		this.csrq = value;
	}

	/**
	 * Gets the value of the zzmmdm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZzmmdm() {
		return zzmmdm;
	}

	/**
	 * Sets the value of the zzmmdm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setZzmmdm(String value) {
		this.zzmmdm = value;
	}

	/**
	 * Gets the value of the kqh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getKqh() {
		return kqh;
	}

	/**
	 * Sets the value of the kqh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setKqh(String value) {
		this.kqh = value;
	}

	/**
	 * Gets the value of the byzx property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getByzx() {
		return byzx;
	}

	/**
	 * Sets the value of the byzx property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setByzx(String value) {
		this.byzx = value;
	}

	/**
	 * Gets the value of the gkzf property.
	 * 
	 * @return possible object is {@link Float }
	 * 
	 */
	public Float getGkzf() {
		return gkzf;
	}

	/**
	 * Sets the value of the gkzf property.
	 * 
	 * @param value allowed object is {@link Float }
	 * 
	 */
	public void setGkzf(Float value) {
		this.gkzf = value;
	}

	/**
	 * Gets the value of the lqh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getLqh() {
		return lqh;
	}

	/**
	 * Sets the value of the lqh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setLqh(String value) {
		this.lqh = value;
	}

	/**
	 * Gets the value of the gkksh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getGkksh() {
		return gkksh;
	}

	/**
	 * Sets the value of the gkksh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setGkksh(String value) {
		this.gkksh = value;
	}

	/**
	 * Gets the value of the rxksyz property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getRxksyz() {
		return rxksyz;
	}

	/**
	 * Sets the value of the rxksyz property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setRxksyz(String value) {
		this.rxksyz = value;
	}

	/**
	 * Gets the value of the lxdz property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getLxdz() {
		return lxdz;
	}

	/**
	 * Sets the value of the lxdz property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setLxdz(String value) {
		this.lxdz = value;
	}

	/**
	 * Gets the value of the yb property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getYb() {
		return yb;
	}

	/**
	 * Sets the value of the yb property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setYb(String value) {
		this.yb = value;
	}

	/**
	 * Gets the value of the jzxx property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getJzxx() {
		return jzxx;
	}

	/**
	 * Sets the value of the jzxx property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setJzxx(String value) {
		this.jzxx = value;
	}

	/**
	 * Gets the value of the rxrq property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getRxrq() {
		return rxrq;
	}

	/**
	 * Sets the value of the rxrq property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setRxrq(String value) {
		this.rxrq = value;
	}

	/**
	 * Gets the value of the yxsh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getYxsh() {
		return yxsh;
	}

	/**
	 * Sets the value of the yxsh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setYxsh(String value) {
		this.yxsh = value;
	}

	/**
	 * Gets the value of the zyh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZyh() {
		return zyh;
	}

	/**
	 * Sets the value of the zyh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setZyh(String value) {
		this.zyh = value;
	}

	/**
	 * Gets the value of the zyfxh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZyfxh() {
		return zyfxh;
	}

	/**
	 * Sets the value of the zyfxh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setZyfxh(String value) {
		this.zyfxh = value;
	}

	/**
	 * Gets the value of the nj property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getNj() {
		return nj;
	}

	/**
	 * Sets the value of the nj property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setNj(String value) {
		this.nj = value;
	}

	/**
	 * Gets the value of the bjh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getBjh() {
		return bjh;
	}

	/**
	 * Sets the value of the bjh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setBjh(String value) {
		this.bjh = value;
	}

	/**
	 * Gets the value of the sfyxj property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSfyxj() {
		return sfyxj;
	}

	/**
	 * Sets the value of the sfyxj property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSfyxj(String value) {
		this.sfyxj = value;
	}

	/**
	 * Gets the value of the sfygjxj property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSfygjxj() {
		return sfygjxj;
	}

	/**
	 * Sets the value of the sfygjxj property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSfygjxj(String value) {
		this.sfygjxj = value;
	}

	/**
	 * Gets the value of the xqh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getXqh() {
		return xqh;
	}

	/**
	 * Sets the value of the xqh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setXqh(String value) {
		this.xqh = value;
	}

	/**
	 * Gets the value of the ydf property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getYdf() {
		return ydf;
	}

	/**
	 * Sets the value of the ydf property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setYdf(String value) {
		this.ydf = value;
	}

	/**
	 * Gets the value of the dztm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDztm() {
		return dztm;
	}

	/**
	 * Sets the value of the dztm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setDztm(String value) {
		this.dztm = value;
	}

	/**
	 * Gets the value of the sjhm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSjhm() {
		return sjhm;
	}

	/**
	 * Sets the value of the sjhm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSjhm(String value) {
		this.sjhm = value;
	}

	/**
	 * Gets the value of the sslh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSslh() {
		return sslh;
	}

	/**
	 * Sets the value of the sslh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSslh(String value) {
		this.sslh = value;
	}

	/**
	 * Gets the value of the fjh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getFjh() {
		return fjh;
	}

	/**
	 * Sets the value of the fjh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setFjh(String value) {
		this.fjh = value;
	}

	/**
	 * Gets the value of the ssdh property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSsdh() {
		return ssdh;
	}

	/**
	 * Sets the value of the ssdh property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSsdh(String value) {
		this.ssdh = value;
	}

	/**
	 * Gets the value of the email property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the value of the email property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setEmail(String value) {
		this.email = value;
	}

	/**
	 * Gets the value of the qq property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getQq() {
		return qq;
	}

	/**
	 * Sets the value of the qq property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setQq(String value) {
		this.qq = value;
	}

	/**
	 * Gets the value of the msn property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMsn() {
		return msn;
	}

	/**
	 * Sets the value of the msn property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setMsn(String value) {
		this.msn = value;
	}

	/**
	 * Gets the value of the tz property.
	 * 
	 * @return possible object is {@link Float }
	 * 
	 */
	public Float getTz() {
		return tz;
	}

	/**
	 * Sets the value of the tz property.
	 * 
	 * @param value allowed object is {@link Float }
	 * 
	 */
	public void setTz(Float value) {
		this.tz = value;
	}

	/**
	 * Gets the value of the sg property.
	 * 
	 * @return possible object is {@link Float }
	 * 
	 */
	public Float getSg() {
		return sg;
	}

	/**
	 * Sets the value of the sg property.
	 * 
	 * @param value allowed object is {@link Float }
	 * 
	 */
	public void setSg(Float value) {
		this.sg = value;
	}

	/**
	 * Gets the value of the hcz property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getHcz() {
		return hcz;
	}

	/**
	 * Sets the value of the hcz property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setHcz(String value) {
		this.hcz = value;
	}
}