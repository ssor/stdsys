package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "syncDataEntity", propOrder = {"syncInfoId", "description", "operateFlag"})
public class SyncDataEntity {
	protected String syncInfoId;
	protected String description;
	protected String operateFlag;

	/**
	 * Gets the value of the syncInfoId property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSyncInfoId() {
		return syncInfoId;
	}

	/**
	 * Sets the value of the syncInfoId property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSyncInfoId(String value) {
		this.syncInfoId = value;
	}

	/**
	 * Gets the value of the description property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the value of the description property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setDescription(String value) {
		this.description = value;
	}

	/**
	 * Gets the value of the operateFlag property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getOperateFlag() {
		return operateFlag;
	}

	/**
	 * Sets the value of the operateFlag property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setOperateFlag(String value) {
		this.operateFlag = value;
	}
}