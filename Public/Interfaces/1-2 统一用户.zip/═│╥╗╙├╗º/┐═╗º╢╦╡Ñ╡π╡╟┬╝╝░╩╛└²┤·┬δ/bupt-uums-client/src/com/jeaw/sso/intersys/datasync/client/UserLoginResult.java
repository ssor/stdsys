package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "userLoginResult", propOrder = {"code", "message", "appsyses"})
public class UserLoginResult {
	protected String code;
	protected String message;
	protected String appsyses;

	/**
	 * Gets the value of the code property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Sets the value of the code property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setCode(String value) {
		this.code = value;
	}

	/**
	 * Gets the value of the message property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the value of the message property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setMessage(String value) {
		this.message = value;
	}

	/**
	 * Gets the value of the appsyses property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getAppsyses() {
		return appsyses;
	}

	/**
	 * Sets the value of the appsyses property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setAppsyses(String value) {
		this.appsyses = value;
	}
}