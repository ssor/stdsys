package com.jeaw.sso.intersys.datasync.client;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateSyncDataParam", propOrder = {"auth", "syncType", "syncDatas"})
public class UpdateSyncDataParam {
	protected AuthEntity auth;
	protected String syncType;
	protected UpdateSyncDataParam.SyncDatas syncDatas;

	/**
	 * Gets the value of the auth property.
	 * 
	 * @return possible object is {@link AuthEntity }
	 * 
	 */
	public AuthEntity getAuth() {
		return auth;
	}

	/**
	 * Sets the value of the auth property.
	 * 
	 * @param value allowed object is {@link AuthEntity }
	 * 
	 */
	public void setAuth(AuthEntity value) {
		this.auth = value;
	}

	/**
	 * Gets the value of the syncType property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSyncType() {
		return syncType;
	}

	/**
	 * Sets the value of the syncType property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSyncType(String value) {
		this.syncType = value;
	}

	/**
	 * Gets the value of the syncDatas property.
	 * 
	 * @return possible object is {@link List<String> }
	 * 
	 */
	public List<SyncDataEntity> getSyncDatas() {
		if (syncDatas != null) {
			return syncDatas.getSyncData();
		}
		return new ArrayList<SyncDataEntity>();
	}

	public void addSyncData(SyncDataEntity entity) {
		if (syncDatas == null) {
			syncDatas = new SyncDatas();
		}
		syncDatas.getSyncData().add(entity);
	}

	public void addSyncDatas(List<SyncDataEntity> entities) {
		if (syncDatas == null) {
			syncDatas = new SyncDatas();
		}
		syncDatas.getSyncData().addAll(entities);
	}

	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "", propOrder = {"syncData"})
	public static class SyncDatas {
		protected List<SyncDataEntity> syncData;

		public List<SyncDataEntity> getSyncData() {
			if (syncData == null) {
				syncData = new ArrayList<SyncDataEntity>();
			}
			return this.syncData;
		}
	}
}