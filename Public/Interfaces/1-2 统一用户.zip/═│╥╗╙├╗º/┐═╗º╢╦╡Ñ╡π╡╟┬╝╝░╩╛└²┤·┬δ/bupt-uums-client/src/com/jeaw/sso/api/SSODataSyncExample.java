package com.jeaw.sso.api;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.jeaw.sso.intersys.datasync.client.AttachEntity;
import com.jeaw.sso.intersys.datasync.client.AuthEntity;
import com.jeaw.sso.intersys.datasync.client.BarcodeEntity;
import com.jeaw.sso.intersys.datasync.client.ChangePasswdParam;
import com.jeaw.sso.intersys.datasync.client.ChangePasswdResult;
import com.jeaw.sso.intersys.datasync.client.FindAppsysAuthParam;
import com.jeaw.sso.intersys.datasync.client.FindAppsysAuthResult;
import com.jeaw.sso.intersys.datasync.client.FindSyncDataParam;
import com.jeaw.sso.intersys.datasync.client.FindSyncDataResult;
import com.jeaw.sso.intersys.datasync.client.ForgotPasswdParam;
import com.jeaw.sso.intersys.datasync.client.ForgotPasswdResult;
import com.jeaw.sso.intersys.datasync.client.GraduateEntity;
import com.jeaw.sso.intersys.datasync.client.OrgEntity;
import com.jeaw.sso.intersys.datasync.client.PageEntity;
import com.jeaw.sso.intersys.datasync.client.PhotoEntity;
import com.jeaw.sso.intersys.datasync.client.ReceiptEntity;
import com.jeaw.sso.intersys.datasync.client.SyncDataEntity;
import com.jeaw.sso.intersys.datasync.client.TeacherEntity;
import com.jeaw.sso.intersys.datasync.client.UnderGraduateEntity;
import com.jeaw.sso.intersys.datasync.client.UpdateSyncDataParam;
import com.jeaw.sso.intersys.datasync.client.UpdateSyncDataResult;
import com.jeaw.sso.intersys.datasync.client.UserLoginParam;
import com.jeaw.sso.intersys.datasync.client.UserLoginResult;
import com.jeaw.sso.intersys.datasync.client.WriteBeginOrEndReceiptParam;
import com.jeaw.sso.intersys.datasync.client.WriteIncrReceiptParam;

public class SSODataSyncExample {
	public void findFullUser() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		FindSyncDataParam findFullUserParam = new FindSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		findFullUserParam.setAuth(authEntity);

		// 必设参数：分页信息。
		PageEntity pageEntity = new PageEntity();
		// 必设参数：页码，从0开始。
		pageEntity.setPageNumber(0);
		// 必设参数：每页记录条数。
		pageEntity.setPageSize(500);
		findFullUserParam.setPage(pageEntity);

		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询全量本科生（0101）、查询全量研究生（0102）、查询全量教职工（0103）。
		findFullUserParam.setSyncType("0101");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询全量本科生（0101）、查询全量研究生（0102）、查询全量教职工（0103）。
		writeBeginOrEndReceiptParam.setSyncType("0101");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 查询并处理数据，直到没有查询到数据为止。
		int pageNumber = 0;
		while (true) {
			// 每次处理完成，需要设置为下一页，直到最后没有查到数据为止。
			pageEntity.setPageNumber(pageNumber++);
			findFullUserParam.setPage(pageEntity);

			// 执行查询。
			FindSyncDataResult result = ssoDataSync.findFullUser(findFullUserParam);

			// 迭代处理查询结果。
			if (result.getSyncDatas() != null && result.getSyncDatas().size() > 0) {
				List<SyncDataEntity> syncDataEntities = result.getSyncDatas();
				for (SyncDataEntity syncDataEntity : syncDataEntities) {
					// 将查询结果转换为本科生（UnderGraduateEntity）、研究生（GraduateEntity）、教职工（TeacherEntity）。
					UnderGraduateEntity underGraduateEntity = (UnderGraduateEntity)syncDataEntity;

					// 将数据保存到本地，保存时需要主意：
					// 1、如果系统中存在该信息，则执行更新操作，否则执行增加操作。
					// 2、对于一批同步的数据需要做好统一标记，能够标识数据是一批处理的，以区分出哪些数据是同步而来，哪些数据是系统原有的。
					// 3、？？？对于系统中已有的数据，但不在本次全量同步中，如何处理，需要由各系统决定，是删除还是做好标记保留在系统中。？？？
				}
			} else {
				// 没查找到数据，跳出本次调用。
				break;
			}
		}

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询全量本科生（0101）、查询全量研究生（0102）、查询全量教职工（0103）。
		writeBeginOrEndReceiptParam.setSyncType("0101");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////
	}

	public void findIncrUser() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		FindSyncDataParam findIncrUserParam = new FindSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		findIncrUserParam.setAuth(authEntity);

		// 必设参数：分页信息。
		PageEntity pageEntity = new PageEntity();
		// 必设参数：页码，从0开始。
		pageEntity.setPageNumber(0);
		// 必设参数：每页记录条数。
		pageEntity.setPageSize(500);
		findIncrUserParam.setPage(pageEntity);

		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询增量本科生（0201）、查询增量研究生（0202）、查询增量教职工（0203）。
		findIncrUserParam.setSyncType("0201");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询增量本科生（0201）、查询增量研究生（0202）、查询增量教职工（0203）。
		writeBeginOrEndReceiptParam.setSyncType("0201");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 查询并处理数据，直到没有查询到数据为止。
		while (true) {
			// 执行查询。
			FindSyncDataResult result = ssoDataSync.findIncrUser(findIncrUserParam);

			// 迭代处理查询结果。
			if (result.getSyncDatas() != null && result.getSyncDatas().size() > 0) {
				List<ReceiptEntity> eachReceipts = new ArrayList<ReceiptEntity>();
				List<SyncDataEntity> syncDataEntities = result.getSyncDatas();
				for (SyncDataEntity syncDataEntity : syncDataEntities) {
					// 将查询结果转换为本科生（UnderGraduateEntity）、研究生（GraduateEntity）、教职工（TeacherEntity）。
					UnderGraduateEntity underGraduateEntity = (UnderGraduateEntity)syncDataEntity;

					// 将数据保存到本地，保存时需要主意：
					// 1、如果系统中存在该信息，则执行更新操作，否则执行增加操作。
					// 2、如果是删除操作，系统中不存在该信息，则直接返回，否则执行删除操作。
					// 3、对于一批同步的数据需要做好统一标记，能够标识数据是一批处理的，以区分出哪些数据是同步而来，哪些数据是系统原有的。
					// 4、增量数据同步除了记录开始和结束同步回执外，还需要记录增量回执。

					// 处理时，需要记录处理是否成功的回执。
					ReceiptEntity receiptEntity = new ReceiptEntity();
					// 必设参数：0：失败，1：成功
					receiptEntity.setCode("1");
					// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
					// 查询增量本科生（0201）、查询增量研究生（0202）、查询增量教职工（0203）。
					receiptEntity.setSyncType("0201");
					// 必设参数：来自查询结果。
					receiptEntity.setSyncInfoId(underGraduateEntity.getSyncInfoId());
					receiptEntity.setMessage("可选内容");
					eachReceipts.add(receiptEntity);
				}

				// 处理回执。
				WriteIncrReceiptParam writeIncrReceiptParam = new WriteIncrReceiptParam();
				writeIncrReceiptParam.setAuth(authEntity);
				writeIncrReceiptParam.addReceipts(eachReceipts);
				ssoDataSync.writeIncrReceipt(writeIncrReceiptParam);
			} else {
				// 没查找到数据，跳出本次调用。
				break;
			}
		}

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询增量本科生（0201）、查询增量研究生（0202）、查询增量教职工（0203）。
		writeBeginOrEndReceiptParam.setSyncType("0201");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////
	}

	public void findFullPhoto() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		FindSyncDataParam findFullPhotoParam = new FindSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		findFullPhotoParam.setAuth(authEntity);

		// 必设参数：分页信息。
		PageEntity pageEntity = new PageEntity();
		// 必设参数：页码，从0开始。
		pageEntity.setPageNumber(0);
		// 必设参数：每页记录条数。
		pageEntity.setPageSize(100);
		findFullPhotoParam.setPage(pageEntity);

		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询全量本科生照片（0301）、查询全量研究生照片（0302）、查询全量教职工照片（0303）。
		findFullPhotoParam.setSyncType("0301");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询全量本科生照片（0301）、查询全量研究生照片（0302）、查询全量教职工照片（0303）。
		writeBeginOrEndReceiptParam.setSyncType("0301");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 查询并处理数据，直到没有查询到数据为止。
		int pageNumber = 0;
		while (true) {
			// 每次处理完成，需要设置为下一页，直到最后没有查到数据为止。
			pageEntity.setPageNumber(pageNumber++);
			findFullPhotoParam.setPage(pageEntity);

			// 执行查询。
			FindSyncDataResult result = ssoDataSync.findFullPhoto(findFullPhotoParam);

			// 迭代处理查询结果。
			if (result.getSyncDatas() != null && result.getSyncDatas().size() > 0) {
				List<SyncDataEntity> syncDataEntities = result.getSyncDatas();
				for (SyncDataEntity syncDataEntity : syncDataEntities) {
					// 将查询结果转换为照片（PhotoEntity）。
					PhotoEntity photoEntity = (PhotoEntity)syncDataEntity;

					// 将数据保存到本地，保存时需要主意：
					// 1、如果系统中存在该信息，则执行更新操作，否则执行增加操作。
					// 2、对于一批同步的数据需要做好统一标记，能够标识数据是一批处理的，以区分出哪些数据是同步而来，哪些数据是系统原有的。
					// 3、？？？对于系统中已有的数据，但不在本次全量同步中，如何处理，需要由各系统决定，是删除还是做好标记保留在系统中。？？？
				}
			} else {
				// 没查找到数据，跳出本次调用。
				break;
			}
		}

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询全量本科生照片（0301）、查询全量研究生照片（0302）、查询全量教职工照片（0303）。
		writeBeginOrEndReceiptParam.setSyncType("0301");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////
	}

	public void findIncrPhoto() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		FindSyncDataParam findIncrPhotoParam = new FindSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		findIncrPhotoParam.setAuth(authEntity);

		// 必设参数：分页信息。
		PageEntity pageEntity = new PageEntity();
		// 必设参数：页码，从0开始。
		pageEntity.setPageNumber(0);
		// 必设参数：每页记录条数。
		pageEntity.setPageSize(100);
		findIncrPhotoParam.setPage(pageEntity);

		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询增量本科生照片（0401）、查询增量研究生照片（0402）、查询增量教职工照片（0403）。
		findIncrPhotoParam.setSyncType("0401");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询增量本科生照片（0401）、查询增量研究生照片（0402）、查询增量教职工照片（0403）。
		writeBeginOrEndReceiptParam.setSyncType("0401");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 查询并处理数据，直到没有查询到数据为止。
		while (true) {
			// 执行查询。
			FindSyncDataResult result = ssoDataSync.findIncrPhoto(findIncrPhotoParam);

			// 迭代处理查询结果。
			if (result.getSyncDatas() != null && result.getSyncDatas().size() > 0) {
				List<ReceiptEntity> eachReceipts = new ArrayList<ReceiptEntity>();
				List<SyncDataEntity> syncDataEntities = result.getSyncDatas();
				for (SyncDataEntity syncDataEntity : syncDataEntities) {
					// 将查询结果转换为照片（PhotoEntity）。
					PhotoEntity photoEntity = (PhotoEntity)syncDataEntity;

					// 将数据保存到本地，保存时需要主意：
					// 1、如果系统中存在该信息，则执行更新操作，否则执行增加操作。
					// 2、如果是删除操作，系统中不存在该信息，则直接返回，否则执行删除操作。
					// 3、对于一批同步的数据需要做好统一标记，能够标识数据是一批处理的，以区分出哪些数据是同步而来，哪些数据是系统原有的。
					// 4、增量数据同步除了记录开始和结束同步回执外，还需要记录增量回执。

					// 处理时，需要记录处理是否成功的回执。
					ReceiptEntity receiptEntity = new ReceiptEntity();
					// 必设参数：0：失败，1：成功
					receiptEntity.setCode("1");
					// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
					// 查询增量本科生照片（0401）、查询增量研究生照片（0402）、查询增量教职工照片（0403）。
					receiptEntity.setSyncType("0401");
					// 必设参数：来自查询结果。
					receiptEntity.setSyncInfoId(photoEntity.getSyncInfoId());
					receiptEntity.setMessage("可选内容");
					eachReceipts.add(receiptEntity);
				}

				// 处理回执。
				WriteIncrReceiptParam writeIncrReceiptParam = new WriteIncrReceiptParam();
				writeIncrReceiptParam.setAuth(authEntity);
				writeIncrReceiptParam.addReceipts(eachReceipts);
				ssoDataSync.writeIncrReceipt(writeIncrReceiptParam);
			} else {
				// 没查找到数据，跳出本次调用。
				break;
			}
		}

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询增量本科生照片（0401）、查询增量研究生照片（0402）、查询增量教职工照片（0403）。
		writeBeginOrEndReceiptParam.setSyncType("0401");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////
	}

	public void findFullBarcode() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		FindSyncDataParam findFullBarcodeParam = new FindSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		findFullBarcodeParam.setAuth(authEntity);

		// 必设参数：分页信息。
		PageEntity pageEntity = new PageEntity();
		// 必设参数：页码，从0开始。
		pageEntity.setPageNumber(0);
		// 必设参数：每页记录条数。
		pageEntity.setPageSize(500);
		findFullBarcodeParam.setPage(pageEntity);

		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询全量本科生条码号（0501）、查询全量研究生条码号（0502）、查询全量教职工条码号（0503）。
		findFullBarcodeParam.setSyncType("0501");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询全量本科生条码号（0501）、查询全量研究生条码号（0502）、查询全量教职工条码号（0503）。
		writeBeginOrEndReceiptParam.setSyncType("0501");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 查询并处理数据，直到没有查询到数据为止。
		int pageNumber = 0;
		while (true) {
			// 每次处理完成，需要设置为下一页，直到最后没有查到数据为止。
			pageEntity.setPageNumber(pageNumber++);
			findFullBarcodeParam.setPage(pageEntity);

			// 执行查询。
			FindSyncDataResult result = ssoDataSync.findFullBarcode(findFullBarcodeParam);

			// 迭代处理查询结果。
			if (result.getSyncDatas() != null && result.getSyncDatas().size() > 0) {
				List<SyncDataEntity> syncDataEntities = result.getSyncDatas();
				for (SyncDataEntity syncDataEntity : syncDataEntities) {
					// 将查询结果转换为条码号（BarcodeEntity）。
					BarcodeEntity barcodeEntity = (BarcodeEntity)syncDataEntity;

					// 将数据保存到本地，保存时需要主意：
					// 1、如果系统中存在该信息，则执行更新操作，否则执行增加操作。
					// 2、对于一批同步的数据需要做好统一标记，能够标识数据是一批处理的，以区分出哪些数据是同步而来，哪些数据是系统原有的。
					// 3、？？？对于系统中已有的数据，但不在本次全量同步中，如何处理，需要由各系统决定，是删除还是做好标记保留在系统中。？？？
				}
			} else {
				// 没查找到数据，跳出本次调用。
				break;
			}
		}

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询全量本科生条码号（0501）、查询全量研究生条码号（0502）、查询全量教职工条码号（0503）。
		writeBeginOrEndReceiptParam.setSyncType("0501");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////
	}

	public void findIncrBarcode() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		FindSyncDataParam findIncrBarcodeParam = new FindSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		findIncrBarcodeParam.setAuth(authEntity);

		// 必设参数：分页信息。
		PageEntity pageEntity = new PageEntity();
		// 必设参数：页码，从0开始。
		pageEntity.setPageNumber(0);
		// 必设参数：每页记录条数。
		pageEntity.setPageSize(500);
		findIncrBarcodeParam.setPage(pageEntity);

		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询增量本科生条码号（0601）、查询增量研究生条码号（0602）、查询增量教职工条码号（0603）。
		findIncrBarcodeParam.setSyncType("0601");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询增量本科生条码号（0601）、查询增量研究生条码号（0602）、查询增量教职工条码号（0603）。
		writeBeginOrEndReceiptParam.setSyncType("0601");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 查询并处理数据，直到没有查询到数据为止。
		while (true) {
			// 执行查询。
			FindSyncDataResult result = ssoDataSync.findIncrBarcode(findIncrBarcodeParam);

			// 迭代处理查询结果。
			if (result.getSyncDatas() != null && result.getSyncDatas().size() > 0) {
				List<ReceiptEntity> eachReceipts = new ArrayList<ReceiptEntity>();
				List<SyncDataEntity> syncDataEntities = result.getSyncDatas();
				for (SyncDataEntity syncDataEntity : syncDataEntities) {
					// 将查询结果转换为条码号（BarcodeEntity）。
					BarcodeEntity barcodeEntity = (BarcodeEntity)syncDataEntity;

					// 将数据保存到本地，保存时需要主意：
					// 1、如果系统中存在该信息，则执行更新操作，否则执行增加操作。
					// 2、如果是删除操作，系统中不存在该信息，则直接返回，否则执行删除操作。
					// 3、对于一批同步的数据需要做好统一标记，能够标识数据是一批处理的，以区分出哪些数据是同步而来，哪些数据是系统原有的。
					// 4、增量数据同步除了记录开始和结束同步回执外，还需要记录增量回执。

					// 处理时，需要记录处理是否成功的回执。
					ReceiptEntity receiptEntity = new ReceiptEntity();
					// 必设参数：0：失败，1：成功
					receiptEntity.setCode("1");
					// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
					// 查询增量本科生条码号（0601）、查询增量研究生条码号（0602）、查询增量教职工条码号（0603）。
					receiptEntity.setSyncType("0601");
					// 必设参数：来自查询结果。
					receiptEntity.setSyncInfoId(barcodeEntity.getSyncInfoId());
					receiptEntity.setMessage("可选内容");
					eachReceipts.add(receiptEntity);
				}

				// 处理回执。
				WriteIncrReceiptParam writeIncrReceiptParam = new WriteIncrReceiptParam();
				writeIncrReceiptParam.setAuth(authEntity);
				writeIncrReceiptParam.addReceipts(eachReceipts);
				ssoDataSync.writeIncrReceipt(writeIncrReceiptParam);
			} else {
				// 没查找到数据，跳出本次调用。
				break;
			}
		}

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 查询增量本科生条码号（0601）、查询增量研究生条码号（0602）、查询增量教职工条码号（0603）。
		writeBeginOrEndReceiptParam.setSyncType("0601");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////
	}

	public void findFullOrg() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		FindSyncDataParam findFullOrgParam = new FindSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		findFullOrgParam.setAuth(authEntity);

		// 必设参数：分页信息。
		PageEntity pageEntity = new PageEntity();
		// 必设参数：页码，从0开始。
		pageEntity.setPageNumber(0);
		// 必设参数：每页记录条数。
		pageEntity.setPageSize(500);
		findFullOrgParam.setPage(pageEntity);

		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		findFullOrgParam.setSyncType("1401");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("1401");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 查询并处理数据，直到没有查询到数据为止。
		int pageNumber = 0;
		while (true) {
			// 每次处理完成，需要设置为下一页，直到最后没有查到数据为止。
			pageEntity.setPageNumber(pageNumber++);
			findFullOrgParam.setPage(pageEntity);

			// 执行查询。
			FindSyncDataResult result = ssoDataSync.findFullOrg(findFullOrgParam);

			// 迭代处理查询结果。
			if (result.getSyncDatas() != null && result.getSyncDatas().size() > 0) {
				List<SyncDataEntity> syncDataEntities = result.getSyncDatas();
				for (SyncDataEntity syncDataEntity : syncDataEntities) {
					// 将查询结果转换为组织机构（OrgEntity）。
					OrgEntity orgEntity = (OrgEntity)syncDataEntity;

					// 将数据保存到本地，保存时需要主意：
					// 1、如果系统中存在该信息，则执行更新操作，否则执行增加操作。
					// 2、对于一批同步的数据需要做好统一标记，能够标识数据是一批处理的，以区分出哪些数据是同步而来，哪些数据是系统原有的。
					// 3、？？？对于系统中已有的数据，但不在本次全量同步中，如何处理，需要由各系统决定，是删除还是做好标记保留在系统中。？？？
				}
			} else {
				// 没查找到数据，跳出本次调用。
				break;
			}
		}

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("1401");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////
	}

	public void findIncrOrg() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		FindSyncDataParam findIncrOrgParam = new FindSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		findIncrOrgParam.setAuth(authEntity);

		// 必设参数：分页信息。
		PageEntity pageEntity = new PageEntity();
		// 必设参数：页码，从0开始。
		pageEntity.setPageNumber(0);
		// 必设参数：每页记录条数。
		pageEntity.setPageSize(500);
		findIncrOrgParam.setPage(pageEntity);

		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		findIncrOrgParam.setSyncType("1402");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("1402");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 查询并处理数据，直到没有查询到数据为止。
		while (true) {
			// 执行查询。
			FindSyncDataResult result = ssoDataSync.findIncrOrg(findIncrOrgParam);

			// 迭代处理查询结果。
			if (result.getSyncDatas() != null && result.getSyncDatas().size() > 0) {
				List<ReceiptEntity> eachReceipts = new ArrayList<ReceiptEntity>();
				List<SyncDataEntity> syncDataEntities = result.getSyncDatas();
				for (SyncDataEntity syncDataEntity : syncDataEntities) {
					// 将查询结果转换为组织机构（OrgEntity）。
					OrgEntity orgEntity = (OrgEntity)syncDataEntity;

					// 将数据保存到本地，保存时需要主意：
					// 1、如果系统中存在该信息，则执行更新操作，否则执行增加操作。
					// 2、如果是删除操作，系统中不存在该信息，则直接返回，否则执行删除操作。
					// 3、对于一批同步的数据需要做好统一标记，能够标识数据是一批处理的，以区分出哪些数据是同步而来，哪些数据是系统原有的。
					// 4、增量数据同步除了记录开始和结束同步回执外，还需要记录增量回执。

					// 处理时，需要记录处理是否成功的回执。
					ReceiptEntity receiptEntity = new ReceiptEntity();
					// 必设参数：0：失败，1：成功
					receiptEntity.setCode("1");
					// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
					receiptEntity.setSyncType("1402");
					// 必设参数：来自查询结果。
					receiptEntity.setSyncInfoId(orgEntity.getSyncInfoId());
					receiptEntity.setMessage("可选内容");
					eachReceipts.add(receiptEntity);
				}

				// 处理回执。
				WriteIncrReceiptParam writeIncrReceiptParam = new WriteIncrReceiptParam();
				writeIncrReceiptParam.setAuth(authEntity);
				writeIncrReceiptParam.addReceipts(eachReceipts);
				ssoDataSync.writeIncrReceipt(writeIncrReceiptParam);
			} else {
				// 没查找到数据，跳出本次调用。
				break;
			}
		}

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("1402");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////
	}

	// //////////////////////////////////////////////////////////////////////////////
	// 以下三个方法为updateFullUser，包括updateFullUnderGraduate（本科生）、updateFullGraduate（研究生）、updateFullTeacher（教职工）。
	// //////////////////////////////////////////////////////////////////////////////
	public void updateFullUnderGraduate() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		UpdateSyncDataParam updateFullUserParam = new UpdateSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		updateFullUserParam.setAuth(authEntity);
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		updateFullUserParam.setSyncType("0701");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("0701");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 必设参数：待同步数据，实体类型为UnderGraduateEntity（本科生）。
		for (int i = 0; i < 5; i++) {
			UnderGraduateEntity userEntity = new UnderGraduateEntity();

			// xh必须设置。
			userEntity.setXh("bksxh" + i);

			// xm必须设置。
			userEntity.setXm("xm" + i);

			// yxsh、nj、bjh必须设置。
			userEntity.setYxsh("yxsh" + i);
			userEntity.setNj("nj" + i);
			userEntity.setBjh("bjh" + i);

			// 设置其它内容，能够提供的最大内容。
			userEntity.setCym("cym" + i);
			// 。。。

			updateFullUserParam.addSyncData(userEntity);
		}

		UpdateSyncDataResult result = ssoDataSync.updateFullUser(updateFullUserParam);

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("0701");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 对返回结果，做进一步处理。
		// 判断更新是否成功。
	}

	public void updateFullGraduate() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		UpdateSyncDataParam updateFullUserParam = new UpdateSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		updateFullUserParam.setAuth(authEntity);
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		updateFullUserParam.setSyncType("0702");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("0702");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 必设参数：待同步数据，实体类型为GraduateEntity（研究生）。
		for (int i = 0; i < 5; i++) {
			GraduateEntity userEntity = new GraduateEntity();

			// xh必须设置。
			userEntity.setXh("yjsxh" + i);

			// xm必须设置。
			userEntity.setXm("xm" + i);

			// yxsh、nj、bjh必须设置。
			userEntity.setYxsh("yxsh" + i);
			userEntity.setNj("nj" + i);
			userEntity.setBjh("bjh" + i);

			// 设置其它内容，能够提供的最大内容。
			userEntity.setCym("cym" + i);
			// 。。。

			updateFullUserParam.addSyncData(userEntity);
		}

		UpdateSyncDataResult result = ssoDataSync.updateFullUser(updateFullUserParam);

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("0702");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 对返回结果，做进一步处理。
		// 判断更新是否成功。
	}

	public void updateFullTeacher() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		UpdateSyncDataParam updateFullUserParam = new UpdateSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		updateFullUserParam.setAuth(authEntity);
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		updateFullUserParam.setSyncType("0703");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("0703");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 必设参数：待同步数据，实体类型为TeacherEntity（教职工）。
		for (int i = 0; i < 5; i++) {
			TeacherEntity userEntity = new TeacherEntity();

			// jgh必须设置。
			userEntity.setJgh("jgh" + i);

			// xm必须设置。
			userEntity.setXm("xm" + i);

			// bmdm必须设置。
			userEntity.setBmdm("bmdm" + i);

			// 设置其它内容，能够提供的最大内容。
			userEntity.setCym("cym" + i);
			// 。。。

			updateFullUserParam.addSyncData(userEntity);
		}

		UpdateSyncDataResult result = ssoDataSync.updateFullUser(updateFullUserParam);

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("0703");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 对返回结果，做进一步处理。
		// 判断更新是否成功。
	}

	// //////////////////////////////////////////////////////////////////////////////
	// 以下三个方法为updateIncrUser，包括updateIncrUnderGraduate（本科生）、updateIncrGraduate（研究生）、updateIncrTeacher（教职工）。
	// //////////////////////////////////////////////////////////////////////////////
	public void updateIncrUnderGraduate() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		UpdateSyncDataParam updateIncrUserParam = new UpdateSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		updateIncrUserParam.setAuth(authEntity);
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		updateIncrUserParam.setSyncType("0801");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("0801");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 必设参数：待同步数据，实体类型为UnderGraduateEntity（本科生）。
		for (int i = 0; i < 5; i++) {
			UnderGraduateEntity userEntity = new UnderGraduateEntity();

			// //////////////////////////////////////////////////////////////////////////////
			// incr（增量）同步额外信息。
			// //////////////////////////////////////////////////////////////////////////////
			// 设置同步流水号，能唯一标识该实体，UnderGraduateEntity（本科生）设置为xh。
			userEntity.setSyncInfoId("bksxh" + i);
			// A：增加，U：修改，D：删除
			userEntity.setOperateFlag("U");
			// //////////////////////////////////////////////////////////////////////////////

			// xh必须设置。
			userEntity.setXh("bksxh" + i);

			// xm必须设置。
			userEntity.setXm("xm" + i);

			// yxsh、nj、bjh必须设置。
			userEntity.setYxsh("yxsh" + i);
			userEntity.setNj("nj" + i);
			userEntity.setBjh("bjh" + i);

			// 设置其它内容，能够提供的最大内容。
			userEntity.setCym("cym" + i);
			// 。。。

			updateIncrUserParam.addSyncData(userEntity);
		}

		UpdateSyncDataResult result = ssoDataSync.updateIncrUser(updateIncrUserParam);

		// //////////////////////////////////////////////////////////////////////////////
		// incr（增量）同步额外处理逻辑。
		// //////////////////////////////////////////////////////////////////////////////
		// 迭代回执信息，判断该条信息在适当时候需要再次同步（回执返回失败时）。
		List<ReceiptEntity> receipts = result.getReceipts();
		for (ReceiptEntity receipt : receipts) {
			if ("1".equals(receipt.getCode())) {
				// 1：成功，不需要再同步。
				System.out.println(receipt.getSyncInfoId() + "同步成功，不需要再次同步。");
			} else {
				// 0：不成功，需要再次同步。
				System.out.println(receipt.getSyncInfoId() + "同步失败，需要再次同步。");
			}
		}
		// //////////////////////////////////////////////////////////////////////////////

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("0801");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 对返回结果，做进一步处理。
		// 判断更新是否成功。
	}

	public void updateIncrGraduate() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		UpdateSyncDataParam updateIncrUserParam = new UpdateSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		updateIncrUserParam.setAuth(authEntity);
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		updateIncrUserParam.setSyncType("0802");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("0802");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 必设参数：待同步数据，实体类型为GraduateEntity（研究生）。
		for (int i = 0; i < 5; i++) {
			GraduateEntity userEntity = new GraduateEntity();

			// //////////////////////////////////////////////////////////////////////////////
			// incr（增量）同步额外信息。
			// //////////////////////////////////////////////////////////////////////////////
			// 设置同步流水号，能唯一标识该实体，GraduateEntity（研究生）设置为xh。
			userEntity.setSyncInfoId("yjsxh" + i);
			// A：增加，U：修改，D：删除
			userEntity.setOperateFlag("D");
			// //////////////////////////////////////////////////////////////////////////////

			// xh必须设置。
			userEntity.setXh("yjsxh" + i);

			// xm必须设置。
			userEntity.setXm("xm" + i);

			// yxsh、nj、bjh必须设置。
			userEntity.setYxsh("yxsh" + i);
			userEntity.setNj("nj" + i);
			userEntity.setBjh("bjh" + i);

			// 设置其它内容，能够提供的最大内容。
			userEntity.setCym("cymwww" + i);
			// 。。。

			updateIncrUserParam.addSyncData(userEntity);
		}

		UpdateSyncDataResult result = ssoDataSync.updateIncrUser(updateIncrUserParam);

		// //////////////////////////////////////////////////////////////////////////////
		// incr（增量）同步额外处理逻辑。
		// //////////////////////////////////////////////////////////////////////////////
		// 迭代回执信息，判断该条信息在适当时候需要再次同步（回执返回失败时）。
		List<ReceiptEntity> receipts = result.getReceipts();
		for (ReceiptEntity receipt : receipts) {
			if ("1".equals(receipt.getCode())) {
				// 1：成功，不需要再同步。
				System.out.println(receipt.getSyncInfoId() + "同步成功，不需要再次同步。");
			} else {
				// 0：不成功，需要再次同步。
				System.out.println(receipt.getSyncInfoId() + "同步失败，需要再次同步。");
			}
		}
		// //////////////////////////////////////////////////////////////////////////////

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("0802");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 对返回结果，做进一步处理。
		// 判断更新是否成功。
	}

	public void updateIncrTeacher() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		UpdateSyncDataParam updateIncrUserParam = new UpdateSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		updateIncrUserParam.setAuth(authEntity);
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		updateIncrUserParam.setSyncType("0803");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("0803");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 必设参数：待同步数据，实体类型为TeacherEntity（教职工）。
		for (int i = 0; i < 5; i++) {
			TeacherEntity userEntity = new TeacherEntity();

			// //////////////////////////////////////////////////////////////////////////////
			// incr（增量）同步额外信息。
			// //////////////////////////////////////////////////////////////////////////////
			// 设置同步流水号，能唯一标识该实体，TeacherEntity（教职工）设置为jgh。
			userEntity.setSyncInfoId("jgh" + i);
			// A：增加，U：修改，D：删除
			userEntity.setOperateFlag("D");
			// //////////////////////////////////////////////////////////////////////////////

			// jgh必须设置。
			userEntity.setJgh("jgh" + i);

			// xm必须设置。
			userEntity.setXm("xm" + i);

			// bmdm必须设置。
			userEntity.setBmdm("bmdm" + i);

			// 设置其它内容，能够提供的最大内容。
			userEntity.setCym("cym" + i);
			// 。。。

			updateIncrUserParam.addSyncData(userEntity);
		}

		UpdateSyncDataResult result = ssoDataSync.updateIncrUser(updateIncrUserParam);

		// //////////////////////////////////////////////////////////////////////////////
		// incr（增量）同步额外处理逻辑。
		// //////////////////////////////////////////////////////////////////////////////
		// 迭代回执信息，判断该条信息在适当时候需要再次同步（回执返回失败时）。
		List<ReceiptEntity> receipts = result.getReceipts();
		for (ReceiptEntity receipt : receipts) {
			if ("1".equals(receipt.getCode())) {
				// 1：成功，不需要再同步。
				System.out.println(receipt.getSyncInfoId() + "同步成功，不需要再次同步。");
			} else {
				// 0：不成功，需要再次同步。
				System.out.println(receipt.getSyncInfoId() + "同步失败，需要再次同步。");
			}
		}
		// //////////////////////////////////////////////////////////////////////////////

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("0803");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 对返回结果，做进一步处理。
		// 判断更新是否成功。
	}

	// //////////////////////////////////////////////////////////////////////////////
	// 以下方法为updatePhoto。
	// //////////////////////////////////////////////////////////////////////////////
	public void updateFullPhoto() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		UpdateSyncDataParam updateFullPhotoParam = new UpdateSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		updateFullPhotoParam.setAuth(authEntity);
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 更新全量本科生照片（0901）、更新全量研究生照片（0902）、更新全量教职工照片（0903）。
		updateFullPhotoParam.setSyncType("0903");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 更新全量本科生照片（0901）、更新全量研究生照片（0902）、更新全量教职工照片（0903）。
		writeBeginOrEndReceiptParam.setSyncType("0903");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 必设参数：待同步数据。
		for (int i = 0; i < 5; i++) {
			PhotoEntity photoEntity = new PhotoEntity();

			// userCode必须设置。
			// 与syncType参数：更新全量本科生照片（0901）、更新全量研究生照片（0902）、更新全量教职工照片（0903）对应。
			photoEntity.setUserCode("jgh" + i);

			// photo必须设置。
			AttachEntity attachEntity = new AttachEntity();
			if (i % 2 == 0) {
				attachEntity.setFileContent(readFile("d:/妍2008-06-07-004.jpg"));
			} else {
				attachEntity.setFileContent(readFile("d:/子璇子妍20091018.jpg"));
			}
			photoEntity.setPhoto(attachEntity);

			updateFullPhotoParam.addSyncData(photoEntity);
		}

		UpdateSyncDataResult result = ssoDataSync.updateFullPhoto(updateFullPhotoParam);

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 更新全量本科生照片（0901）、更新全量研究生照片（0902）、更新全量教职工照片（0903）。
		writeBeginOrEndReceiptParam.setSyncType("0903");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 对返回结果，做进一步处理。
		// 判断更新是否成功。
	}

	public void updateIncrPhoto() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		UpdateSyncDataParam updateIncrPhotoParam = new UpdateSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		updateIncrPhotoParam.setAuth(authEntity);
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 更新增量本科生照片（1001）、更新增量研究生照片（1002）、更新增量教职工照片（1003）。
		updateIncrPhotoParam.setSyncType("1003");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 更新增量本科生照片（1001）、更新增量研究生照片（1002）、更新增量教职工照片（1003）。
		writeBeginOrEndReceiptParam.setSyncType("1003");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 必设参数：待同步数据。
		for (int i = 0; i < 5; i++) {
			PhotoEntity photoEntity = new PhotoEntity();

			// //////////////////////////////////////////////////////////////////////////////
			// incr（增量）同步额外信息。
			// //////////////////////////////////////////////////////////////////////////////
			// 设置同步流水号，能唯一标识该实体。
			photoEntity.setSyncInfoId("jgh" + i);
			// A：增加，U：修改，D：删除
			photoEntity.setOperateFlag("U");
			// //////////////////////////////////////////////////////////////////////////////

			// userCode必须设置。
			// 与syncType参数：更新增量本科生照片（1001）、更新增量研究生照片（1002）、更新增量教职工照片（1003）对应。
			photoEntity.setUserCode("jgh" + i);

			// photo必须设置。
			AttachEntity attachEntity = new AttachEntity();
			if (i % 2 != 0) {
				attachEntity.setFileContent(readFile("d:/妍2008-06-07-004.jpg"));
			} else {
				attachEntity.setFileContent(readFile("d:/子璇子妍20091018.jpg"));
			}
			photoEntity.setPhoto(attachEntity);

			updateIncrPhotoParam.addSyncData(photoEntity);
		}

		UpdateSyncDataResult result = ssoDataSync.updateIncrPhoto(updateIncrPhotoParam);

		// //////////////////////////////////////////////////////////////////////////////
		// incr（增量）同步额外处理逻辑。
		// //////////////////////////////////////////////////////////////////////////////
		// 迭代回执信息，判断该条信息在适当时候需要再次同步（回执返回失败时）。
		List<ReceiptEntity> receipts = result.getReceipts();
		for (ReceiptEntity receipt : receipts) {
			if ("1".equals(receipt.getCode())) {
				// 1：成功，不需要再同步。
				System.out.println(receipt.getSyncInfoId() + "同步成功，不需要再次同步。");
			} else {
				// 0：不成功，需要再次同步。
				System.out.println(receipt.getSyncInfoId() + "同步失败，需要再次同步。");
			}
		}
		// //////////////////////////////////////////////////////////////////////////////

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 更新增量本科生照片（1001）、更新增量研究生照片（1002）、更新增量教职工照片（1003）。
		writeBeginOrEndReceiptParam.setSyncType("1003");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 对返回结果，做进一步处理。
		// 判断更新是否成功。
	}

	// //////////////////////////////////////////////////////////////////////////////
	// 以下方法为updateBarcode。
	// //////////////////////////////////////////////////////////////////////////////
	public void updateFullBarcode() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		UpdateSyncDataParam updateFullBarcodeParam = new UpdateSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		updateFullBarcodeParam.setAuth(authEntity);
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 更新全量本科生条码号（1101）、更新全量研究生条码号（1102）、更新全量教职工条码号（1103）。
		updateFullBarcodeParam.setSyncType("1101");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 更新全量本科生条码号（1101）、更新全量研究生条码号（1102）、更新全量教职工条码号（1103）。
		writeBeginOrEndReceiptParam.setSyncType("1101");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 必设参数：待同步数据。
		for (int i = 0; i < 5; i++) {
			BarcodeEntity barcodeEntity = new BarcodeEntity();

			// userCode必须设置。
			// 与syncType参数：更新全量本科生条码号（1101）、更新全量研究生条码号（1102）、更新全量教职工条码号（1103）对应。
			barcodeEntity.setUserCode("bksxh" + i);

			// barcode必须设置。
			barcodeEntity.setBarcode("barcode" + i);

			updateFullBarcodeParam.addSyncData(barcodeEntity);
		}

		UpdateSyncDataResult result = ssoDataSync.updateFullBarcode(updateFullBarcodeParam);

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 更新全量本科生条码号（1101）、更新全量研究生条码号（1102）、更新全量教职工条码号（1103）。
		writeBeginOrEndReceiptParam.setSyncType("1101");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 对返回结果，做进一步处理。
		// 判断更新是否成功。
	}

	public void updateIncrBarcode() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		UpdateSyncDataParam updateIncrBarcodeParam = new UpdateSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		updateIncrBarcodeParam.setAuth(authEntity);
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 更新增量本科生条码号（1201）、更新增量研究生条码号（1202）、更新增量教职工条码号（1203）。
		updateIncrBarcodeParam.setSyncType("1201");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 更新增量本科生条码号（1201）、更新增量研究生条码号（1202）、更新增量教职工条码号（1203）。
		writeBeginOrEndReceiptParam.setSyncType("1201");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 必设参数：待同步数据。
		for (int i = 0; i < 5; i++) {
			BarcodeEntity barcodeEntity = new BarcodeEntity();

			// //////////////////////////////////////////////////////////////////////////////
			// incr（增量）同步额外信息。
			// //////////////////////////////////////////////////////////////////////////////
			// 设置同步流水号，能唯一标识该实体。
			barcodeEntity.setSyncInfoId("bksxh" + i);
			// A：增加，U：修改，D：删除
			barcodeEntity.setOperateFlag("U");
			// //////////////////////////////////////////////////////////////////////////////

			// userCode必须设置。
			// 与syncType参数：更新增量本科生条码号（1201）、更新增量研究生条码号（1202）、更新增量教职工条码号（1203）对应。
			barcodeEntity.setUserCode("bksxh" + i);

			// barcode必须设置。
			barcodeEntity.setBarcode("barcode" + i);

			updateIncrBarcodeParam.addSyncData(barcodeEntity);
		}

		UpdateSyncDataResult result = ssoDataSync.updateIncrBarcode(updateIncrBarcodeParam);

		// //////////////////////////////////////////////////////////////////////////////
		// incr（增量）同步额外处理逻辑。
		// //////////////////////////////////////////////////////////////////////////////
		// 迭代回执信息，判断该条信息在适当时候需要再次同步（回执返回失败时）。
		List<ReceiptEntity> receipts = result.getReceipts();
		for (ReceiptEntity receipt : receipts) {
			if ("1".equals(receipt.getCode())) {
				// 1：成功，不需要再同步。
				System.out.println(receipt.getSyncInfoId() + "同步成功，不需要再次同步。");
			} else {
				// 0：不成功，需要再次同步。
				System.out.println(receipt.getSyncInfoId() + "同步失败，需要再次同步。");
			}
		}
		// //////////////////////////////////////////////////////////////////////////////

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		// 更新增量本科生条码号（1201）、更新增量研究生条码号（1202）、更新增量教职工条码号（1203）。
		writeBeginOrEndReceiptParam.setSyncType("1201");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 对返回结果，做进一步处理。
		// 判断更新是否成功。
	}

	// //////////////////////////////////////////////////////////////////////////////
	// 以下方法为updateOrg。
	// //////////////////////////////////////////////////////////////////////////////
	public void updateFullOrg() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		UpdateSyncDataParam updateFullOrgParam = new UpdateSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		updateFullOrgParam.setAuth(authEntity);
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		updateFullOrgParam.setSyncType("1403");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("1403");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 必设参数：待同步数据。
		for (int i = 0; i < 5; i++) {
			OrgEntity orgEntity = new OrgEntity();

			// jgdm必须设置。
			orgEntity.setJgdm("jgdm" + i);

			// jgmc必须设置。
			orgEntity.setJgmc("jgmc" + i);

			// 设置其它内容，能够提供的最大内容。
			// 。。。

			updateFullOrgParam.addSyncData(orgEntity);
		}

		UpdateSyncDataResult result = ssoDataSync.updateFullOrg(updateFullOrgParam);

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("1403");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 对返回结果，做进一步处理。
		// 判断更新是否成功。
	}

	public void updateIncrOrg() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		UpdateSyncDataParam updateIncrOrgParam = new UpdateSyncDataParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		updateIncrOrgParam.setAuth(authEntity);
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		updateIncrOrgParam.setSyncType("1404");

		// //////////////////////////////////////////////////////////////////////////////
		// 记录开始同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam = new WriteBeginOrEndReceiptParam();
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("1");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("0");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("1404");
		// 执行开始同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 必设参数：待同步数据。
		for (int i = 0; i < 5; i++) {
			OrgEntity orgEntity = new OrgEntity();

			// //////////////////////////////////////////////////////////////////////////////
			// incr（增量）同步额外信息。
			// //////////////////////////////////////////////////////////////////////////////
			// 设置同步流水号，能唯一标识该实体。
			orgEntity.setSyncInfoId("jgdm" + i);
			// A：增加，U：修改，D：删除
			orgEntity.setOperateFlag("U");
			// //////////////////////////////////////////////////////////////////////////////

			// jgdm必须设置。
			orgEntity.setJgdm("jgdm" + i);

			// jgmc必须设置。
			orgEntity.setJgmc("jgmc" + i);

			// 设置其它内容，能够提供的最大内容。
			orgEntity.setJgjc("jgmc对应的简称" + i);
			// 。。。

			updateIncrOrgParam.addSyncData(orgEntity);
		}

		UpdateSyncDataResult result = ssoDataSync.updateIncrOrg(updateIncrOrgParam);

		// //////////////////////////////////////////////////////////////////////////////
		// incr（增量）同步额外处理逻辑。
		// //////////////////////////////////////////////////////////////////////////////
		// 迭代回执信息，判断该条信息在适当时候需要再次同步（回执返回失败时）。
		List<ReceiptEntity> receipts = result.getReceipts();
		for (ReceiptEntity receipt : receipts) {
			if ("1".equals(receipt.getCode())) {
				// 1：成功，不需要再同步。
				System.out.println(receipt.getSyncInfoId() + "同步成功，不需要再次同步。");
			} else {
				// 0：不成功，需要再次同步。
				System.out.println(receipt.getSyncInfoId() + "同步失败，需要再次同步。");
			}
		}
		// //////////////////////////////////////////////////////////////////////////////

		// //////////////////////////////////////////////////////////////////////////////
		// 记录结束同步回执。
		// //////////////////////////////////////////////////////////////////////////////
		// 必设参数：安全认证信息。
		writeBeginOrEndReceiptParam.setAuth(authEntity);
		// 必设参数：1：开始，2：结束
		writeBeginOrEndReceiptParam.setBeginOrEndFlag("2");
		// 必设参数：0：初始，1：成功，2：失败
		writeBeginOrEndReceiptParam.setSyncStatus("1");
		// 必设参数：同步类型，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		writeBeginOrEndReceiptParam.setSyncType("1404");
		// 执行结束同步回执。
		ssoDataSync.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);
		// //////////////////////////////////////////////////////////////////////////////

		// 对返回结果，做进一步处理。
		// 判断更新是否成功。
	}

	// //////////////////////////////////////////////////////////////////////////////
	// 以下方法为changePasswd。
	// //////////////////////////////////////////////////////////////////////////////
	public void changePasswd() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		ChangePasswdParam changePasswdParam = new ChangePasswdParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		changePasswdParam.setAuth(authEntity);

		// 必设参数：待同步数据。
		changePasswdParam.setUserCode("bksxh" + 0);
		changePasswdParam.setOldPasswd("oldPasswd");
		changePasswdParam.setNewPasswd("newPasswd");

		ChangePasswdResult result = ssoDataSync.changePasswd(changePasswdParam);

		// 对返回结果，做进一步处理。
		// 判断修改密码是否成功。
	}

	// //////////////////////////////////////////////////////////////////////////////
	// 以下方法为forgotPasswd。
	// //////////////////////////////////////////////////////////////////////////////
	public void forgotPasswd() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		ForgotPasswdParam forgotPasswdParam = new ForgotPasswdParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		forgotPasswdParam.setAuth(authEntity);

		// 必设参数：待同步数据。
		forgotPasswdParam.setUserCode("bksxh" + 0);

		ForgotPasswdResult result = ssoDataSync.forgotPasswd(forgotPasswdParam);

		// 对返回结果，做进一步处理。
		// 获取返回的密码。
	}

	// //////////////////////////////////////////////////////////////////////////////
	// 以下方法为userLogin。
	// //////////////////////////////////////////////////////////////////////////////
	public void userLogin() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		UserLoginParam userLoginParam = new UserLoginParam();

		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		userLoginParam.setAppsys("0901");
		// 必设参数：登录用户帐号。
		userLoginParam.setUserCode("userCode");
		// 必设参数：登录用户密码。
		userLoginParam.setPasswd("passwd");

		UserLoginResult result = ssoDataSync.userLogin(userLoginParam);

		// 对返回结果，做进一步处理。
		// 判断用户是否成功登录，有哪些应用系统的权限。
	}

	// //////////////////////////////////////////////////////////////////////////////
	// 以下方法为findAppsysAuth。
	// //////////////////////////////////////////////////////////////////////////////
	public void findAppsysAuth() {
		// 创建客户端连接。
		SSODataSync ssoDataSync = new SSODataSync();

		// 初始化参数。
		FindAppsysAuthParam findAppsysAuthParam = new FindAppsysAuthParam();

		// 必设参数：安全认证信息。
		AuthEntity authEntity = new AuthEntity();
		// 必设参数：应用系统代码，值见《02-公共基础平台-数据同步接口规范.doc》中7.1静态参数。
		authEntity.setAppsys("0901");
		// 必设参数：分配给每个应用系统连接统一用管理的密码。
		authEntity.setPasswd("2222");
		// 可选参数：数据是否加密的标识，1表示加密，0或不设置表示不加密。
		authEntity.setEncrypt("0");
		// 必设参数：安全认证信息。
		findAppsysAuthParam.setAuth(authEntity);

		FindAppsysAuthResult result = ssoDataSync.findAppsysAuth(findAppsysAuthParam);

		// 对返回结果，做进一步处理。
		// 将返回的结果保存在本系统中。
	}

	public void writeBeginOrEndReceipt() {
		// 见find或update方法中的记录开始和结束回执。
	}

	public void writeIncrReceipt() {
		// 见find方法中的记录增量回执。
	}

	private byte[] readFile(String filename) {
		byte[] readed = null;
		try {
			InputStream is = new FileInputStream(new File(filename));
			int length = is.available();
			readed = new byte[length];
			while (is.read(readed) != -1) {
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return readed;
	}

	private void writeFile(String filename, byte[] writted) {
		try {
			OutputStream os = new FileOutputStream(new File(filename));
			os.write(writted);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		SSODataSyncExample example = new SSODataSyncExample();
		// example.findFullUser();
		// example.findIncrUser();
		// example.findFullPhoto();
		// example.findIncrPhoto();
		// example.findFullBarcode();
		// example.findIncrBarcode();
		// example.findFullOrg();
		// example.findIncrOrg();
		// example.updateFullUnderGraduate();
		// example.updateFullGraduate();
		// example.updateFullTeacher();
		// example.updateIncrUnderGraduate();
		// example.updateIncrGraduate();
		// example.updateIncrTeacher();
		// example.updateFullPhoto();
		// example.updateIncrPhoto();
		// example.updateFullBarcode();
		// example.updateIncrBarcode();
		// example.updateFullOrg();
		// example.updateIncrOrg();
		// example.changePasswd();
		// example.forgotPasswd();
		// example.userLogin();
		// example.findAppsysAuth();
		// example.writeBeginOrEndReceipt();
		// example.writeIncrReceipt();
	}
}