package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "forgotPasswdParam", propOrder = {"auth", "userCode", "idCard", "question", "answer", "email"})
public class ForgotPasswdParam {
	protected AuthEntity auth;
	protected String userCode;
	protected String idCard;
	protected String question;
	protected String answer;
	protected String email;

	/**
	 * Gets the value of the auth property.
	 * 
	 * @return possible object is {@link AuthEntity }
	 * 
	 */
	public AuthEntity getAuth() {
		return auth;
	}

	/**
	 * Sets the value of the auth property.
	 * 
	 * @param value allowed object is {@link AuthEntity }
	 * 
	 */
	public void setAuth(AuthEntity value) {
		this.auth = value;
	}

	/**
	 * Gets the value of the userCode property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getUserCode() {
		return userCode;
	}

	/**
	 * Sets the value of the userCode property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setUserCode(String value) {
		this.userCode = value;
	}

	/**
	 * Gets the value of the idCard property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getIdCard() {
		return idCard;
	}

	/**
	 * Sets the value of the idCard property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setIdCard(String value) {
		this.idCard = value;
	}

	/**
	 * Gets the value of the question property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getQuestion() {
		return question;
	}

	/**
	 * Sets the value of the question property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setQuestion(String value) {
		this.question = value;
	}

	/**
	 * Gets the value of the answer property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getAnswer() {
		return answer;
	}

	/**
	 * Sets the value of the answer property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setAnswer(String value) {
		this.answer = value;
	}

	/**
	 * Gets the value of the email property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the value of the email property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setEmail(String value) {
		this.email = value;
	}
}