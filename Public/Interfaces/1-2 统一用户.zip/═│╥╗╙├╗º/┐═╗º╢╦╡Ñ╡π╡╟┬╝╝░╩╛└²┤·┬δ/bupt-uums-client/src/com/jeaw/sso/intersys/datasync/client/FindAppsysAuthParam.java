package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "findAppsysAuthParam", propOrder = {"auth"})
public class FindAppsysAuthParam {
	protected AuthEntity auth;

	/**
	 * Gets the value of the auth property.
	 * 
	 * @return possible object is {@link AuthEntity }
	 * 
	 */
	public AuthEntity getAuth() {
		return auth;
	}

	/**
	 * Sets the value of the auth property.
	 * 
	 * @param value allowed object is {@link AuthEntity }
	 * 
	 */
	public void setAuth(AuthEntity value) {
		this.auth = value;
	}
}