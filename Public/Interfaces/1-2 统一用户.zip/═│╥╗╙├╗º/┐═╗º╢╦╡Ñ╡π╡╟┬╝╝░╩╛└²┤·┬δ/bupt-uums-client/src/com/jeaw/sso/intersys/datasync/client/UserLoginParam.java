package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "userLoginParam", propOrder = {"appsys", "userCode", "passwd"})
public class UserLoginParam {
	protected String appsys;
	protected String userCode;
	protected String passwd;

	/**
	 * Gets the value of the appsys property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getAppsys() {
		return appsys;
	}

	/**
	 * Sets the value of the appsys property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setAppsys(String value) {
		this.appsys = value;
	}

	/**
	 * Gets the value of the userCode property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getUserCode() {
		return userCode;
	}

	/**
	 * Sets the value of the userCode property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setUserCode(String value) {
		this.userCode = value;
	}

	/**
	 * Gets the value of the passwd property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPasswd() {
		return passwd;
	}

	/**
	 * Sets the value of the passwd property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setPasswd(String value) {
		this.passwd = value;
	}
}