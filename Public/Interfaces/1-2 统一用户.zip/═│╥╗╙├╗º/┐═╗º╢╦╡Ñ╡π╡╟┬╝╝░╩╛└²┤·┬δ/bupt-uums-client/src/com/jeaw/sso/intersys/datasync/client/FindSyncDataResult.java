package com.jeaw.sso.intersys.datasync.client;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "findSyncDataResult", propOrder = {"code", "message", "syncDatas"})
public class FindSyncDataResult {
	protected String code;
	protected String message;
	protected FindSyncDataResult.SyncDatas syncDatas;

	/**
	 * Gets the value of the code property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Sets the value of the code property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setCode(String value) {
		this.code = value;
	}

	/**
	 * Gets the value of the message property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the value of the message property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setMessage(String value) {
		this.message = value;
	}

	/**
	 * Gets the value of the syncDatas property.
	 * 
	 * @return possible object is {@link List<String> }
	 * 
	 */
	public List<SyncDataEntity> getSyncDatas() {
		if (syncDatas != null) {
			return syncDatas.getSyncData();
		}
		return new ArrayList<SyncDataEntity>();
	}

	public void addSyncData(SyncDataEntity entity) {
		if (syncDatas == null) {
			syncDatas = new SyncDatas();
		}
		syncDatas.getSyncData().add(entity);
	}

	public void addSyncDatas(List<SyncDataEntity> entities) {
		if (syncDatas == null) {
			syncDatas = new SyncDatas();
		}
		syncDatas.getSyncData().addAll(entities);
	}

	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "", propOrder = {"syncData"})
	public static class SyncDatas {
		protected List<SyncDataEntity> syncData;

		public List<SyncDataEntity> getSyncData() {
			if (syncData == null) {
				syncData = new ArrayList<SyncDataEntity>();
			}
			return this.syncData;
		}
	}
}