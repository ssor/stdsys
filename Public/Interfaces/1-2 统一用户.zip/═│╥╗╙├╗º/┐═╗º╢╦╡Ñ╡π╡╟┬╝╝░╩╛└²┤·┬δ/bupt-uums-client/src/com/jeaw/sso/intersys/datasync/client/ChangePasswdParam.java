package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "changePasswdParam", propOrder = {"auth", "userCode", "oldPasswd", "newPasswd"})
public class ChangePasswdParam {
	protected AuthEntity auth;
	protected String userCode;
	protected String oldPasswd;
	protected String newPasswd;

	/**
	 * Gets the value of the auth property.
	 * 
	 * @return possible object is {@link AuthEntity }
	 * 
	 */
	public AuthEntity getAuth() {
		return auth;
	}

	/**
	 * Sets the value of the auth property.
	 * 
	 * @param value allowed object is {@link AuthEntity }
	 * 
	 */
	public void setAuth(AuthEntity value) {
		this.auth = value;
	}

	/**
	 * Gets the value of the userCode property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getUserCode() {
		return userCode;
	}

	/**
	 * Sets the value of the userCode property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setUserCode(String value) {
		this.userCode = value;
	}

	/**
	 * Gets the value of the oldPasswd property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getOldPasswd() {
		return oldPasswd;
	}

	/**
	 * Sets the value of the oldPasswd property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setOldPasswd(String value) {
		this.oldPasswd = value;
	}

	/**
	 * Gets the value of the newPasswd property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getNewPasswd() {
		return newPasswd;
	}

	/**
	 * Sets the value of the newPasswd property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setNewPasswd(String value) {
		this.newPasswd = value;
	}
}