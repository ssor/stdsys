package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlRegistry;

@XmlRegistry
public class ObjectFactory {
	/**
	 * Create a new ObjectFactory that can be used to create new instances of
	 * schema derived classes for package:
	 * com.jeaw.sso.intersys.datasync.service
	 * 
	 */
	public ObjectFactory() {
	}

	/**
	 * Create an instance of {@link UserLoginResult }
	 * 
	 */
	public UserLoginResult createUserLoginResult() {
		return new UserLoginResult();
	}

	/**
	 * Create an instance of {@link FindSyncDataParam }
	 * 
	 */
	public FindSyncDataParam createFindSyncDataParam() {
		return new FindSyncDataParam();
	}

	/**
	 * Create an instance of {@link BarcodeEntity }
	 * 
	 */
	public BarcodeEntity createBarcodeEntity() {
		return new BarcodeEntity();
	}

	/**
	 * Create an instance of {@link ForgotPasswdResult }
	 * 
	 */
	public ForgotPasswdResult createForgotPasswdResult() {
		return new ForgotPasswdResult();
	}

	/**
	 * Create an instance of {@link UpdateSyncDataResult }
	 * 
	 */
	public UpdateSyncDataResult createUpdateSyncDataResult() {
		return new UpdateSyncDataResult();
	}

	/**
	 * Create an instance of {@link PhotoEntity }
	 * 
	 */
	public PhotoEntity createPhotoEntity() {
		return new PhotoEntity();
	}

	/**
	 * Create an instance of {@link GraduateEntity }
	 * 
	 */
	public GraduateEntity createGraduateEntity() {
		return new GraduateEntity();
	}

	/**
	 * Create an instance of {@link PageEntity }
	 * 
	 */
	public PageEntity createPageEntity() {
		return new PageEntity();
	}

	/**
	 * Create an instance of {@link UpdateSyncDataResult.Receipts }
	 * 
	 */
	public UpdateSyncDataResult.Receipts createUpdateSyncDataResultReceipts() {
		return new UpdateSyncDataResult.Receipts();
	}

	/**
	 * Create an instance of {@link UpdateSyncDataParam.SyncDatas }
	 * 
	 */
	public UpdateSyncDataParam.SyncDatas createUpdateSyncDataParamSyncDatas() {
		return new UpdateSyncDataParam.SyncDatas();
	}

	/**
	 * Create an instance of {@link FindAppsysAuthParam }
	 * 
	 */
	public FindAppsysAuthParam createFindAppsysAuthParam() {
		return new FindAppsysAuthParam();
	}

	/**
	 * Create an instance of {@link UpdateSyncDataParam }
	 * 
	 */
	public UpdateSyncDataParam createUpdateSyncDataParam() {
		return new UpdateSyncDataParam();
	}

	/**
	 * Create an instance of {@link SyncDataEntity }
	 * 
	 */
	public SyncDataEntity createSyncDataEntity() {
		return new SyncDataEntity();
	}

	/**
	 * Create an instance of {@link FindAppsysAuthResult }
	 * 
	 */
	public FindAppsysAuthResult createFindAppsysAuthResult() {
		return new FindAppsysAuthResult();
	}

	/**
	 * Create an instance of {@link FindSyncDataResult.SyncDatas }
	 * 
	 */
	public FindSyncDataResult.SyncDatas createFindSyncDataResultSyncDatas() {
		return new FindSyncDataResult.SyncDatas();
	}

	/**
	 * Create an instance of {@link WriteIncrReceiptParam.Receipts }
	 * 
	 */
	public WriteIncrReceiptParam.Receipts createWriteIncrReceiptParamReceipts() {
		return new WriteIncrReceiptParam.Receipts();
	}

	/**
	 * Create an instance of {@link ForgotPasswdParam }
	 * 
	 */
	public ForgotPasswdParam createForgotPasswdParam() {
		return new ForgotPasswdParam();
	}

	/**
	 * Create an instance of {@link UnderGraduateEntity }
	 * 
	 */
	public UnderGraduateEntity createUnderGraduateEntity() {
		return new UnderGraduateEntity();
	}

	/**
	 * Create an instance of {@link TeacherEntity }
	 * 
	 */
	public TeacherEntity createTeacherEntity() {
		return new TeacherEntity();
	}

	/**
	 * Create an instance of {@link ReceiptEntity }
	 * 
	 */
	public ReceiptEntity createReceiptEntity() {
		return new ReceiptEntity();
	}

	/**
	 * Create an instance of {@link UserLoginParam }
	 * 
	 */
	public UserLoginParam createUserLoginParam() {
		return new UserLoginParam();
	}

	/**
	 * Create an instance of {@link WriteBeginOrEndReceiptParam }
	 * 
	 */
	public WriteBeginOrEndReceiptParam createWriteBeginOrEndReceiptParam() {
		return new WriteBeginOrEndReceiptParam();
	}

	/**
	 * Create an instance of {@link OrgEntity }
	 * 
	 */
	public OrgEntity createOrgEntity() {
		return new OrgEntity();
	}

	/**
	 * Create an instance of {@link WriteIncrReceiptParam }
	 * 
	 */
	public WriteIncrReceiptParam createWriteIncrReceiptParam() {
		return new WriteIncrReceiptParam();
	}

	/**
	 * Create an instance of {@link FindSyncDataResult }
	 * 
	 */
	public FindSyncDataResult createFindSyncDataResult() {
		return new FindSyncDataResult();
	}

	/**
	 * Create an instance of {@link ChangePasswdResult }
	 * 
	 */
	public ChangePasswdResult createChangePasswdResult() {
		return new ChangePasswdResult();
	}

	/**
	 * Create an instance of {@link WriteReceiptResult }
	 * 
	 */
	public WriteReceiptResult createWriteReceiptResult() {
		return new WriteReceiptResult();
	}

	/**
	 * Create an instance of {@link AttachEntity }
	 * 
	 */
	public AttachEntity createAttachEntity() {
		return new AttachEntity();
	}

	/**
	 * Create an instance of {@link AuthEntity }
	 * 
	 */
	public AuthEntity createAuthEntity() {
		return new AuthEntity();
	}

	/**
	 * Create an instance of {@link ChangePasswdParam }
	 * 
	 */
	public ChangePasswdParam createChangePasswdParam() {
		return new ChangePasswdParam();
	}
}