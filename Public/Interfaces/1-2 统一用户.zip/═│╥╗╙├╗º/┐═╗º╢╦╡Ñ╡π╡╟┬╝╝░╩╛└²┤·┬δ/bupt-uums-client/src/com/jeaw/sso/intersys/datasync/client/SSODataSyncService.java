package com.jeaw.sso.intersys.datasync.client;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlSeeAlso;

@WebService(targetNamespace = "http://www.jeaw.com/sso", name = "SSODataSyncService")
@XmlSeeAlso({ObjectFactory.class})
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
public interface SSODataSyncService {
	@WebMethod(operationName = "findFullUser", action = "findFullUser")
	@WebResult(name = "findFullUserResult", targetNamespace = "http://www.jeaw.com/sso", partName = "findFullUserResult")
	public FindSyncDataResult findFullUser(
			@WebParam(name = "findFullUserParam", targetNamespace = "http://www.jeaw.com/sso", partName = "findFullUserParam") FindSyncDataParam findFullUserParam);

	@WebMethod(operationName = "findIncrUser", action = "findIncrUser")
	@WebResult(name = "findIncrUserResult", targetNamespace = "http://www.jeaw.com/sso", partName = "findIncrUserResult")
	public FindSyncDataResult findIncrUser(
			@WebParam(name = "findIncrUserParam", targetNamespace = "http://www.jeaw.com/sso", partName = "findIncrUserParam") FindSyncDataParam findIncrUserParam);

	@WebMethod(operationName = "findFullPhoto", action = "findFullPhoto")
	@WebResult(name = "findFullPhotoResult", targetNamespace = "http://www.jeaw.com/sso", partName = "findFullPhotoResult")
	public FindSyncDataResult findFullPhoto(
			@WebParam(name = "findFullPhotoParam", targetNamespace = "http://www.jeaw.com/sso", partName = "findFullPhotoParam") FindSyncDataParam findFullPhotoParam);

	@WebMethod(operationName = "findIncrPhoto", action = "findIncrPhoto")
	@WebResult(name = "findIncrPhotoResult", targetNamespace = "http://www.jeaw.com/sso", partName = "findIncrPhotoResult")
	public FindSyncDataResult findIncrPhoto(
			@WebParam(name = "findIncrPhotoParam", targetNamespace = "http://www.jeaw.com/sso", partName = "findIncrPhotoParam") FindSyncDataParam findIncrPhotoParam);

	@WebMethod(operationName = "findFullBarcode", action = "findFullBarcode")
	@WebResult(name = "findFullBarcodeResult", targetNamespace = "http://www.jeaw.com/sso", partName = "findFullBarcodeResult")
	public FindSyncDataResult findFullBarcode(
			@WebParam(name = "findFullBarcodeParam", targetNamespace = "http://www.jeaw.com/sso", partName = "findFullBarcodeParam") FindSyncDataParam findFullBarcodeParam);

	@WebMethod(operationName = "findIncrBarcode", action = "findIncrBarcode")
	@WebResult(name = "findIncrBarcodeResult", targetNamespace = "http://www.jeaw.com/sso", partName = "findIncrBarcodeResult")
	public FindSyncDataResult findIncrBarcode(
			@WebParam(name = "findIncrBarcodeParam", targetNamespace = "http://www.jeaw.com/sso", partName = "findIncrBarcodeParam") FindSyncDataParam findIncrBarcodeParam);

	@WebMethod(operationName = "findFullOrg", action = "findFullOrg")
	@WebResult(name = "findFullOrgResult", targetNamespace = "http://www.jeaw.com/sso", partName = "findFullOrgResult")
	public FindSyncDataResult findFullOrg(
			@WebParam(name = "findFullOrgParam", targetNamespace = "http://www.jeaw.com/sso", partName = "findFullOrgParam") FindSyncDataParam findFullOrgParam);

	@WebMethod(operationName = "findIncrOrg", action = "findIncrOrg")
	@WebResult(name = "findIncrOrgResult", targetNamespace = "http://www.jeaw.com/sso", partName = "findIncrOrgResult")
	public FindSyncDataResult findIncrOrg(
			@WebParam(name = "findIncrOrgParam", targetNamespace = "http://www.jeaw.com/sso", partName = "findIncrOrgParam") FindSyncDataParam findIncrOrgParam);

	@WebMethod(operationName = "updateFullUser", action = "updateFullUser")
	@WebResult(name = "updateFullUserResult", targetNamespace = "http://www.jeaw.com/sso", partName = "updateFullUserResult")
	public UpdateSyncDataResult updateFullUser(
			@WebParam(name = "updateFullUserParam", targetNamespace = "http://www.jeaw.com/sso", partName = "updateFullUserParam") UpdateSyncDataParam updateFullUserParam);

	@WebMethod(operationName = "updateIncrUser", action = "updateIncrUser")
	@WebResult(name = "updateIncrUserResult", targetNamespace = "http://www.jeaw.com/sso", partName = "updateIncrUserResult")
	public UpdateSyncDataResult updateIncrUser(
			@WebParam(name = "updateIncrUserParam", targetNamespace = "http://www.jeaw.com/sso", partName = "updateIncrUserParam") UpdateSyncDataParam updateIncrUserParam);

	@WebMethod(operationName = "updateFullPhoto", action = "updateFullPhoto")
	@WebResult(name = "updateFullPhotoResult", targetNamespace = "http://www.jeaw.com/sso", partName = "updateFullPhotoResult")
	public UpdateSyncDataResult updateFullPhoto(
			@WebParam(name = "updateFullPhotoParam", targetNamespace = "http://www.jeaw.com/sso", partName = "updateFullPhotoParam") UpdateSyncDataParam updateFullPhotoParam);

	@WebMethod(operationName = "updateIncrPhoto", action = "updateIncrPhoto")
	@WebResult(name = "updateIncrPhotoResult", targetNamespace = "http://www.jeaw.com/sso", partName = "updateIncrPhotoResult")
	public UpdateSyncDataResult updateIncrPhoto(
			@WebParam(name = "updateIncrPhotoParam", targetNamespace = "http://www.jeaw.com/sso", partName = "updateIncrPhotoParam") UpdateSyncDataParam updateIncrPhotoParam);

	@WebMethod(operationName = "updateFullBarcode", action = "updateFullBarcode")
	@WebResult(name = "updateFullBarcodeResult", targetNamespace = "http://www.jeaw.com/sso", partName = "updateFullBarcodeResult")
	public UpdateSyncDataResult updateFullBarcode(
			@WebParam(name = "updateFullBarcodeParam", targetNamespace = "http://www.jeaw.com/sso", partName = "updateFullBarcodeParam") UpdateSyncDataParam updateFullBarcodeParam);

	@WebMethod(operationName = "updateIncrBarcode", action = "updateIncrBarcode")
	@WebResult(name = "updateIncrBarcodeResult", targetNamespace = "http://www.jeaw.com/sso", partName = "updateIncrBarcodeResult")
	public UpdateSyncDataResult updateIncrBarcode(
			@WebParam(name = "updateIncrBarcodeParam", targetNamespace = "http://www.jeaw.com/sso", partName = "updateIncrBarcodeParam") UpdateSyncDataParam updateIncrBarcodeParam);

	@WebMethod(operationName = "updateFullOrg", action = "updateFullOrg")
	@WebResult(name = "updateFullOrgResult", targetNamespace = "http://www.jeaw.com/sso", partName = "updateFullOrgResult")
	public UpdateSyncDataResult updateFullOrg(
			@WebParam(name = "updateFullOrgParam", targetNamespace = "http://www.jeaw.com/sso", partName = "updateFullOrgParam") UpdateSyncDataParam updateFullOrgParam);

	@WebMethod(operationName = "updateIncrOrg", action = "updateIncrOrg")
	@WebResult(name = "updateIncrOrgResult", targetNamespace = "http://www.jeaw.com/sso", partName = "updateIncrOrgResult")
	public UpdateSyncDataResult updateIncrOrg(
			@WebParam(name = "updateIncrOrgParam", targetNamespace = "http://www.jeaw.com/sso", partName = "updateIncrOrgParam") UpdateSyncDataParam updateIncrOrgParam);

	@WebMethod(operationName = "changePasswd", action = "changePasswd")
	@WebResult(name = "changePasswdResult", targetNamespace = "http://www.jeaw.com/sso", partName = "changePasswdResult")
	public ChangePasswdResult changePasswd(
			@WebParam(name = "changePasswdParam", targetNamespace = "http://www.jeaw.com/sso", partName = "changePasswdParam") ChangePasswdParam changePasswdParam);

	@WebMethod(operationName = "forgotPasswd", action = "forgotPasswd")
	@WebResult(name = "forgotPasswdResult", targetNamespace = "http://www.jeaw.com/sso", partName = "forgotPasswdResult")
	public ForgotPasswdResult forgotPasswd(
			@WebParam(name = "forgotPasswdParam", targetNamespace = "http://www.jeaw.com/sso", partName = "forgotPasswdParam") ForgotPasswdParam forgotPasswdParam);

	@WebMethod(operationName = "userLogin", action = "userLogin")
	@WebResult(name = "userLoginResult", targetNamespace = "http://www.jeaw.com/sso", partName = "userLoginResult")
	public UserLoginResult userLogin(
			@WebParam(name = "userLoginParam", targetNamespace = "http://www.jeaw.com/sso", partName = "userLoginParam") UserLoginParam userLoginParam);

	@WebMethod(operationName = "findAppsysAuth", action = "findAppsysAuth")
	@WebResult(name = "findAppsysAuthResult", targetNamespace = "http://www.jeaw.com/sso", partName = "findAppsysAuthResult")
	public FindAppsysAuthResult findAppsysAuth(
			@WebParam(name = "findAppsysAuthParam", targetNamespace = "http://www.jeaw.com/sso", partName = "findAppsysAuthParam") FindAppsysAuthParam findAppsysAuthParam);

	@WebMethod(operationName = "writeBeginOrEndReceipt", action = "writeBeginOrEndReceipt")
	@WebResult(name = "writeBeginOrEndReceiptResult", targetNamespace = "http://www.jeaw.com/sso", partName = "writeBeginOrEndReceiptResult")
	public WriteReceiptResult writeBeginOrEndReceipt(
			@WebParam(name = "writeBeginOrEndReceiptParam", targetNamespace = "http://www.jeaw.com/sso", partName = "writeBeginOrEndReceiptParam") WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam);

	@WebMethod(operationName = "writeIncrReceipt", action = "writeIncrReceipt")
	@WebResult(name = "writeIncrReceiptResult", targetNamespace = "http://www.jeaw.com/sso", partName = "writeIncrReceiptResult")
	public WriteReceiptResult writeIncrReceipt(
			@WebParam(name = "writeIncrReceiptParam", targetNamespace = "http://www.jeaw.com/sso", partName = "writeIncrReceiptParam") WriteIncrReceiptParam writeIncrReceiptParam);
}