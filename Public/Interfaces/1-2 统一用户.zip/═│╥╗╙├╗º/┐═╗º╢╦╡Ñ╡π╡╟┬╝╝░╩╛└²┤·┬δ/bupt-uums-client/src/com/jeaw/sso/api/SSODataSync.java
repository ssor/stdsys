package com.jeaw.sso.api;

import com.jeaw.sso.intersys.datasync.client.ChangePasswdParam;
import com.jeaw.sso.intersys.datasync.client.ChangePasswdResult;
import com.jeaw.sso.intersys.datasync.client.FindAppsysAuthParam;
import com.jeaw.sso.intersys.datasync.client.FindAppsysAuthResult;
import com.jeaw.sso.intersys.datasync.client.FindSyncDataParam;
import com.jeaw.sso.intersys.datasync.client.FindSyncDataResult;
import com.jeaw.sso.intersys.datasync.client.ForgotPasswdParam;
import com.jeaw.sso.intersys.datasync.client.ForgotPasswdResult;
import com.jeaw.sso.intersys.datasync.client.SSODataSyncService;
import com.jeaw.sso.intersys.datasync.client.SSODataSyncServiceImpl;
import com.jeaw.sso.intersys.datasync.client.UpdateSyncDataParam;
import com.jeaw.sso.intersys.datasync.client.UpdateSyncDataResult;
import com.jeaw.sso.intersys.datasync.client.UserLoginParam;
import com.jeaw.sso.intersys.datasync.client.UserLoginResult;
import com.jeaw.sso.intersys.datasync.client.WriteBeginOrEndReceiptParam;
import com.jeaw.sso.intersys.datasync.client.WriteIncrReceiptParam;
import com.jeaw.sso.intersys.datasync.client.WriteReceiptResult;

public class SSODataSync {
	public FindSyncDataResult findFullUser(FindSyncDataParam findFullUserParam) {
		SSODataSyncService serviceClient = getServiceClient();

		FindSyncDataResult result = serviceClient.findFullUser(findFullUserParam);

		return result;
	}

	public FindSyncDataResult findIncrUser(FindSyncDataParam findIncrUserParam) {
		SSODataSyncService serviceClient = getServiceClient();

		FindSyncDataResult result = serviceClient.findIncrUser(findIncrUserParam);

		return result;
	}

	public FindSyncDataResult findFullPhoto(FindSyncDataParam findFullPhotoParam) {
		SSODataSyncService serviceClient = getServiceClient();

		FindSyncDataResult result = serviceClient.findFullPhoto(findFullPhotoParam);

		return result;
	}

	public FindSyncDataResult findIncrPhoto(FindSyncDataParam findIncrPhotoParam) {
		SSODataSyncService serviceClient = getServiceClient();

		FindSyncDataResult result = serviceClient.findIncrPhoto(findIncrPhotoParam);

		return result;
	}

	public FindSyncDataResult findFullBarcode(FindSyncDataParam findFullBarcodeParam) {
		SSODataSyncService serviceClient = getServiceClient();

		FindSyncDataResult result = serviceClient.findFullBarcode(findFullBarcodeParam);

		return result;
	}

	public FindSyncDataResult findIncrBarcode(FindSyncDataParam findIncrBarcodeParam) {
		SSODataSyncService serviceClient = getServiceClient();

		FindSyncDataResult result = serviceClient.findIncrBarcode(findIncrBarcodeParam);

		return result;
	}

	public FindSyncDataResult findFullOrg(FindSyncDataParam findFullOrgParam) {
		SSODataSyncService serviceClient = getServiceClient();

		FindSyncDataResult result = serviceClient.findFullOrg(findFullOrgParam);

		return result;
	}

	public FindSyncDataResult findIncrOrg(FindSyncDataParam findIncrOrgParam) {
		SSODataSyncService serviceClient = getServiceClient();

		FindSyncDataResult result = serviceClient.findIncrOrg(findIncrOrgParam);

		return result;
	}

	public UpdateSyncDataResult updateFullUser(UpdateSyncDataParam updateFullUserParam) {
		SSODataSyncService serviceClient = getServiceClient();

		UpdateSyncDataResult result = serviceClient.updateFullUser(updateFullUserParam);

		return result;
	}

	public UpdateSyncDataResult updateIncrUser(UpdateSyncDataParam updateIncrUserParam) {
		SSODataSyncService serviceClient = getServiceClient();

		UpdateSyncDataResult result = serviceClient.updateIncrUser(updateIncrUserParam);

		return result;
	}

	public UpdateSyncDataResult updateFullPhoto(UpdateSyncDataParam updateFullPhotoParam) {
		SSODataSyncService serviceClient = getServiceClient();

		UpdateSyncDataResult result = serviceClient.updateFullPhoto(updateFullPhotoParam);

		return result;
	}

	public UpdateSyncDataResult updateIncrPhoto(UpdateSyncDataParam updateIncrPhotoParam) {
		SSODataSyncService serviceClient = getServiceClient();

		UpdateSyncDataResult result = serviceClient.updateIncrPhoto(updateIncrPhotoParam);

		return result;
	}

	public UpdateSyncDataResult updateFullBarcode(UpdateSyncDataParam updateFullBarcodeParam) {
		SSODataSyncService serviceClient = getServiceClient();

		UpdateSyncDataResult result = serviceClient.updateFullBarcode(updateFullBarcodeParam);

		return result;
	}

	public UpdateSyncDataResult updateIncrBarcode(UpdateSyncDataParam updateIncrBarcodeParam) {
		SSODataSyncService serviceClient = getServiceClient();

		UpdateSyncDataResult result = serviceClient.updateIncrBarcode(updateIncrBarcodeParam);

		return result;
	}

	public UpdateSyncDataResult updateFullOrg(UpdateSyncDataParam updateFullOrgParam) {
		SSODataSyncService serviceClient = getServiceClient();

		UpdateSyncDataResult result = serviceClient.updateFullOrg(updateFullOrgParam);

		return result;
	}

	public UpdateSyncDataResult updateIncrOrg(UpdateSyncDataParam updateIncrOrgParam) {
		SSODataSyncService serviceClient = getServiceClient();

		UpdateSyncDataResult result = serviceClient.updateIncrOrg(updateIncrOrgParam);

		return result;
	}

	public ChangePasswdResult changePasswd(ChangePasswdParam changePasswdParam) {
		SSODataSyncService serviceClient = getServiceClient();

		ChangePasswdResult result = serviceClient.changePasswd(changePasswdParam);

		return result;
	}

	public ForgotPasswdResult forgotPasswd(ForgotPasswdParam forgotPasswdParam) {
		SSODataSyncService serviceClient = getServiceClient();

		ForgotPasswdResult result = serviceClient.forgotPasswd(forgotPasswdParam);

		return result;
	}

	public UserLoginResult userLogin(UserLoginParam userLoginParam) {
		SSODataSyncService serviceClient = getServiceClient();

		UserLoginResult result = serviceClient.userLogin(userLoginParam);

		return result;
	}

	public FindAppsysAuthResult findAppsysAuth(FindAppsysAuthParam findAppsysAuthParam) {
		SSODataSyncService serviceClient = getServiceClient();

		FindAppsysAuthResult result = serviceClient.findAppsysAuth(findAppsysAuthParam);

		return result;
	}

	public WriteReceiptResult writeBeginOrEndReceipt(WriteBeginOrEndReceiptParam writeBeginOrEndReceiptParam) {
		SSODataSyncService serviceClient = getServiceClient();

		WriteReceiptResult result = serviceClient.writeBeginOrEndReceipt(writeBeginOrEndReceiptParam);

		return result;
	}

	public WriteReceiptResult writeIncrReceipt(WriteIncrReceiptParam writeIncrReceiptParam) {
		SSODataSyncService serviceClient = getServiceClient();

		WriteReceiptResult result = serviceClient.writeIncrReceipt(writeIncrReceiptParam);

		return result;
	}

	private SSODataSyncService getServiceClient() {
		SSODataSyncService serviceClient = new SSODataSyncServiceImpl().getSSODataSyncServicePort();

		return serviceClient;
	}
}