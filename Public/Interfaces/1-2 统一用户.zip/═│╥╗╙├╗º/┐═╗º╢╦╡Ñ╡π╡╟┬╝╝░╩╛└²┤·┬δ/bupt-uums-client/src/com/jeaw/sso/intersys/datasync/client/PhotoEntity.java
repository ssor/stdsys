package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "photoEntity", propOrder = {"userCode", "photo"})
public class PhotoEntity extends SyncDataEntity {
	protected String userCode;
	protected AttachEntity photo;

	/**
	 * Gets the value of the userCode property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getUserCode() {
		return userCode;
	}

	/**
	 * Sets the value of the userCode property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setUserCode(String value) {
		this.userCode = value;
	}

	/**
	 * Gets the value of the photo property.
	 * 
	 * @return possible object is {@link AttachEntity }
	 * 
	 */
	public AttachEntity getPhoto() {
		return photo;
	}

	/**
	 * Sets the value of the photo property.
	 * 
	 * @param value allowed object is {@link AttachEntity }
	 * 
	 */
	public void setPhoto(AttachEntity value) {
		this.photo = value;
	}
}