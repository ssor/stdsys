package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "orgEntity", propOrder = {"jgdm", "jgmc", "jgywmc", "jgjc", "jgywjc", "jgjp", "dz", "sjjgdm", "jgjb",
		"jglb", "sfyx", "sfst", "jgbb", "pxh", "yzbm", "dhhm", "czhm", "email"})
public class OrgEntity extends SyncDataEntity {
	protected String jgdm;
	protected String jgmc;
	protected String jgywmc;
	protected String jgjc;
	protected String jgywjc;
	protected String jgjp;
	protected String dz;
	protected String sjjgdm;
	protected Integer jgjb;
	protected String jglb;
	protected String sfyx;
	protected String sfst;
	protected String jgbb;
	protected Integer pxh;
	protected String yzbm;
	protected String dhhm;
	protected String czhm;
	protected String email;

	/**
	 * Gets the value of the jgdm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getJgdm() {
		return jgdm;
	}

	/**
	 * Sets the value of the jgdm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setJgdm(String value) {
		this.jgdm = value;
	}

	/**
	 * Gets the value of the jgmc property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getJgmc() {
		return jgmc;
	}

	/**
	 * Sets the value of the jgmc property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setJgmc(String value) {
		this.jgmc = value;
	}

	/**
	 * Gets the value of the jgywmc property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getJgywmc() {
		return jgywmc;
	}

	/**
	 * Sets the value of the jgywmc property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setJgywmc(String value) {
		this.jgywmc = value;
	}

	/**
	 * Gets the value of the jgjc property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getJgjc() {
		return jgjc;
	}

	/**
	 * Sets the value of the jgjc property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setJgjc(String value) {
		this.jgjc = value;
	}

	/**
	 * Gets the value of the jgywjc property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getJgywjc() {
		return jgywjc;
	}

	/**
	 * Sets the value of the jgywjc property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setJgywjc(String value) {
		this.jgywjc = value;
	}

	/**
	 * Gets the value of the jgjp property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getJgjp() {
		return jgjp;
	}

	/**
	 * Sets the value of the jgjp property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setJgjp(String value) {
		this.jgjp = value;
	}

	/**
	 * Gets the value of the dz property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDz() {
		return dz;
	}

	/**
	 * Sets the value of the dz property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setDz(String value) {
		this.dz = value;
	}

	/**
	 * Gets the value of the sjjgdm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSjjgdm() {
		return sjjgdm;
	}

	/**
	 * Sets the value of the sjjgdm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSjjgdm(String value) {
		this.sjjgdm = value;
	}

	/**
	 * Gets the value of the jgjb property.
	 * 
	 * @return possible object is {@link Integer }
	 * 
	 */
	public Integer getJgjb() {
		return jgjb;
	}

	/**
	 * Sets the value of the jgjb property.
	 * 
	 * @param value allowed object is {@link Integer }
	 * 
	 */
	public void setJgjb(Integer value) {
		this.jgjb = value;
	}

	/**
	 * Gets the value of the jglb property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getJglb() {
		return jglb;
	}

	/**
	 * Sets the value of the jglb property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setJglb(String value) {
		this.jglb = value;
	}

	/**
	 * Gets the value of the sfyx property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSfyx() {
		return sfyx;
	}

	/**
	 * Sets the value of the sfyx property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSfyx(String value) {
		this.sfyx = value;
	}

	/**
	 * Gets the value of the sfst property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSfst() {
		return sfst;
	}

	/**
	 * Sets the value of the sfst property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSfst(String value) {
		this.sfst = value;
	}

	/**
	 * Gets the value of the jgbb property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getJgbb() {
		return jgbb;
	}

	/**
	 * Sets the value of the jgbb property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setJgbb(String value) {
		this.jgbb = value;
	}

	/**
	 * Gets the value of the pxh property.
	 * 
	 * @return possible object is {@link Integer }
	 * 
	 */
	public Integer getPxh() {
		return pxh;
	}

	/**
	 * Sets the value of the pxh property.
	 * 
	 * @param value allowed object is {@link Integer }
	 * 
	 */
	public void setPxh(Integer value) {
		this.pxh = value;
	}

	/**
	 * Gets the value of the yzbm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getYzbm() {
		return yzbm;
	}

	/**
	 * Sets the value of the yzbm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setYzbm(String value) {
		this.yzbm = value;
	}

	/**
	 * Gets the value of the dhhm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDhhm() {
		return dhhm;
	}

	/**
	 * Sets the value of the dhhm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setDhhm(String value) {
		this.dhhm = value;
	}

	/**
	 * Gets the value of the czhm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCzhm() {
		return czhm;
	}

	/**
	 * Sets the value of the czhm property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setCzhm(String value) {
		this.czhm = value;
	}

	/**
	 * Gets the value of the email property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the value of the email property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setEmail(String value) {
		this.email = value;
	}
}