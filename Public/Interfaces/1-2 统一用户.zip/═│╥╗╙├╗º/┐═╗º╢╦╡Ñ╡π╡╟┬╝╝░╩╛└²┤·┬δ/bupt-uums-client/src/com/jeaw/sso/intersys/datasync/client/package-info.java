@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.jeaw.com/sso", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.jeaw.sso.intersys.datasync.client;