/*
 * @(#)Configer.java 2008-5-7
 * 
 * jWorks 版权所有2006~2010。
 */
package com.jeaw.sso.commons.util;

import java.io.PrintWriter;
import java.util.Properties;

/**
 * 读取配置文件的工具。
 * 
 * @author junzai
 * @version 1.0 2008-5-7
 */
public class Configer {
	/** 配置文件属性保存对象。 */
	private static Properties props = new Properties();

	/** 日志输出对象。 */
	private static PrintWriter out = null;

	/** 执行配置文件对象初始化。 */
	static {
		init("/intersysConfig.properties");
	}

	/**
	 * 加载配置文件。
	 * 
	 * @param configClassPath 配置文件的类路径。
	 */
	public static void load(String configClassPath) {
		init(configClassPath);
	}

	/**
	 * 获取以字符串格式返回的值。
	 * 
	 * @param key 属性键。
	 * @return 属性键对应的属性值。
	 */
	public static String getString(String key) {
		return props.getProperty(key);
	}

	/**
	 * 获取以整型格式返回的值。
	 * 
	 * @param key 属性键。
	 * @return 属性键对应的属性值。
	 */
	public static Integer getInteger(String key) {
		return Integer.parseInt(props.getProperty(key));
	}

	/**
	 * 获取以布尔型格式返回的值。
	 * 
	 * @param key 属性键。
	 * @return 属性键对应的属性值。
	 */
	public static Boolean getBoolean(String key) {
		return Boolean.parseBoolean(props.getProperty(key));
	}

	/**
	 * 执行配置类的初始化。
	 * 
	 * @param configClassPath 配置文件所在的类路径。
	 */
	private static void init(String configClassPath) {
		try {
			props.load(Configer.class.getResourceAsStream(configClassPath));
			System.out.println("加载属性文件成功！");
		} catch (Exception e) {
			System.out.println("加载属性文件出错！");
			e.printStackTrace();
		}
	}
}