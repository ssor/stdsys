package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "receiptEntity", propOrder = {"syncInfoId", "syncType", "code", "message"})
public class ReceiptEntity {
	protected String syncInfoId;
	protected String syncType;
	protected String code;
	protected String message;

	/**
	 * Gets the value of the syncInfoId property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSyncInfoId() {
		return syncInfoId;
	}

	/**
	 * Sets the value of the syncInfoId property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSyncInfoId(String value) {
		this.syncInfoId = value;
	}

	/**
	 * Gets the value of the syncType property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSyncType() {
		return syncType;
	}

	/**
	 * Sets the value of the syncType property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSyncType(String value) {
		this.syncType = value;
	}

	/**
	 * Gets the value of the code property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Sets the value of the code property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setCode(String value) {
		this.code = value;
	}

	/**
	 * Gets the value of the message property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the value of the message property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setMessage(String value) {
		this.message = value;
	}
}