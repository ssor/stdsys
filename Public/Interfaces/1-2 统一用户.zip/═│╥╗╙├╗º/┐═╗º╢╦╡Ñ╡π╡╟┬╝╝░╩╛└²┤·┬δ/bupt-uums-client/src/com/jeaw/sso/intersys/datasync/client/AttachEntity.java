package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "attachEntity", propOrder = {"filename", "fileExt", "fileContent"})
public class AttachEntity {
	protected String filename;
	protected String fileExt;
	protected byte[] fileContent;

	/**
	 * Gets the value of the filename property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * Sets the value of the filename property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setFilename(String value) {
		this.filename = value;
	}

	/**
	 * Gets the value of the fileExt property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getFileExt() {
		return fileExt;
	}

	/**
	 * Sets the value of the fileExt property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setFileExt(String value) {
		this.fileExt = value;
	}

	/**
	 * Gets the value of the fileContent property.
	 * 
	 * @return possible object is byte[]
	 */
	public byte[] getFileContent() {
		return fileContent;
	}

	/**
	 * Sets the value of the fileContent property.
	 * 
	 * @param value allowed object is byte[]
	 */
	public void setFileContent(byte[] value) {
		this.fileContent = value;
	}
}