package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "barcodeEntity", propOrder = {"userCode", "barcode"})
public class BarcodeEntity extends SyncDataEntity {
	protected String userCode;
	protected String barcode;

	/**
	 * Gets the value of the userCode property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getUserCode() {
		return userCode;
	}

	/**
	 * Sets the value of the userCode property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setUserCode(String value) {
		this.userCode = value;
	}

	/**
	 * Gets the value of the barcode property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getBarcode() {
		return barcode;
	}

	/**
	 * Sets the value of the barcode property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setBarcode(String value) {
		this.barcode = value;
	}
}