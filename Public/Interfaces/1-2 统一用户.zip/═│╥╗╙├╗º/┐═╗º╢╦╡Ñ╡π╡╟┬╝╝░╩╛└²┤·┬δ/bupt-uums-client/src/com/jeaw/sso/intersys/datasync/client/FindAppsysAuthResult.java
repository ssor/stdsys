package com.jeaw.sso.intersys.datasync.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "findAppsysAuthResult", propOrder = {"code", "message", "passwd", "desKey", "md5Key", "publicKey",
		"privateKey"})
public class FindAppsysAuthResult {
	protected String code;
	protected String message;
	protected String passwd;
	protected String desKey;
	protected String md5Key;
	protected String publicKey;
	protected String privateKey;

	/**
	 * Gets the value of the code property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Sets the value of the code property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setCode(String value) {
		this.code = value;
	}

	/**
	 * Gets the value of the message property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the value of the message property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setMessage(String value) {
		this.message = value;
	}

	/**
	 * Gets the value of the passwd property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPasswd() {
		return passwd;
	}

	/**
	 * Sets the value of the passwd property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setPasswd(String value) {
		this.passwd = value;
	}

	/**
	 * Gets the value of the desKey property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDesKey() {
		return desKey;
	}

	/**
	 * Sets the value of the desKey property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setDesKey(String value) {
		this.desKey = value;
	}

	/**
	 * Gets the value of the md5Key property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMd5Key() {
		return md5Key;
	}

	/**
	 * Sets the value of the md5Key property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setMd5Key(String value) {
		this.md5Key = value;
	}

	/**
	 * Gets the value of the publicKey property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPublicKey() {
		return publicKey;
	}

	/**
	 * Sets the value of the publicKey property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setPublicKey(String value) {
		this.publicKey = value;
	}

	/**
	 * Gets the value of the privateKey property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPrivateKey() {
		return privateKey;
	}

	/**
	 * Sets the value of the privateKey property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setPrivateKey(String value) {
		this.privateKey = value;
	}
}