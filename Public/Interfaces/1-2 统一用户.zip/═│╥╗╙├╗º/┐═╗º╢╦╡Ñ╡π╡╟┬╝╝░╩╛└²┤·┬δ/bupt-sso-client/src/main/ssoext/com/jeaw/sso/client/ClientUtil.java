package com.jeaw.sso.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientUtil {
	private static Logger logger = LoggerFactory.getLogger(ClientUtil.class);

	/**
	 * 获取url的内容。
	 * 
	 * @param url 要获取的url。
	 * @return url的内容。
	 * @throws IOException
	 */
	public static String retrieve(String url) throws IOException {
		if (logger.isTraceEnabled()) {
			logger.trace("entering retrieve(" + url + ")");
		}

		BufferedReader r = null;

		try {
			URL u = new URL(url);

			// 不强制要求一定要用https协议，即http与https都兼容。
			// if (!u.getProtocol().equals("https")) {
			// // IOException may not be the best exception we could throw here
			// // since the problem is with the URL argument we were passed,
			// // not
			// // IO. -awp9
			// log.error("retrieve(" + url +
			// ") on an illegal URL since protocol was not https.");
			// throw new
			// IOException("only 'https' URLs are valid for this method");
			// }

			URLConnection uc = u.openConnection();
			uc.setRequestProperty("Connection", "close");

			// 默认使用UTF-8编码方式。
			r = new BufferedReader(new InputStreamReader(uc.getInputStream(), "UTF-8"));

			String line;
			StringBuffer buf = new StringBuffer();
			while ((line = r.readLine()) != null) {
				buf.append(line + "\n");
			}

			return buf.toString();
		} finally {
			try {
				if (r != null) {
					r.close();
				}
			} catch (IOException ex) {
				// ignore
			}
		}
	}

	/**
	 * 根据serverName获取service。
	 * 
	 * @param request 请求对象。
	 * @param serverName 客户端服务器名称（带端口号）。
	 * @return service。
	 * @throws ServletException
	 */
	public static String getService(HttpServletRequest request, String serverName) throws ServletException {
		if (logger.isTraceEnabled()) {
			logger.trace("entering getService(" + request + ", " + serverName + ")");
		}

		// ensure we have a server name
		if (serverName == null) {
			logger.error("getService() argument \"serverName\" was illegally null.");
			throw new IllegalArgumentException("name of server is required");
		}

		// now, construct our best guess at the string
		StringBuffer sb = new StringBuffer();
		if (request.isSecure()) {
			sb.append("https://");
		} else {
			sb.append("http://");
		}
		sb.append(serverName);
		sb.append(request.getRequestURI());

		if (request.getQueryString() != null) {
			// first, see whether we've got a 'ticket' at all
			int ticketLoc = request.getQueryString().indexOf("ticket=");

			// if ticketLoc == 0, then it's the only parameter and we ignore
			// the whole query string

			// if no ticket is present, we use the query string wholesale
			if (ticketLoc == -1) {
				sb.append("?" + request.getQueryString());
			} else if (ticketLoc > 0) {
				ticketLoc = request.getQueryString().indexOf("&ticket=");
				if (ticketLoc == -1) {
					// there was a 'ticket=' unrelated to a parameter named
					// 'ticket'
					sb.append("?" + request.getQueryString());
				} else if (ticketLoc > 0) {
					// otherwise, we use the query string up to "&ticket="
					sb.append("?" + request.getQueryString().substring(0, ticketLoc));
				}
			}
		}

		String encodedService = null;
		try {
			encodedService = URLEncoder.encode(sb.toString(), "UTF-8");
		} catch (Exception e) {
			logger.error("getService() encoding service error", e);
			throw new ServletException(e);
		}

		if (logger.isTraceEnabled()) {
			logger.trace("returning from getService() with encoded service [" + encodedService + "]");
		}

		return encodedService;
	}

	/**
	 * 重定向到SSOServer进行登录。
	 * 
	 * @param request 请求对象。
	 * @param response 响应对象。
	 * @param loginUrl 登录url。
	 * @param serverName 客户端服务器名称（带端口号）。
	 * @throws IOException
	 * @throws ServletException
	 */
	public static void redirectToSSOServer(HttpServletRequest request, HttpServletResponse response, String loginUrl,
			String serverName) throws IOException, ServletException {
		String serverLoginString = loginUrl + "?service=" + ClientUtil.getService(request, serverName);

		if (logger.isDebugEnabled()) {
			logger.debug("Redirecting browser to [" + serverLoginString + ")");
		}

		response.sendRedirect(serverLoginString);

		if (logger.isTraceEnabled()) {
			logger.trace("returning from redirectToSSOServer()");
		}
	}

	/**
	 * 验证票据是否正确，验证通过返回验证信息封装对象。
	 * 
	 * @param request 请求对象。
	 * @param validateUrl 服务端验证url。
	 * @param service 客户端url。
	 * @param ticket 传递的票据。
	 * @return 验证信息的封装对象。
	 * @throws ServletException
	 */
	public static Receipt getAuthenticatedUser(HttpServletRequest request, String validateUrl, String service,
			String ticket) throws ServletException {
		logger.trace("entering getAuthenticatedUser()");

		ProxyTicketValidator pv = new ProxyTicketValidator();
		pv.setValidateUrl(validateUrl);
		pv.setService(service);
		pv.setServiceTicket(ticket);
		pv.setRenew(false);

		if (logger.isDebugEnabled()) {
			logger.debug("about to validate ProxyTicketValidator: [" + pv + "]");
		}

		try {
			return Receipt.getReceipt(pv);
		} catch (AuthenticationException e) {
			throw new ServletException(e);
		}
	}
}