package com.jeaw.sso.client;

import javax.servlet.http.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FilterRequestWrapper extends HttpServletRequestWrapper {
	private static Logger logger = LoggerFactory.getLogger(FilterRequestWrapper.class);

	public FilterRequestWrapper(HttpServletRequest request) {
		super(request);
		if (logger.isTraceEnabled()) {
			logger.trace("wrapping an HttpServletRequest in a FilterRequestWrapper.");
		}
	}

	/**
	 * <p>
	 * Returns the currently logged in SSOServer user.
	 * </p>
	 * <p>
	 * Specifically, this returns the value of the session attribute,
	 * <code>Constants.SESSION_USER</code>.
	 * </p>
	 */
	public String getRemoteUser() {
		String user = (String)getSession().getAttribute(Constants.SESSION_USER);
		if (logger.isTraceEnabled()) {
			logger.trace("getRemoteUser() returning [" + user + "]");
		}
		return user;
	}
}