/*
 * @(#)CustomizeSSOHelper.java 2009-12-28
 * 
 * jeaw 版权所有2006~2015。
 */

package com.jeaw.sso.client.example;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.jeaw.sso.client.DefaultSSOHelper;

/**
 * 自定义单点登录接口实现，从DefaultSSOHelper继承，可以重写getSSOObject和setSSOObject两个接口。
 * 
 * @author junzai
 * @version 1.0 2009-12-28
 */
public class CustomizeSSOHelper extends DefaultSSOHelper {
	private static final String SESSION_USER = "session.user";
	private static final String SESSION_USER_ROLES = "session.user.roles";

	/**
	 * 获取登录成功后保存在session中的验证信息对象。
	 * 
	 * @param request 请求对象。
	 * @return 验证信息对象。
	 */
	protected Object getSSOObject(HttpServletRequest request) {
		HttpSession session = request.getSession();

		return session.getAttribute(SESSION_USER);
	}

	/**
	 * 将登录成功后的验证信息对象保存在session中。
	 * 
	 * @param request 请求对象。
	 * @param username 登录的帐号。
	 */
	protected void setSSOObject(HttpServletRequest request, String username, List<Map<String, String>> userRoles) {
		// 通过username来进行个性的定制工作，比如查出系统用户，然后保存到session中。
		HttpSession session = request.getSession();

		session.setAttribute(SESSION_USER, username);
		session.setAttribute(SESSION_USER_ROLES, userRoles);
	}
}