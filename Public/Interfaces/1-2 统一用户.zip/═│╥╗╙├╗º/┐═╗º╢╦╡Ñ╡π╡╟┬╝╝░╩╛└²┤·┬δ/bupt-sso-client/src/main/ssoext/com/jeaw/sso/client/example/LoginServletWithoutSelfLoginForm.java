/*
 * @(#)LoginServletWithoutSelfLoginForm.java 2009-12-28
 * 
 * jeaw 版权所有2006~2015。
 */

package com.jeaw.sso.client.example;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jeaw.sso.client.DefaultSSOHelper;
import com.jeaw.sso.client.SSOHelper;

/**
 * 不保留原登录框的验证servlet，可以参照此类，service方法在ssoHelper.sso后，添加自己的处理逻辑。
 * 
 * @author junzai
 * @version 1.0 2009-12-28
 */
public class LoginServletWithoutSelfLoginForm extends HttpServlet {
	/**
	 * servlet的初始化，获取初始配置信息。
	 * 
	 * @param config servlet配置对象。
	 * @throws ServletException
	 */
	public void init(final ServletConfig config) throws ServletException {
		super.init(config);

		// key1：需要初始化。
		DefaultSSOHelper.init(config);
	}

	/**
	 * 响应servlet的每次请求，并进行处理。
	 * 
	 * @param request 请求对象。
	 * @param response 响应对象。
	 * @throws IOException
	 * @throws ServletException
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException,
			ServletException {
		// key2：使用ssoHelper单点登录，如果失败，则直接返回。
		SSOHelper ssoHelper = new DefaultSSOHelper();
		if (!ssoHelper.sso(request, response)) {
			return;
		}

		request.getRequestDispatcher("/ssoclient/examples/successWithoutSelfLoginForm.jsp").forward(request, response);
	}
}