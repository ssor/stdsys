package com.jeaw.sso.client;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class ProxyTicketValidator extends ServiceTicketValidator {
	protected List proxyList;

	/**
	 * Retrieves a list of proxies involved in the current authentication.
	 */
	public List getProxyList() {
		return proxyList;
	}

	protected DefaultHandler newHandler() {
		return new ProxyHandler();
	}

	protected class ProxyHandler extends ServiceTicketValidator.Handler {
		protected static final String PROXIES = "cas:proxies";
		protected static final String PROXY = "cas:proxy";

		protected List proxyList = new ArrayList();
		protected boolean proxyFragment = false;

		public void startElement(String ns, String ln, String qn, Attributes a) {
			super.startElement(ns, ln, qn, a);
			if (authenticationSuccess && qn.equals(PROXIES)) {
				proxyFragment = true;
			}
		}

		public void endElement(String ns, String ln, String qn) throws SAXException {
			super.endElement(ns, ln, qn);
			if (qn.equals(PROXIES)) {
				proxyFragment = false;
			} else if (proxyFragment && qn.equals(PROXY)) {
				proxyList.add(currentText.toString().trim());
			}
		}

		public void endDocument() throws SAXException {
			super.endDocument();
			if (authenticationSuccess) {
				ProxyTicketValidator.this.proxyList = proxyList;
			}
		}
	}

	/**
	 * Clears internally manufactured state.
	 */
	protected void clear() {
		super.clear();
		proxyList = null;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("[");
		sb.append(ProxyTicketValidator.class.getName());
		sb.append(" proxyList=[");
		sb.append(this.proxyList);
		sb.append("] ");
		sb.append(super.toString());
		sb.append("]");
		return sb.toString();
	}
}