/*
 * @(#)LoginServletUsingFilter.java 2009-12-28
 * 
 * jeaw 版权所有2006~2015。
 */

package com.jeaw.sso.client.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jeaw.sso.client.Constants;

/**
 * 采用filter方式的单点登录成功后的处理。
 * 
 * @author junzai
 * @version 1.0 2009-12-28
 */
public class LoginServletUsingFilter extends HttpServlet {
	public void service(HttpServletRequest request, HttpServletResponse response) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@hanguanghui:1521:oradev", "uums", "uums");

			String loginid = (String)request.getSession().getAttribute(Constants.SESSION_USER);

			stmt = conn.createStatement();
			rs = stmt.executeQuery("select 1 from t_sys_user where loginid='" + loginid + "'");

			if (rs.next()) {
				request.getRequestDispatcher("/ssoclient/examples/successUsingFilter.jsp").forward(request, response);
			} else {
				request.getRequestDispatcher("/ssoclient/examples/failureUsingFilter.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}