package com.jeaw.sso.client;

public class AuthenticationException extends Exception {
	/**
	 * @param string
	 */
	public AuthenticationException(String string) {
		super(string);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public AuthenticationException(String message, Throwable cause) {
		super(message, cause);
	}
}