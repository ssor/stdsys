package com.jeaw.sso.client;

public class Constants {
	/**
	 * SSOServer登录的url（必须设置）。
	 */
	public static final String LOGIN_INIT_PARAM = "sso.server.loginUrl";

	/**
	 * SSOServer验证的url（必须设置）。
	 */
	public static final String VALIDATE_INIT_PARAM = "sso.server.validateUrl";

	/**
	 * 访问SSOServer的客户端url（如果SERVERNAME_INIT_PARAM没有设置，则必须设置，
	 * 与SERVERNAME_INIT_PARAM二选一）。
	 */
	public static final String SERVICE_INIT_PARAM = "sso.client.serviceUrl";

	/**
	 * 访问SSOServer的客户端名称（主机+端口，如果SERVICE_INIT_PARAM没有设置，则必须设置，
	 * 与SERVICE_INIT_PARAM二选一）。
	 */
	public static final String SERVERNAME_INIT_PARAM = "sso.client.serverName";

	/**
	 * value of SSOServer "renew" parameter. Bypasses single sign-on and
	 * requires user to provide SSOServer with his/her credentials again. This
	 * should either be "true" or not be set. It is mutually exclusive with
	 * GATEWAY. (Optional. If nothing is specified, this defaults to false.)
	 */
	public static final String RENEW_INIT_PARAM = "sso.client.renew";

	/**
	 * The name of the filter initialization parameter the value of which must
	 * be a whitespace delimited list of services (ProxyTicketReceptors)
	 * authorized to proxy authentication to the service filtered by this
	 * Filter. These must be https: URLs. This parameter is optional - not
	 * setting it results in no proxy tickets being acceptable.
	 */
	public static final String AUTHORIZED_PROXY_INIT_PARAM = "sso.client.authorizedProxy";

	/**
	 * URL of local proxy callback listener used to acquire PGT/PGTIOU.
	 * (Optional)
	 */
	public static final String PROXY_CALLBACK_INIT_PARAM = "sso.client.proxyCallbackUrl";

	/**
	 * The name of the filter initialization parameter the value of which
	 * indicates whether this filter should wrap requests to expose the
	 * authenticated username.
	 */
	public static final String WRAP_REQUESTS_INIT_PARAM = "sso.client.wrapRequest";

	/**
	 * The name of the filter initialization parameter the value of which is the
	 * value the Filter should send for the gateway parameter on the SSOServer
	 * login request.
	 */
	public static final String GATEWAY_INIT_PARAM = "sso.client.gateway";

	/**
	 * 验证通过后，将userName保存到该key代表的session中。
	 */
	public static final String SESSION_USER = "sso.client.session.user";

	/**
	 * 验证通过后，将Receipt保存到该key代表的session中。
	 */
	public static final String SESSION_RECEIPT = "sso.client.session.receipt";

	/**
	 * Session attribute in which internally used gateway attribute is stored.
	 */
	public static final String SESSION_GATEWAYED = "sso.client.session.didGateway";
}