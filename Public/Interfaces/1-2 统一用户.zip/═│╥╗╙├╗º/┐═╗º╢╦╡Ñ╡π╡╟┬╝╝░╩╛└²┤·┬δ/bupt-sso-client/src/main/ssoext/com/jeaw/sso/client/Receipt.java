package com.jeaw.sso.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Receipt {
	private static Logger logger = LoggerFactory.getLogger(Receipt.class);

	/**
	 * Get a Receipt from a ProxyTicketValidator. While the ptv properties must
	 * be set, you may or may not have already called ptv.validate(). If the
	 * ProxyTicketValidator has not already been validated, this method will
	 * validate the ptv.
	 * 
	 * @param ptv - a ProxyTicketValidator from which to harvest the receipt.
	 * @return Receipt encapsulating fruits of authentication.
	 * @throws AuthenticationException - if ticket validation fails for any
	 *             reason.
	 */
	public static Receipt getReceipt(ProxyTicketValidator ptv) throws AuthenticationException {
		if (logger.isTraceEnabled()) {
			logger.trace("entering getReceipt(ProxyTicketValidator=[" + ptv + "])");
		}

		if (!ptv.isAuthenticationSuccesful()) {
			try {
				ptv.validate();
			} catch (Exception e) {
				AuthenticationException authenticationException = new AuthenticationException(
						"Unable to validate ProxyTicketValidator [" + ptv + "]", e);
				logger.error("Unable to validate ProxyTicketValidator [" + ptv + "]", authenticationException);
				throw authenticationException;
			}
		}

		if (!ptv.isAuthenticationSuccesful()) {
			logger.error("validation of [" + ptv + "] was not successful.");
			throw new AuthenticationException("Unable to validate ProxyTicketValidator [" + ptv + "]");
		}

		Receipt receipt = new Receipt();
		receipt.validateUrl = ptv.getValidateUrl();
		receipt.pgtIou = ptv.getPgtIou();
		receipt.userName = ptv.getUser();

		String userRolesAsString = ptv.getUserRolesAsString();
		receipt.userRoles = Receipt.userRolesString2ListMap(userRolesAsString);
		if (logger.isDebugEnabled()) {
			logger.debug("Receipt[getReceipt], userRolesAsString=[" + userRolesAsString + "]");
		}

		String userDetailsAsString = ptv.getUserDetailsAsString();
		receipt.userDetails = Receipt.userDetailsString2Map(userDetailsAsString);
		if (logger.isDebugEnabled()) {
			logger.debug("Receipt[getReceipt], userDetailsAsString=[" + userDetailsAsString + "]");
		}

		String userAppsysesAsString = ptv.getUserAppsysesAsString();
		receipt.userAppsyses = ((userAppsysesAsString == null) ? "" : userAppsysesAsString);
		if (logger.isDebugEnabled()) {
			logger.debug("Receipt[getReceipt], userAppsysesAsString=[" + userAppsysesAsString + "]");
		}

		receipt.proxyCallbackUrl = ptv.getProxyCallbackUrl();
		receipt.proxyList = ptv.getProxyList();
		receipt.primaryAuthentication = ptv.isRenew();

		if (!receipt.validate()) {
			throw new AuthenticationException("Validation of [" + ptv
					+ "] did not result in an internally consistent Receipt.");
		}

		if (logger.isTraceEnabled()) {
			logger.trace("returning from getReceipt() with return value [" + receipt + "]");
		}

		return receipt;
	}

	/**
	 * The SSOServer validation service URL against which the ticket was
	 * validated.
	 */
	private String validateUrl;

	/** The PGTIOU, if any. */
	private String pgtIou;

	/** Was authentication by presentation of primary credentials. */
	private boolean primaryAuthentication = false;

	/** The URL, if any, to which the SSOServer sent the PGT,PGTIOU pair. */
	private String proxyCallbackUrl;

	/**
	 * List of services through which authentication was proxied, if any, from
	 * most recent back to service ticket recipient.
	 */
	private List proxyList = new ArrayList();

	/** The authenticated username. */
	private String userName;

	/** The authenticated userRoles. */
	private List<Map<String, String>> userRoles;

	/** The authenticated userAppsyses. */
	private String userAppsyses = "";

	/** The authenticated userDetails. */
	private Map<String, String> userDetails;

	/**
	 * Do-nothing constructor. You probably want to call
	 * getReceipt(ProxyTicketValidator);
	 */
	public Receipt() {
		// does nothing
	}

	/**
	 * Get the URL of the SSOServer ticket validation service against which the
	 * ticket leading to this receipt was authenticated.
	 * 
	 * @return the URL of the SSOServer ticket validation service.
	 */
	public String getValidateUrl() {
		return this.validateUrl;
	}

	/**
	 * Get the Proxy Granting Ticket IOU, if any, associated with the
	 * authentication represented by this receipt.
	 * 
	 * @return the PGTIOU, or NULL.
	 */
	public String getPgtIou() {
		return this.pgtIou;
	}

	/**
	 * Get the Proxy Callback URL, if any.
	 * 
	 * @return the Proxy Callback URL, or NULL if none was set.
	 */
	public String getProxyCallbackUrl() {
		return this.proxyCallbackUrl;
	}

	/**
	 * Get the list of proxies, if any, in the authentication chain. List is in
	 * order from closest proxying service back to the original recipient of a
	 * Service Ticket. See also the convenience method proxyingService().
	 * 
	 * @return an unmodifiable view on the proxy list.
	 */
	public List getProxyList() {
		return Collections.unmodifiableList(this.proxyList);
	}

	/**
	 * Get the authenticated username.
	 * 
	 * @return the authenticated username.
	 */
	public String getUserName() {
		return this.userName;
	}

	/**
	 * Get the authenticated userRolesAsString.
	 * 
	 * @return the authenticated userRoles.
	 */
	public List<Map<String, String>> getUserRoles() {
		return this.userRoles;
	}

	/**
	 * Get the authenticated userAppsysesAsString.
	 * 
	 * @return the authenticated userAppsyses.
	 */
	public String getUserAppsyses() {
		return this.userAppsyses;
	}

	/**
	 * Get the authenticated userDetailsAsString.
	 * 
	 * @return the authenticated userDetails.
	 */
	public Map<String, String> getUserDetails() {
		return this.userDetails;
	}

	/**
	 * Was the authentication accomplished by presentation of primary
	 * credentials (e.g. a password). (As opposed to presentation of secondary
	 * credentials, such as a Single Sign On session cookie.) That is, was the
	 * renew parameter set to true on the request to validate the (service)
	 * ticket.
	 * 
	 * @return true if authentication was by primary credentials, false
	 *         otherwise.
	 */
	public boolean isPrimaryAuthentication() {
		return this.primaryAuthentication;
	}

	/**
	 * Was authentication proxied by another service.
	 * 
	 * @return true if authentication was proxied by another service, false
	 *         otherwise.
	 */
	public boolean isProxied() {
		return (!this.proxyList.isEmpty());
	}

	/**
	 * Get the URL of the service proxying authentication to this application,
	 * if any.
	 * 
	 * @return the URL of the service proxying authentication to this
	 *         application, or NULL.
	 */
	public String getProxyingService() {
		if (proxyList.isEmpty()) {
			return null;
		}
		return (String)proxyList.get(0);
	}

	/**
	 * @param validateUrl The validateUrl to set.
	 */
	public void setValidateUrl(String validateUrl) {
		this.validateUrl = validateUrl;
	}

	/**
	 * @param pgtIou The pgtIou to set.
	 */
	public void setPgtIou(String pgtIou) {
		this.pgtIou = pgtIou;
	}

	/**
	 * @param primaryAuthentication The primaryAuthentication to set.
	 */
	public void setPrimaryAuthentication(boolean primaryAuthentication) {
		this.primaryAuthentication = primaryAuthentication;
	}

	/**
	 * @param proxyCallbackUrl The proxyCallbackUrl to set.
	 */
	public void setProxyCallbackUrl(String proxyCallbackUrl) {
		this.proxyCallbackUrl = proxyCallbackUrl;
	}

	/**
	 * @param proxyList The proxyList to set.
	 */
	public void setProxyList(List proxyList) {
		this.proxyList = proxyList;
	}

	/**
	 * @param userName The userName to set.
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @param userRolesAsString The userRolesAsString to set.
	 */
	public void setUserRoles(List<Map<String, String>> userRoles) {
		this.userRoles = userRoles;
	}

	/**
	 * @param userAppsysesAsString The userAppsysesAsString to set.
	 */
	public void setUserAppsyses(String userAppsyses) {
		this.userAppsyses = userAppsyses;
	}

	/**
	 * @param userDetailsAsString The userDetailsAsString to set.
	 */
	public void setUserDetails(Map<String, String> userDetails) {
		this.userDetails = userDetails;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("[");
		sb.append(Receipt.class.getName());
		sb.append(" userName=[");
		sb.append(this.userName);
		sb.append("]");
		sb.append(" userRolesAsString=[");
		sb.append(this.userRoles);
		sb.append("]");
		sb.append(" userAppsysesAsString=[");
		sb.append(this.userAppsyses);
		sb.append("]");
		sb.append(" userDetailsAsString=[");
		sb.append(this.userDetails);
		sb.append("]");
		sb.append(" validateUrl=[");
		sb.append(this.validateUrl);
		sb.append("]");
		sb.append(" proxyCallbackUrl=[");
		sb.append(this.proxyCallbackUrl);
		sb.append("]");
		sb.append(" pgtIou=[");
		sb.append(this.pgtIou);
		sb.append("]");
		sb.append(" validateUrl=[");
		sb.append(this.validateUrl);
		sb.append("]");
		sb.append(" proxyList=[");
		sb.append(this.proxyList);
		sb.append("]");

		sb.append("]");
		return sb.toString();
	}

	/**
	 * Is this Receipt internally complete and consistent. Issues logging
	 * messages at error level recording reasons why receipt is invalid, if any.
	 * 
	 * @return true if internally consistent, false otherwise.
	 */
	private boolean validate() {
		boolean valid = true;
		if (this.userName == null) {
			logger.error("Receipt was invalid because userName was null. Receipt:[" + this + "]");
			valid = false;
		}
		if (this.validateUrl == null) {
			logger.error("Receipt was invalid because validateUrl was null.  Receipt:[" + this + "]");
			valid = false;
		}
		if (this.proxyList == null) {
			logger.error("receipt was invalid because " + "proxyList was null.  Receipt:[" + this + "]");
			valid = false;
		}

		if (this.primaryAuthentication && !this.proxyList.isEmpty()) {
			logger.error("If authentication was by primary credentials then it could not have been proxied. "
					+ "Yet, primaryAuthentication is true where proxyList is not empty.  Receipt:[" + this + "]");
			valid = false;
		}

		return valid;
	}

	/**
	 * change user roles as string to List<Map<String, String>>.
	 * 
	 * @param userRolesAsString - the user roles as string..
	 * @return List<Map<String, String>> userRoles of login user..
	 */
	private static List<Map<String, String>> userRolesString2ListMap(String userRolesAsString) {
		List<Map<String, String>> userRolesListMap = new ArrayList<Map<String, String>>();
		if (userRolesAsString != null) {
			String[] groupArray = userRolesAsString.split(";");
			if (groupArray != null && groupArray.length > 0) {
				for (String groupString : groupArray) {
					if (groupString != null) {
						String[] eachArray = groupString.split(",");
						if (eachArray != null && eachArray.length >= 4) {
							Map<String, String> map = new HashMap<String, String>();
							map.put("roleCode", change2CustomerNull(eachArray[0]));
							map.put("roleName", change2CustomerNull(eachArray[1]));
							map.put("roleType", change2CustomerNull(eachArray[2]));
							map.put("roleAttr", change2CustomerNull(eachArray[3]));
							userRolesListMap.add(map);
						}
					}
				}
			}
		}

		return userRolesListMap;
	}

	/**
	 * change user details as string to Map<String, String>.
	 * 
	 * @param userDetailsAsString - the user details as string..
	 * @return Map<String, String> userDetails of login user..
	 */
	private static Map<String, String> userDetailsString2Map(String userDetailsAsString) {
		Map<String, String> userDetailsMap = new HashMap<String, String>();
		if (userDetailsAsString != null) {
			String[] eachArray = userDetailsAsString.split(",");
			if (eachArray != null && eachArray.length >= 6) {
				userDetailsMap.put("userName", change2CustomerNull(eachArray[0]));
				userDetailsMap.put("loginId", change2CustomerNull(eachArray[1]));
				userDetailsMap.put("userType", change2CustomerNull(eachArray[2]));
				userDetailsMap.put("idCard", change2CustomerNull(eachArray[3]));
				userDetailsMap.put("gender", change2CustomerNull(eachArray[4]));
				userDetailsMap.put("orgCode", change2CustomerNull(eachArray[5]));
			}
		}

		return userDetailsMap;
	}

	/**
	 * change src to customer null.
	 * 
	 * @param src source string.
	 * @return changed string.
	 */
	private static String change2CustomerNull(String src) {
		if (src == null || "".equals(src.trim()) || "__null__".equals(src.trim())) {
			return "";
		}

		return src.trim();
	}
}