package com.jeaw.sso.client;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

public class ServiceTicketValidator {
	private String validateUrl;
	private String proxyCallbackUrl;
	private String st;
	private String service;
	private String pgtIou;
	private String user;
	private String userRolesAsString;
	private String userAppsysesAsString;
	private String userDetailsAsString;
	private String errorCode;
	private String errorMessage;
	private String entireResponse;
	private boolean renew = false;
	private boolean attemptedAuthentication;
	private boolean successfulAuthentication;

	/**
	 * Sets the SSOServer validation URL to use when validating tickets and
	 * retrieving PGT IOUs.
	 */
	public void setValidateUrl(String x) {
		this.validateUrl = x;
	}

	/**
	 * Gets the SSOServer validation URL to use when validating tickets and
	 * retrieving PGT IOUs.
	 */
	public String getValidateUrl() {
		return this.validateUrl;
	}

	/**
	 * Sets the callback URL, owned logically by the calling service, to receive
	 * the PGTid/PGTiou mapping.
	 */
	public void setProxyCallbackUrl(String x) {
		this.proxyCallbackUrl = x;
	}

	/**
	 * Sets the "renew" flag on authentication. When set to "true",
	 * authentication will only succeed if this was an initial login (forced by
	 * the "renew" flag being set on login).
	 */
	public void setRenew(boolean b) {
		this.renew = b;
	}

	/**
	 * Gets the callback URL, owned logically by the calling service, to receive
	 * the PGTid/PGTiou mapping.
	 */
	public String getProxyCallbackUrl() {
		return this.proxyCallbackUrl;
	}

	/**
	 * Sets the ST to validate.
	 */
	public void setServiceTicket(String x) {
		this.st = x;
	}

	/**
	 * Sets the service to use when validating.
	 */
	public void setService(String x) {
		this.service = x;
	}

	/**
	 * Returns the strongly authenticated username.
	 */
	public String getUser() {
		return this.user;
	}

	/**
	 * Returns the strongly authenticated userRolesAsString.
	 */
	public String getUserRolesAsString() {
		return this.userRolesAsString;
	}

	/**
	 * Returns the strongly authenticated userAppsysesAsString.
	 */
	public String getUserAppsysesAsString() {
		return this.userAppsysesAsString;
	}

	/**
	 * Returns the strongly authenticated userDetailsAsString.
	 */
	public String getUserDetailsAsString() {
		return this.userDetailsAsString;
	}

	/**
	 * Returns the PGT IOU returned by SSOServer.
	 */
	public String getPgtIou() {
		return this.pgtIou;
	}

	/**
	 * Returns <tt>true</tt> if the most recent authentication attempted
	 * succeeded, <tt>false</tt> otherwise.
	 */
	public boolean isAuthenticationSuccesful() {
		return this.successfulAuthentication;
	}

	/**
	 * Returns an error message if SSOServer authentication failed.
	 */
	public String getErrorMessage() {
		return this.errorMessage;
	}

	/**
	 * Returns SSOServer's error code if authentication failed.
	 */
	public String getErrorCode() {
		return this.errorCode;
	}

	/**
	 * Retrieves SSOServer's entire response, if authentication was succsesful.
	 */
	public String getResponse() {
		return this.entireResponse;
	}

	public void validate() throws IOException, SAXException, ParserConfigurationException {
		if (validateUrl == null || st == null) {
			throw new IllegalStateException("must set validation URL and ticket");
		}
		clear();
		attemptedAuthentication = true;
		StringBuffer sb = new StringBuffer();
		sb.append(validateUrl);
		if (validateUrl.indexOf('?') == -1) {
			sb.append('?');
		} else {
			sb.append('&');
		}
		sb.append("service=" + service + "&ticket=" + st);
		if (proxyCallbackUrl != null) {
			sb.append("&pgtUrl=" + proxyCallbackUrl);
		}
		if (renew) {
			sb.append("&renew=true");
		}
		String url = sb.toString();
		String response = ClientUtil.retrieve(url);
		this.entireResponse = response;

		// parse the response and set appropriate properties
		if (response != null) {
			XMLReader r = SAXParserFactory.newInstance().newSAXParser().getXMLReader();
			r.setFeature("http://xml.org/sax/features/namespaces", false);
			r.setContentHandler(newHandler());
			r.parse(new InputSource(new StringReader(response)));
		}
	}

	protected DefaultHandler newHandler() {
		return new Handler();
	}

	protected class Handler extends DefaultHandler {
		protected static final String AUTHENTICATION_SUCCESS = "cas:authenticationSuccess";
		protected static final String AUTHENTICATION_FAILURE = "cas:authenticationFailure";
		protected static final String PROXY_GRANTING_TICKET = "cas:proxyGrantingTicket";
		protected static final String USER = "cas:user";
		protected static final String USER_ROLES_AS_STRING = "cas:userRolesAsString";
		protected static final String USER_APPSYSES_AS_STRING = "cas:userAppsysesAsString";
		protected static final String USER_DETAILS_AS_STRING = "cas:userDetailsAsString";

		protected boolean authenticationSuccess = false;
		protected boolean authenticationFailure = false;
		protected String netid, pgtIou, errorCode, errorMessage;
		protected StringBuffer currentText = new StringBuffer();

		public void startElement(String ns, String ln, String qn, Attributes a) {
			// clear the buffer
			currentText = new StringBuffer();

			// check outer elements
			if (qn.equals(AUTHENTICATION_SUCCESS)) {
				authenticationSuccess = true;
			} else if (qn.equals(AUTHENTICATION_FAILURE)) {
				authenticationFailure = true;
				errorCode = a.getValue("code");
				if (errorCode != null) {
					errorCode = errorCode.trim();
				}
			}
		}

		public void characters(char[] ch, int start, int length) {
			// store the body, in stages if necessary
			currentText.append(ch, start, length);
		}

		public void endElement(String ns, String ln, String qn) throws SAXException {
			if (authenticationSuccess) {
				if (qn.equals(USER)) {
					user = currentText.toString().trim();
				}
				if (qn.equals(USER_ROLES_AS_STRING)) {
					userRolesAsString = currentText.toString().trim();
				}
				if (qn.equals(USER_APPSYSES_AS_STRING)) {
					userAppsysesAsString = currentText.toString().trim();
				}
				if (qn.equals(USER_DETAILS_AS_STRING)) {
					userDetailsAsString = currentText.toString().trim();
				}
				if (qn.equals(PROXY_GRANTING_TICKET)) {
					pgtIou = currentText.toString().trim();
				}
			} else if (authenticationFailure) {
				if (qn.equals(AUTHENTICATION_FAILURE)) {
					errorMessage = currentText.toString().trim();
				}
			}
		}

		public void endDocument() throws SAXException {
			// save values as appropriate
			if (authenticationSuccess) {
				ServiceTicketValidator.this.user = user;
				ServiceTicketValidator.this.userRolesAsString = userRolesAsString;
				ServiceTicketValidator.this.userAppsysesAsString = userAppsysesAsString;
				ServiceTicketValidator.this.userDetailsAsString = userDetailsAsString;
				ServiceTicketValidator.this.pgtIou = pgtIou;
				ServiceTicketValidator.this.successfulAuthentication = true;
			} else if (authenticationFailure) {
				ServiceTicketValidator.this.errorMessage = errorMessage;
				ServiceTicketValidator.this.errorCode = errorCode;
				ServiceTicketValidator.this.successfulAuthentication = false;
			} else {
				throw new SAXException("no indication of success or failure from SSOServer");
			}
		}
	}

	/**
	 * Clears internally manufactured state.
	 */
	protected void clear() {
		user = userRolesAsString = userAppsysesAsString = userDetailsAsString = pgtIou = errorMessage = null;
		attemptedAuthentication = false;
		successfulAuthentication = false;
	}

	/**
	 * Is this ServiceTicketValidator configured to pass renew=true on the
	 * ticket validation request?
	 * 
	 * @return true if renew=true on validation reqeust, false otherwise.
	 */
	public boolean isRenew() {
		return renew;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("[");
		sb.append(ServiceTicketValidator.class.getName());
		if (validateUrl != null) {
			sb.append(" validateUrl=[");
			sb.append(validateUrl);
			sb.append("]");
		}
		if (proxyCallbackUrl != null) {
			sb.append(" proxyCallbackUrl=[");
			sb.append(proxyCallbackUrl);
			sb.append("]");
		}
		if (st != null) {
			sb.append(" ticket=[");
			sb.append(st);
			sb.append("]");
		}
		if (service != null) {
			sb.append(" service=[");
			sb.append(service);
			sb.append("]");
		}
		if (pgtIou != null) {
			sb.append(" pgtIou=[");
			sb.append(pgtIou);
			sb.append("]");
		}
		if (user != null) {
			sb.append(" user=[");
			sb.append(user);
			sb.append("]");
		}
		if (userRolesAsString != null) {
			sb.append(" userRolesAsString=[");
			sb.append(userRolesAsString);
			sb.append("]");
		}
		if (userAppsysesAsString != null) {
			sb.append(" userAppsysesAsString=[");
			sb.append(userAppsysesAsString);
			sb.append("]");
		}
		if (userDetailsAsString != null) {
			sb.append(" userDetailsAsString=[");
			sb.append(userDetailsAsString);
			sb.append("]");
		}
		if (errorCode != null) {
			sb.append(" errorCode=[");
			sb.append(errorCode);
			sb.append("]");
		}
		if (errorMessage != null) {
			sb.append(" errorMessage=[");
			sb.append(errorMessage);
			sb.append("]");
		}
		sb.append(" renew=");
		sb.append(renew);
		if (entireResponse != null) {
			sb.append(" entireResponse=[");
			sb.append(entireResponse);
			sb.append("]");
		}
		sb.append("]");
		return sb.toString();
	}
}