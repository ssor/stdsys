/*
 * @(#)LoginServletWithSelfLoginForm.java 2009-12-28
 * 
 * jeaw 版权所有2006~2015。
 */

package com.jeaw.sso.client.example;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jeaw.sso.client.Constants;
import com.jeaw.sso.client.Receipt;
import com.jeaw.sso.client.ClientUtil;

/**
 * 保留原登录框的验证servlet，子类可以重写onSuccessLogin方法，添加自己的处理逻辑。
 * 
 * @author junzai
 * @version 1.0 2009-12-28
 */
public class LoginServletWithSelfLoginForm extends HttpServlet {
	private static Logger logger = LoggerFactory.getLogger(LoginServletWithSelfLoginForm.class);

	// 在session中用此key保存认证成功之后要导向的url，该key可以任意命名，只要不和其它的重复即可。
	private static final String LOGIN_SUCCESS_URL_PARAM = "login.success.url.param";

	// 当前请求的url。
	private static String requestUrl = null;

	// 单点登录服务器的访问地址。
	private static String loginUrl;

	// 单点登录服务器验证地址。
	private static String validateUrl;

	// 成功之后导向到的url。
	private static String serviceUrl;

	// 单点登录服务器名称。
	private static String serverName;

	/**
	 * servlet的初始化，获取初始配置信息。
	 * 
	 * @param config servlet配置对象。
	 * @throws ServletException
	 */
	public void init(final ServletConfig config) throws ServletException {
		super.init(config);

		loginUrl = config.getInitParameter(Constants.LOGIN_INIT_PARAM);
		validateUrl = config.getInitParameter(Constants.VALIDATE_INIT_PARAM);
		serviceUrl = config.getInitParameter(Constants.SERVICE_INIT_PARAM);
		serverName = config.getInitParameter(Constants.SERVERNAME_INIT_PARAM);
	}

	/**
	 * 响应servlet的每次请求，并进行处理。
	 * 
	 * @param request 请求对象。
	 * @param response 响应对象。
	 * @throws IOException
	 * @throws ServletException
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException,
			ServletException {
		// 到SSOServer服务器验证ticket，判断是否从SSOServer服务器验证回来。
		String ticket = request.getParameter("ticket");
		String error = request.getParameter("error");

		// 已经验证过，存在票据。
		if (ticket != null && !"".equals(ticket)) {
			String tempService = getRequestUrl(request);
			Receipt receipt = ClientUtil.getAuthenticatedUser(request, validateUrl, tempService, ticket);

			this.onSuccessLogin(request, receipt.getUserName());

			String loginSuccessUrl = (String)request.getSession().getAttribute(LOGIN_SUCCESS_URL_PARAM);

			if (loginSuccessUrl == null) {
				loginSuccessUrl = serviceUrl;
			}

			response.sendRedirect(loginSuccessUrl);
		} else {
			String loginSuccessUrl = request.getParameter("loginSuccessUrl");

			if (loginSuccessUrl == null) {
				loginSuccessUrl = serviceUrl;
				request.getSession().removeAttribute(LOGIN_SUCCESS_URL_PARAM);
			}

			if (error != null) {
				response.sendRedirect(loginSuccessUrl + "?error=" + error);
				return;
			} else {
				String username = request.getParameter("username");
				String password = request.getParameter("password");

				if (username == null || "".equals(username) || password == null || "".equals(password)) {

					// 获取票据，如果未登录，则重定向到SSOServer进行登录验证。
					if (ticket == null || "".equals(ticket)) {
						try {
							ClientUtil.redirectToSSOServer(request, response, loginUrl, serverName);
						} catch (Exception e) {
							logger.error("when redirect to SSOServer, something error", e);
							throw new ServletException(e);
						}
						return;
					}
				}

				request.getSession().setAttribute(LOGIN_SUCCESS_URL_PARAM, loginSuccessUrl);
				String currRequestUrl = getRequestUrl(request);

				// 带上&other=true参数，转向带有登录框的验证流程。
				response.sendRedirect(loginUrl + "?service=" + URLEncoder.encode(currRequestUrl, "UTF-8")
						+ "&username=" + username + "&password=" + password + "&other=true");
			}
		}
	}

	/**
	 * 认证成功后要执行的一些动作。
	 * <p>
	 * 一般要被重写，自己系统中需要什么样的信息，就获取什么信息。
	 * 
	 * @param request 当前请求的request。
	 * @param username 登录成功的用户号。
	 */
	protected void onSuccessLogin(HttpServletRequest request, String username) {
		request.getSession().setAttribute(Constants.SESSION_USER, username);
	}

	/**
	 * 获取当前请求的url。
	 * 
	 * @param request 请求对象。
	 * @return 当前请求的url。
	 */
	private static String getRequestUrl(HttpServletRequest request) {
		if (requestUrl == null) {
			requestUrl = request.getRequestURL().toString();
		}
		return requestUrl;
	}
}