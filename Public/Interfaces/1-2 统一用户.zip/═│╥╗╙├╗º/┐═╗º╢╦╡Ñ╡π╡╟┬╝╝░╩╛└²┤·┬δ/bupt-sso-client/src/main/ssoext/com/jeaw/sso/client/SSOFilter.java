package com.jeaw.sso.client;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SSOFilter implements Filter {
	private static Logger logger = LoggerFactory.getLogger(SSOFilter.class);

	/** Secure URL whereat SSOServer offers its login service. */
	private String loginUrl;

	/** Secure URL whereat SSOServer offers its SSOServer 2.0 validate service */
	private String validateUrl;

	/** Filtered service URL for use as service parameter to login and validate */
	private String serviceUrl;

	/**
	 * Name of server, for use in assembling service URL for use as service
	 * parameter to login and validate.
	 */
	private String serverName;

	/** True if renew parameter should be set on login and validate */
	private boolean renew;

	/**
	 * True if this filter should wrap requests to expose authenticated user as
	 * getRemoteUser();
	 */
	private boolean wrapRequest;

	/** True if this filter should set gateway=true on login redirect */
	private boolean gateway = false;

	/**
	 * Secure URL whereto this filter should ask SSOServer to send Proxy
	 * Granting Tickets.
	 */
	private String proxyCallbackUrl;

	/**
	 * List of ProxyTicketReceptor URLs of services authorized to proxy to the
	 * path behind this filter.
	 */
	private List authorizedProxies = new ArrayList();

	public void init(FilterConfig config) throws ServletException {
		loginUrl = config.getInitParameter(Constants.LOGIN_INIT_PARAM);
		validateUrl = config.getInitParameter(Constants.VALIDATE_INIT_PARAM);
		serviceUrl = config.getInitParameter(Constants.SERVICE_INIT_PARAM);
		String authorizedProxy = config.getInitParameter(Constants.AUTHORIZED_PROXY_INIT_PARAM);
		renew = Boolean.valueOf(config.getInitParameter(Constants.RENEW_INIT_PARAM)).booleanValue();
		serverName = config.getInitParameter(Constants.SERVERNAME_INIT_PARAM);
		proxyCallbackUrl = config.getInitParameter(Constants.PROXY_CALLBACK_INIT_PARAM);
		wrapRequest = Boolean.valueOf(config.getInitParameter(Constants.WRAP_REQUESTS_INIT_PARAM)).booleanValue();
		gateway = Boolean.valueOf(config.getInitParameter(Constants.GATEWAY_INIT_PARAM)).booleanValue();

		if (gateway && Boolean.valueOf(renew).booleanValue()) {
			throw new ServletException("gateway and renew cannot both be true in filter configuration");
		}
		if (serverName != null && serviceUrl != null) {
			throw new ServletException("serverName and serviceUrl cannot both be set: choose one.");
		}
		if (serverName == null && serviceUrl == null) {
			throw new ServletException("one of serverName or serviceUrl must be set.");
		}
		if (validateUrl == null) {
			throw new ServletException("validateUrl parameter must be set.");
		}

		if (authorizedProxy != null) {
			// parse and remember authorized proxies
			StringTokenizer proxies = new StringTokenizer(authorizedProxy);
			while (proxies.hasMoreTokens()) {
				String anAuthorizedProxy = proxies.nextToken();
				if (!anAuthorizedProxy.startsWith("https://")) {
					throw new ServletException("SSOFilter initialization parameter for authorized proxies "
							+ "must be a whitespace delimited list of authorized proxies.  "
							+ "Authorized proxies must be secure (https) addresses.  This one wasn't: ["
							+ anAuthorizedProxy + "]");
				}
				this.authorizedProxies.add(anAuthorizedProxy);
			}
		}

		if (logger.isDebugEnabled()) {
			logger.debug(("SSOFilter initialized as: [" + toString() + "]"));
		}
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain fc) throws ServletException,
			IOException {
		if (logger.isTraceEnabled()) {
			logger.trace("entering doFilter()");
		}

		// make sure we've got an HTTP request
		if (!(request instanceof HttpServletRequest) || !(response instanceof HttpServletResponse)) {
			logger.error("doFilter() called on a request or response that was not an HttpServletRequest or response.");
			throw new ServletException("SSOFilter protects only HTTP resources");
		}

		// Is this a request for the proxy callback listener? If so, pass
		// it through
		if (proxyCallbackUrl != null && proxyCallbackUrl.endsWith(((HttpServletRequest)request).getRequestURI())
				&& request.getParameter("pgtId") != null && request.getParameter("pgtIou") != null) {
			logger.trace("passing through what we hope is SSOServer's request for proxy ticket receptor.");
			fc.doFilter(request, response);
			return;
		}

		// Wrap the request if desired
		if (wrapRequest) {
			logger.trace("Wrapping request with FilterRequestWrapper.");
			request = new FilterRequestWrapper((HttpServletRequest)request);
		}

		HttpSession session = ((HttpServletRequest)request).getSession();

		// if our attribute's already present and valid, pass through the filter
		// chain
		Receipt receipt = (Receipt)session.getAttribute(Constants.SESSION_RECEIPT);
		if (receipt != null && isReceiptAcceptable(receipt)) {
			logger
					.trace("Constants.SESSION_RECEIPT attribute was present and acceptable - passing  request through filter..");
			fc.doFilter(request, response);
			return;
		}

		// otherwise, we need to authenticate via SSOServer
		String ticket = request.getParameter("ticket");

		// no ticket? abort request processing and redirect
		if (ticket == null || ticket.equals("")) {
			logger.trace("SSOServer ticket was not present on request.");
			// did we go through the gateway already?
			boolean didGateway = Boolean.valueOf((String)session.getAttribute(Constants.SESSION_GATEWAYED))
					.booleanValue();

			if (loginUrl == null) {
				logger.error("loginUrl was not set, so filter cannot redirect request for authentication.");
				throw new ServletException("When SSOFilter protects pages that do not receive a 'ticket' "
						+ "parameter, it needs a sso.server.loginUrl " + "filter parameter");
			}
			if (!didGateway) {
				logger.trace("Did not previously gateway.  Setting session attribute to true.");
				session.setAttribute(Constants.SESSION_GATEWAYED, "true");
				ClientUtil.redirectToSSOServer((HttpServletRequest)request, (HttpServletResponse)response, loginUrl,
						serverName);
				// abort chain
				return;
			} else {
				logger.trace("Previously gatewayed.");
				// if we should be logged in, make sure validation succeeded
				if (gateway || session.getAttribute(Constants.SESSION_USER) != null) {
					logger
							.trace("gateway was true and Constants.SESSION_USER set: passing request along filter chain.");
					// continue processing the request
					fc.doFilter(request, response);
					return;
				} else {
					// unknown state... redirect to SSOServer
					session.setAttribute(Constants.SESSION_GATEWAYED, "true");
					ClientUtil.redirectToSSOServer((HttpServletRequest)request, (HttpServletResponse)response,
							loginUrl, serverName);
					// abort chain
					return;
				}
			}
		}

		try {
			ticket = request.getParameter("ticket");
			String tempService = ClientUtil.getService((HttpServletRequest)request, serverName);
			receipt = ClientUtil.getAuthenticatedUser((HttpServletRequest)request, validateUrl, tempService, ticket);
		} catch (Exception e) {
			logger.error("getAuthenticatedUser error", e);
			throw new ServletException(e);
		}

		if (!isReceiptAcceptable(receipt)) {
			throw new ServletException(
					"Authentication was technically successful but rejected as a matter of policy. [" + receipt + "]");
		}

		// Store the authenticated user in the session
		if (session != null) { // probably unnecessary
			session.setAttribute(Constants.SESSION_USER, receipt.getUserName());
			session.setAttribute(Constants.SESSION_RECEIPT, receipt);

			// don't store extra unnecessary session state
			session.removeAttribute(Constants.SESSION_GATEWAYED);
		}
		if (logger.isTraceEnabled()) {
			logger.trace("validated ticket to get authenticated receipt [" + receipt
					+ "], now passing request along filter chain.");
		}

		// continue processing the request
		fc.doFilter(request, response);
		logger.trace("returning from doFilter()");
	}

	/**
	 * Is this receipt acceptable as evidence of authentication by credentials
	 * that would have been acceptable to this path? Current implementation
	 * checks whether from renew and whether proxy was authorized.
	 * 
	 * @param receipt
	 * @return true if acceptable, false otherwise
	 */
	private boolean isReceiptAcceptable(Receipt receipt) {
		if (receipt == null)
			throw new IllegalArgumentException("Cannot evaluate a null receipt.");
		if (this.renew && !receipt.isPrimaryAuthentication()) {
			return false;
		}
		if (receipt.isProxied()) {
			if (!this.authorizedProxies.contains(receipt.getProxyingService())) {
				return false;
			}
		}
		return true;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("[SSOFilter:");
		sb.append(" gateway=");
		sb.append(this.gateway);
		sb.append(" wrapRequest=");
		sb.append(this.wrapRequest);
		sb.append(" authorizedProxies=[");
		sb.append(this.authorizedProxies);
		sb.append("]");
		if (this.loginUrl != null) {
			sb.append(" loginUrl=[");
			sb.append(this.loginUrl);
			sb.append("]");
		} else {
			sb.append(" loginUrl=NULL!!!!!");
		}
		if (this.proxyCallbackUrl != null) {
			sb.append(" proxyCallbackUrl=[");
			sb.append(proxyCallbackUrl);
			sb.append("]");
		}
		if (this.renew) {
			sb.append(" renew=true");
		}
		if (this.serverName != null) {
			sb.append(" serverName=[");
			sb.append(serverName);
			sb.append("]");
		}
		if (this.serviceUrl != null) {
			sb.append(" serviceUrl=[");
			sb.append(serviceUrl);
			sb.append("]");
		}
		if (this.validateUrl != null) {
			sb.append(" validateUrl=[");
			sb.append(validateUrl);
			sb.append("]");
		} else {
			sb.append(" validateUrl=NULL!!!");
		}

		return sb.toString();
	}

	public void destroy() {
	}
}