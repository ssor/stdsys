/*
 * @(#)DefaultSSOHelper.java 2009-12-28
 * 
 * jeaw 版权所有2006~2015。
 */

package com.jeaw.sso.client;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 单点登录接口默认实现。
 * 
 * @author junzai
 * @version 1.0 2009-12-28
 */
public class DefaultSSOHelper implements SSOHelper {
	private static Logger logger = LoggerFactory.getLogger(DefaultSSOHelper.class);
	private static String loginUrl;
	private static String validateUrl;
	private static String serverName;

	/**
	 * SSO的初始化，从调用的servlet处获取初始配置信息。<br>
	 * 配置信息包括：loginUrl、validateUrl和serverName，即配置在servlet中的初始参数。<br>
	 * 
	 * @param config servlet配置对象。
	 */
	public static void init(final ServletConfig config) {
		loginUrl = config.getInitParameter(Constants.LOGIN_INIT_PARAM);
		validateUrl = config.getInitParameter(Constants.VALIDATE_INIT_PARAM);
		serverName = config.getInitParameter(Constants.SERVERNAME_INIT_PARAM);
	}

	/**
	 * 执行sso登录，并进行处理，处理成功之后会保存四个属性到session中，保存的属性和内容为：<br>
	 * session.setAttribute(Constants.SESSION_USER, receipt.getUserName());<br>
	 * session.setAttribute(Constants.SESSION_RECEIPT, receipt);<br>
	 * 
	 * @param request 请求对象。
	 * @param response 响应对象。
	 * @throws ServletException
	 */
	public boolean sso(HttpServletRequest request, HttpServletResponse response) throws ServletException {
		// 如果已经登录成功，则直接返回true，表示登录成功。
		if (this.getSSOObject(request) != null) {
			return true;
		}

		// 获取票据，如果未登录，则重定向到SSOServer进行登录验证。
		String ticket = request.getParameter("ticket");
		if (ticket == null || "".equals(ticket)) {
			try {
				ClientUtil.redirectToSSOServer(request, response, loginUrl, serverName);
			} catch (Exception e) {
				logger.error("when redirect to SSOServer, something error", e);
				throw new ServletException(e);
			}
			return false;
		}

		try {
			// 验证票据是否正确，并设置到session中。
			ticket = request.getParameter("ticket");
			String tempService = ClientUtil.getService(request, serverName);
			Receipt receipt = ClientUtil.getAuthenticatedUser(request, validateUrl, tempService, ticket);
			this.setSSOObject(request, receipt);
			this.setSSOObject(request, receipt.getUserName(), receipt.getUserRoles());
		} catch (Exception e) {
			logger.error("there something wrong when validate on SSOServer", e);
			throw new ServletException(e);
		}

		return true;
	}

	/**
	 * 获取登录成功后保存在session中的验证信息对象。<br>
	 * 验证对象在session中的属性默认为Constants.SESSION_USER，取出即为登录用户帐号。<br>
	 * 
	 * @param request 请求对象。
	 * @return 登录用户帐号。
	 */
	protected Object getSSOObject(HttpServletRequest request) {
		HttpSession session = request.getSession();
		return session.getAttribute(Constants.SESSION_USER);
	}

	/**
	 * 设置登录成功后的信息到session中，子类可以根据需要重写，设置自定义的内容。<br>
	 * 
	 * @param request 请求对象。
	 * @param value 需要重新设置的值。
	 */
	protected void setSSOObject(HttpServletRequest request, String username, List<Map<String, String>> userRoles) {
		// 留给子类扩展，子类可以在这里添加自定义的属性，并设置到session中。
		HttpSession session = request.getSession();
		session.setAttribute(Constants.SESSION_USER, username);
	}

	/**
	 * 将登录成功后的验证信息对象保存在session中，保存的属性和内容为：<br>
	 * session.setAttribute(Constants.SESSION_USER, receipt.getUserName());<br>
	 * session.setAttribute(Constants.SESSION_RECEIPT, receipt);<br>
	 * 
	 * @param request 请求对象。
	 * @param username 登录成功后的验证信息封装对象。
	 */
	private void setSSOObject(HttpServletRequest request, Receipt receipt) {
		HttpSession session = request.getSession();
		session.setAttribute(Constants.SESSION_USER, receipt.getUserName());
		session.setAttribute(Constants.SESSION_RECEIPT, receipt);
	}
}