/*
 * @(#)SSOHelper.java 2009-12-28
 * 
 * jeaw 版权所有2006~2015。
 */

package com.jeaw.sso.client;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 单点登录接口，有默认的实现类为DefaultSSOHelper。
 * 
 * @author junzai
 * @version 1.0 2009-12-28
 */
public interface SSOHelper {
	/**
	 * 单点登录接口。</br>
	 * 
	 * @return 是否登录成功。 登录失败返回false，登录成功返回true。
	 */
	public boolean sso(HttpServletRequest request, HttpServletResponse response) throws ServletException;
}